package ToolsQA;

public class WhatsAppAutomation {

	public static void main(String[] args) {
		WhatsAppDriver whatsapp = new WhatsAppDriver();
		whatsapp.open();
		//whatsapp.waitForConnection();
		//whatsapp.openConvWith("Vivek");
		//whatsapp.getCurrentConvImg();
		//whatsapp.getCurrentConvName();
		//whatsapp.getVisableMessages();
		whatsapp.sendMsg("Some text");
	}

}
