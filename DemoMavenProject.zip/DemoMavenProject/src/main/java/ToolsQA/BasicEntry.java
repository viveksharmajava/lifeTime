package ToolsQA;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.w3c.dom.Element;


/**
 * 
 */
public abstract class BasicEntry extends BasicInternalEntry
{
    protected Map<String, List<String>> attributes = new HashMap<String, List<String>>();

    //String IS_PREDEFINED = "_isPredefined";

    protected BasicEntry()
    {
    }

    protected BasicEntry(final String name)
    {
        super(name);
    }

    protected BasicEntry(final String name, final String displayName,
            final String description)
    {
        super(name,displayName,description);
    }

    

    protected BasicEntry (BasicEntry data)
    {
    		
    }
    
    public void addAttribute(String name, String value)
    {
        if(name!=null && value!=null) 
        {
            
            if(attributes.containsKey(name))
            {
                attributes.get(name).add(value);
            }
            else
            {
                 List<String> attributesList = new ArrayList<>();
                 attributesList.add(value);
                 attributes.put(name, attributesList);
            }
        }
    }
    
    public String getAttribute(String name)
    {
        if(name!=null ) 
        {
            if(attributes.containsKey(name) && !attributes.get(name).isEmpty())
            {
                return attributes.get(name).get(0);
            }
        }
        return null;
    }
    
    public void addAttribute(String name, List<String> value,boolean replace)
    {
      if(name!=null && value!=null)
      {
          if(replace && attributes.containsKey(name))
          {
                attributes.remove(name);
          }
          attributes.put(name, value);
      }
    }
    
    public void removeAttribute(String name)
    {}

   
   
    /*
     * This API is just to prevent some classes like BasicAppRoleEntry to implement this method as its
     * The ones who need to can override it 
     * */
    @Override
    void readExtendedVariables(Element node) 
    {
    }

}
