package ToolsQA;

import java.util.HashMap;
import java.util.Map;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


abstract class BasicInternalEntry 
{

    protected String _name = "";
    protected String _description = "";
    protected String _displayName = "";
    protected boolean isSeeded = false;
    
    protected BasicInternalEntry() 
    {
    }
    
    protected BasicInternalEntry(String name) 
    {
        _name = name;
    }

    protected BasicInternalEntry(String name, String displayName, String description) 
    {
        _name = name;
        _displayName = displayName;
        _description = description;
    }

    protected BasicInternalEntry(BasicInternalEntry entry) 
    {
        _name = entry._name;
        _displayName = entry._displayName;
        _description = entry._description;
    }
    
   
    abstract void readExtendedVariables(Element node);
    
    /**
     * {{@inheritDoc}}
     */
    //@Override
    public String getName()
    {
        return _name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param name
     */
    public void setName(String name)
    {
        _name = name;
    }

    /**
     * {{@inheritDoc}}
     */
    //@Override
    public String getDescription()
    {
        return _description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param description
     */
    public void setDescription(String description)
    {
        _description = description;
    }

    /**
     * {{@inheritDoc}}
     */
    //@Override
    public String getDisplayName()
    {
        return _displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param displayName
     */
    public void setDisplayName(String displayName)
    {
        _displayName = displayName;
    }
    
    public boolean isSeededMember()
    {
        return isSeeded;
    }
    
    public void setSeededMember(boolean seeded)
    {
        this.isSeeded = seeded;
    }
  
    
    @Override
    public String toString() 
    {
        StringBuilder str =  new StringBuilder( "Name=" + _name + "\t displayName=" + _displayName + "\t description=" + _description);
        return str.toString();
    }
    
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((_name == null) ? 0 : _name.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj)
    {
        if (obj == null || (obj.getClass() != this.getClass() && !obj.getClass().isAssignableFrom(this.getClass()) && !this.getClass().isAssignableFrom(obj.getClass())))
        {
            return false;
        }
        
        if (this == obj || this.getName().equalsIgnoreCase(((BasicInternalEntry)obj).getName()))
        {
            return true;
        }
        
        return false;
    }

  
    

}
