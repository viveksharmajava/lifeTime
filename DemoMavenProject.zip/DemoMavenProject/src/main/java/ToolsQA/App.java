package ToolsQA;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        Path path = Paths.get("c:\\vivek\\project");
        System.out.println("path "+path.toFile().getAbsolutePath());
        File f = new File("c:\\vivek\\systemuser");
        System.out.println(f.exists());
        
        System.out.println(File.pathSeparator);
        System.out.println(File.separator);
        f.mkdir();
        System.out.println(f.exists());
        try {
			Writer writer=  new FileWriter("c:\\vivek\\systemuser\\username",false);
			writer.write("BISystemUser");
			writer.close();

		    writer=  new FileWriter("c:\\vivek\\systemuser\\password",false);
			writer.write("welcome1");
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
       
    }
}
