package ToolsQA;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class GettingStarted {
 private static LinkedHashMap <String,String> map = new LinkedHashMap<>();
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("Hello Getting started");
	
		testGoogleSearch();
		//System.out.println(map);
		//Thread.sleep(5000);
		//sendToWhatsApp();
		Thread t1 = new Thread("BSE Crawler"){
			public void run(){
				//while(true){
					
					try {
						System.out.println("starting web-crawler");
						GettingStarted.testGoogleSearch();
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				//}
			}
		};
		
	//t1.start();
		Thread t2 = new Thread("Whatsapp Messanger"){
			public void run(){
				while(true){
					
					try {
						System.out.println("starting whatsapp");
						GettingStarted.sendToWhatsApp();
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
		};
		
		//t2.start();
		

	}
	public static  void testGoogleSearch() throws InterruptedException {     

		  // Optional. If not specified, WebDriver searches the PATH for chromedriver.      
		System.setProperty("webdriver.chrome.driver", "C:\\vivek\\software\\chromedriver-win64-146\\chromedriver-win64\\chromedriver.exe");          
		WebDriver driver = new ChromeDriver(); 

		  driver.get("https://www.bseindia.com/corporates/ann.html");    

		  Thread.sleep(3000);  // Let the user actually see something!     

		 
		  
		  WebElement searchBox = driver.findElement(By.name("period"));
		  searchBox.sendKeys("Company Update");    
		  Thread.sleep(2000);  // Let the user actually see something!  

		  
		  /*
Agreement
Allotment of Equity Shares
Award of Order / Receipt of Order
Buy back
Joint Venture
Open Offer
Sale of shares
Utilisation of Funds
Debt Securities
Credit Rating
Shareholding
		   */
		  ArrayList <String> companyUpdate_subCat = new ArrayList<>();
		  companyUpdate_subCat.add("Award of Order / Receipt of Order");
		  companyUpdate_subCat.add("Agreement");
		  companyUpdate_subCat.add("Buy back");
		  companyUpdate_subCat.add("Joint Venture");
		  companyUpdate_subCat.add("Sale of shares");
		  companyUpdate_subCat.add("Award of Order / Receipt of Order");
		  companyUpdate_subCat.add("Open Offer");
		  companyUpdate_subCat.add("Utilisation of Funds");
		  companyUpdate_subCat.add("Credit Rating");
		  companyUpdate_subCat.add("Shareholding");
		  
		  ArrayList <String> corpAction_subCat = new ArrayList<>();
		  corpAction_subCat.add("Amalgamation / Merger / Demerger");
		  corpAction_subCat.add("Bonus");
		  corpAction_subCat.add("Book Closure");
		  corpAction_subCat.add("Capital Reduction");
		  corpAction_subCat.add("Dividend");
		  corpAction_subCat.add("Record Date");
		  corpAction_subCat.add("Bonds / Right issue");
		  corpAction_subCat.add("Sub-division / Stock Split");
		  
		  ArrayList <String> result_subCat = new ArrayList<>();
		  result_subCat.add("Financial Results");
		  result_subCat.add("Limited Review Report");
		  result_subCat.add("Auditors Report");
		  
		  ArrayList <String> boardMeeting_subCat = new ArrayList<>();
		  boardMeeting_subCat.add("Board Meeting");
		  boardMeeting_subCat.add("Outcome of Board Meeting");
		  
		  HashSet <String> category = new HashSet <>();
		  
		  
		  
		 
		  HashMap <Integer,String> catMap  = new HashMap<>();
		  catMap.put(1, "Agreement");
		  catMap.put(2, "Allotment of Equity Shares");
		  catMap.put(3, "Award of Order / Receipt of Order");
		  catMap.put(4, "Buy back");
		  catMap.put(5, "Joint Venture");
		  catMap.put(6, "Open Offer");
		  catMap.put(7, "Sale of shares");
		  catMap.put(8, "Utilisation of Funds");
		  catMap.put(9, "Debt Securities");
		  catMap.put(10, "Credit Rating");
		  catMap.put(11,"Acquisition");
		  Thread.sleep(1000);  // Let the user actually see something!  
		  HashSet <String> set = new  HashSet<>();
		 Integer mi = 1;
		  while(mi <=11){ // keep checking every 30 seconds
			
		  WebElement subCat = driver.findElement(By.name("subcat"));
		  System.out.println("Category="+catMap.get(mi));
		  subCat.sendKeys(catMap.get(mi));//Acquisition
		  mi++;
		  if(mi > 11) mi = 1;
		  WebElement submit = driver.findElement(By.name("submit"));
		  submit.click();    
 
		  Thread.sleep(3000);  // Let the user actually see something!  
		  
		  /*
		  String pageSource = driver.getPageSource();
		  int start = -1;
		  start = pageSource.indexOf("<table cellpadding=\"4\" cellspacing=\"1\" width=\"100%\" ng-repeat=\"cann in CorpannData.Table\"");
		  if(start > 0 ){
			  String resultTable = pageSource.substring(start,pageSource.indexOf("</table>", start));
			  System.out.println(resultTable);
			  String [] rows = resultTable.split("<tr>");
			  System.out.println("rows = "+rows.length);
			  for(int i = 0 ; i < rows.length ; i++){
				
				 // System.out.println(rows[i]);
				 String row = rows[i];
				 String []colums = row.split("<td>");
				 for(int j=0; j < colums.length; j++){
					
					// System.out.println(j +" = "+ colums[j]);
					 
					
						// int s_ind  = "<td class=\"tdcolumngrey\" width=\"70%\" style=\"font-weight:bold;\" valign=\"middle\"><span ng-bind-html=\"cann.NEWSSUB\" class=\"ng-binding\">";
						 String description = colums[j].substring(135);
						 System.out.println("description ="+description);
					  if (j == 3){
						 int link_index = colums[j].indexOf("<a class=\"tablebluelink\" href=\"")+( new String("<a class=\"tablebluelink\" href=\"").length());
					      String link = colums[j].substring(link_index,colums[j].lastIndexOf(".pdf")+4);
					      System.out.println("link = "+link);
					 }
					 
					 
				 }
			  }
		  }
		  */
		
		  List<WebElement> resultsDiv = driver.findElements(By.className("tdcolumngrey"));//("//table[contains (@ng-repeat,'cann in CorpannData.Table')//tbody"));

	       // System.out.println("resultsDiv ="+resultsDiv.size());
		  String mapKey = "";
		  map = new LinkedHashMap<>();
		  for (int i=0; i<resultsDiv.size(); i++) {
	           try{
	        	WebElement span = resultsDiv.get(i).findElement(By.className("ng-binding"));
	        	String org = "";
	        	
	        	////if((i+1)%4 == 1){
	        	if(!span.getText().contains("MB")){
	        		//System.out.println(span.getText());
	        	    org = 	span.getText() ;
	        	    //////if(set.contains(org))break;
	        	  //  set.add(org);
	        	    map.put(org,org);
	        	    mapKey = org;
	        	}
	        	//}
	        	
	        		WebElement pdf_link = 	 resultsDiv.get(i).findElement(By.className("tablebluelink"));
	        		String link = pdf_link.getAttribute("href");
	        		//System.out.println(" link ="+link);
	        		map.put(mapKey,link);
	        		
	           }catch(Exception e){
	        	  // System.out.println(e.getMessage());
	           }
	            
	        }
	       if(map.size() > 0 ){
	    	   System.out.println(map);
	       }else{
	    	//   System.out.println("Nothing new to print !");
	       }
		  Thread.sleep(2000);
		}
		
		//  driver.quit();  
		 
		 } 
	
	//
	public static  void sendToWhatsApp() throws InterruptedException {     

		  // Optional. If not specified, WebDriver searches the PATH for chromedriver.      
		System.setProperty("webdriver.chrome.driver", "C:\\vivek\\software\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");          
		ChromeOptions options = new ChromeOptions();
		options.addArguments("user-data-dir=C:\\Users\\Vivek\\AppData\\Local\\Google\\Chrome\\User Data");
		WebDriver driver = new ChromeDriver(options); 
		
		 driver.get("https://web.whatsapp.com/send?phone=7204767308&text&type=phone_number&app_absent=1");    

		  Thread.sleep(10000);  // Let the user actually see something!     
   //     String xpath_str = "//div[contains(@title,\"Type a message\")]";
		  String xpath_str = "//*[@id=\"whatsapp-web\"]/footer/div[1]/div/span[2]/div/div[2]/div[1]/div/div[1]";
		  WebElement searchBox = driver.findElement(By.xpath(xpath_str));
		  Thread.sleep(1000);  // Let the user actually see something!  

		  searchBox.sendKeys("This is Selenium message for you !");    
		  searchBox.sendKeys(Keys.ENTER);
		  Thread.sleep(2000);  // Let the user actually see something!  

		  /*
		  String pageSource = driver.getPageSource();
		  int start = -1;
		  start = pageSource.indexOf("<table cellpadding=\"4\" cellspacing=\"1\" width=\"100%\" ng-repeat=\"cann in CorpannData.Table\"");
		  if(start > 0 ){
			  String resultTable = pageSource.substring(start,pageSource.indexOf("</table>", start));
			  System.out.println(resultTable);
			  String [] rows = resultTable.split("<tr>");
			  System.out.println("rows = "+rows.length);
			  for(int i = 0 ; i < rows.length ; i++){
				
				 // System.out.println(rows[i]);
				 String row = rows[i];
				 String []colums = row.split("<td>");
				 for(int j=0; j < colums.length; j++){
					
					// System.out.println(j +" = "+ colums[j]);
					 
					
						// int s_ind  = "<td class=\"tdcolumngrey\" width=\"70%\" style=\"font-weight:bold;\" valign=\"middle\"><span ng-bind-html=\"cann.NEWSSUB\" class=\"ng-binding\">";
						 String description = colums[j].substring(135);
						 System.out.println("description ="+description);
					  if (j == 3){
						 int link_index = colums[j].indexOf("<a class=\"tablebluelink\" href=\"")+( new String("<a class=\"tablebluelink\" href=\"").length());
					      String link = colums[j].substring(link_index,colums[j].lastIndexOf(".pdf")+4);
					      System.out.println("link = "+link);
					 }
					 
					 
				 }
			  }
		  }
		  */
		
		
	      
	        

		//  driver.quit();  

		 } 
}
