package ToolsQA;

import java.util.HashSet;

public class Test2 {
    private String s= "Test2";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test2 t1 = new Test2();
		Test2 t2 = new Test2();
		
		HashSet<Test2> set = new HashSet<>();
		set.add(t1);
		set.add(t2);
		Test2 t3 = new Test2();
		if(set.contains(t3)){
			System.out.println("contains");
		}
		

	}
   
	@Override
	public int hashCode(){
		int result =  super.hashCode() + this.s.hashCode();
		return result;
	}
	
	public boolean equals(Object obj){
		Test2 other = (Test2)obj;
		if(this == other) return true;
		if((s == null && other.s == null) || (this.s.equals(other.s))) return true;
		
		return false;
	}
}
