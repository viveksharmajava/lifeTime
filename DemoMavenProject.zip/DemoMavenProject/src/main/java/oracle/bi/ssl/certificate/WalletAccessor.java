package oracle.bi.ssl.certificate;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.logging.Logger;

import javax.security.auth.x500.X500Principal;

import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;
import oracle.security.pki.OracleWallet;

import org.apache.commons.io.IOUtils;

/**
 * Create identity certificate in Oracle Wallet. 
 * 
 * Wallet api is documented at https://stbeehive.oracle.com/teamcollab/library/st/SSL+Toolkit/Documents/Oracle+Wallet+Javadocs/FMW+12.2.1+Draft
 */
public final class WalletAccessor {
    private final static Logger logger = LoggerFactory.createLogger(WalletAccessor.class);
    
    private final OracleWallet wallet;
       
    private final File sslTempDir;
    
    
    /**
     * Create a wallet 
     */
    public WalletAccessor(File sslTempDir, Passphrase walletPassphrase) throws SSLException {
        if( sslTempDir == null){
            throw new IllegalArgumentException("Null sslTempDir");
        }
        this.sslTempDir = sslTempDir;
        wallet = new OracleWallet();
        try {
            wallet.create(walletPassphrase.getPassphraseChars());
            logger.info("Created wallet");
        } catch (IOException e) {
            throw new SSLException("Unable to create wallet", e);
        }
    }
    
    /** 
     * Save the wallet.  There should be a separate walletDir per wallet.  
     * This creates walletDir, and creates a .p12 and .lck file in that directory.
     * You can call save multiple times - it will just overwrite. 
     * @param walletDir
     * @throws SSLException
     */
    public void save(File walletDir) throws SSLException{
        try {
            wallet.saveAs(walletDir.getAbsolutePath());
            logger.info("Saved wallet to directory " + walletDir.getAbsolutePath());
        } catch (IOException e) {
            throw new SSLException("Unable to save wallet to directory " + walletDir.getAbsolutePath(), e);
        }
    }
    
    /**
     * Add a trust (CA) certificate. 
     * @param pemFile
     * @throws SSLException
     */
    public void addTrustCertificate(File pemFile) throws SSLException {
        addCertificate(pemFile, true);
    }
        
    /**
     * Add a CA (trust) certificate (trustPoint = true) or the signed certificate resulting from an exported 
     * certificate signing request (trustPoint = false) 
     * @param pemFile
     * @param trustPoint
     */
    private void addCertificate(File pemFile, final boolean trustPoint) throws SSLException {
        if( pemFile == null){
            throw new IllegalArgumentException("null pemFile");
        }
        if( !pemFile.exists()){
            throw new IllegalArgumentException("pemFile " + pemFile.getAbsolutePath() + " does not exist");
        }
        
        // importCert uses reset on its InputStream.   This is not supported on FileInputStreams, resulting in 
        // an IOException hidden behind an un-informative certificate incorrect exception.  So copy into a 
        // byte array input stream. 
        
        try ( InputStream is = new FileInputStream(pemFile)){
            final ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
            int i;
            while( (i = is.read()) != -1){
                bytearrayoutputstream.write(i);
            }
            
            
            wallet.importCert(new ByteArrayInputStream(bytearrayoutputstream.toByteArray()), trustPoint);
            logger.info("Imported certificate from file " + pemFile.getAbsolutePath() + " into wallet");
            
        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | CertificateException e){
            throw new SSLException("Unable to import CA certificate from " + pemFile.getAbsolutePath() + " into wallet", e);
        }
    }
    
    
    /**
     * Create identity within the wallet.  As with Java keystore the standard approach is to create the key in the keystore, export a signing request, 
     * sign, and then import back.  This avoids any need - which may not even be supported by the api - to move the security sensitive key 
     * from one keystore to another.  So long as all the identities in the various keystores (JKS, Oracle Wallet, openssl certificate files) 
     * are signed by the same CA clients don't care.  Currently we do not support Certifate Extensions such as subject alternate names. 
     * @param dn distinguished name
     * @param ca certificate authority which will sign the identity.  It trust certificate must already have been added to the 
     * wallet using addTrustCertificate
     */
    public void createIdentity(DistinguishedName dn, CertificateAuthority ca) throws SSLException{
        final X500Principal subjectDN = dn.toX500Principal();
        // Only specific key sizes are supported. See documentation for orakpi command line tool. 
        final int keysize = 2048;
        try {
            wallet.addCertRequest(subjectDN, keysize);
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e) {
            throw new SSLException("Unable to create new identity for " + dn.getCommonName(), e);
        }
        
        final File tempCertRequest = SSLFileUtils.unusedFile(sslTempDir, "walletcertreq.txt");
        
        try (final InputStream  is = wallet.exportCertReq(subjectDN);
             final OutputStream os = new FileOutputStream(tempCertRequest)){
            IOUtils.copy(is,  os);
        } catch (UnrecoverableKeyException | KeyStoreException
                | NoSuchAlgorithmException | IOException e) {
            throw new SSLException("Unable to export certificate signing request for " + dn.getCommonName());
        };
        
        final File tempSignedCertificate = SSLFileUtils.unusedFile(sslTempDir, "walletsignedCert.pem");
        // Currently we do not support optional certificate extensions such as subject alternate names for waller
        ca.signCertificate(tempCertRequest,  new CertificateExtensions(), tempSignedCertificate);
        
        final boolean isCA = false;
        addCertificate(tempSignedCertificate, isCA);
    }
}
