package oracle.bi.ssl.locations;

import java.io.File;

import oracle.bi.ssl.pub.SSLException;


/**
 * Defines locations of Oracle Wallets.   Each wallet is a directory, within which is a .p12 and .p12.lck file. 
 */
public final class WalletLocations {



   
    
    /**
     * Directory holding all wallets directories 
     */
    private final File walletsHomeDir;

    
    /**
     * Server wallet containing internal identity (signed by internal CA) plus trust. 
     */
    private final File serverWalletDir;

    
    
    /**
     * Constructor.  
     */
    public WalletLocations(DomainLocations domainLocations) throws SSLException
    {
        
        final File sslConfigDir = domainLocations.getSSLConfigDir();
        walletsHomeDir = new File(sslConfigDir, "wallets");
        serverWalletDir = new File(walletsHomeDir, "internalWallet");
    }


    /**
     * Directory containing individual wallet directories.  
     * @return
     */
    public File getWalletsHomeDir() {
        return walletsHomeDir;
    }


    /**
     * Internal identity certificate signed by the internal CA, plus the corresponding trust chain. 
     * @return
     */
    public File getServerWalletDir() {
        return serverWalletDir;
    }

    
}