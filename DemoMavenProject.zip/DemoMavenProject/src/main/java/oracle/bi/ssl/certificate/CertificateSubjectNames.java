package oracle.bi.ssl.certificate;

import java.security.cert.CertificateException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;

import oracle.bi.ssl.ping.java.CNException;
import oracle.bi.ssl.pub.SSLException;

/**
 * Parse out subject name from the various subject names fields in an X509 certificate
 * 
 *
 */
public final class CertificateSubjectNames {
    
    
    private final static Integer DNS = Integer.valueOf(2);
    
    /**
     * Note this is the more recent java.security.cert, not javax.security.cert (note the x) which does not support 
     * access to Subject Alternative Name
     */
    private final X509Certificate certificate;

    public CertificateSubjectNames(X509Certificate certificate) {
        this.certificate = Objects.requireNonNull(certificate);
    }
    
    /**
     * The common name (CN) is part of the distinguished name (DN).  Historically it was used to perform the certificate host name 
     * check, to prevent person in the middle attacks.  That role is now superceded by Subject Alternative Names. 
     * @return
     * @throws SSLException
     */
    public String getCommonName() throws SSLException{
        final String dn = certificate.getSubjectX500Principal().getName();
        final LdapName ldapDN;
        try {
            ldapDN = new LdapName(dn);
        } catch (InvalidNameException e) {
            throw new SSLException("DN '" + dn +"' not a valid distinguished name", e);
        }
        
        for(Rdn rdn: ldapDN.getRdns()) {
            if( "CN".equals( rdn.getType()) ){
                final Object cn = rdn.getValue();
                if( cn instanceof String){
                    return (String)cn;
                } else {
                    throw new SSLException("CN in " + dn + " of type " + cn.getClass() + " not of type String");
                }
            }
            
        }
        throw new SSLException("No CN in " + dn );
        
    }
    
    /**
     * This is used for debugging, in particular dumping out unexpected SAN values.  So unlike the check code it is forgiving, 
     * falling through from expected cases and printing whatever it finds. 
     * @return textual representation of the subject alternative names.
     */
    public String getSANSummary(){
        final Collection<List<?>> subjectAlternativeNames;
        try {
            subjectAlternativeNames = this.certificate.getSubjectAlternativeNames();
        } catch (CertificateParsingException e) {
            return "Bad cert " + e.getMessage();
        }
        
        final StringBuilder buff = new StringBuilder();
        if( subjectAlternativeNames == null){
            buff.append("NONE");
        } else {
            // see https://docs.oracle.com/javase/7/docs/api/java/security/cert/X509Certificate.html#getSubjectAlternativeNames()
            int count = 0;
            for( List<?> subjectAlternativeName : subjectAlternativeNames){
                if( count > 0){
                    buff.append(", ");
                }
                // Expect length 2, first integer encoding, second value
                int fieldIndex = 0;
                for( Object element : subjectAlternativeName){
                    // Print Human readable for the type field only. 
                    if( fieldIndex > 0 ){
                        buff.append(" ");
                    }
                    if( fieldIndex == 0 && DNS.equals(element) ){
                        buff.append("DNS");
                    } else {
                        buff.append(element );
                    } 
                    fieldIndex++;
                }
                count++;
            }
        }
        return buff.toString();
    }
    
    /**
     * Check if subject alternative names or if none given common name matches hostName.
     * Currently the following are not supported:
     * <ul>
     * <li>wildcard names.  An implementation must be very careful not to allow a maliciously formatted SAN entry to match 
     * more cases than the standard prescribes.    </li>
     * <li>name types other than DNS names </li>
     * </ul>
     * More recent SSL stacks do the full subject name checks for us, but older stacks (eg the FIPS 140 stack) do not. 
     */
    public void checkSubjectNames(String hostName) throws CertificateException {
        
        final Collection<List<?>> subjectAlternativeNames = this.certificate.getSubjectAlternativeNames();
        if( subjectAlternativeNames == null){
            // Fall back on common name only if no SAN - if SAN is present CN should not be considered. 
            checkCommonName(hostName);
        } else {
            checkSubjectAlternativeNames(subjectAlternativeNames, hostName);
        }
    }
    
    /**
     * Check only the Subject Alternative Names.  Does not support wildcards. 
     * @param subjectAlternativeNames
     * @param hostName
     * @throws CertificateException
     */
    private void checkSubjectAlternativeNames(final Collection<List<?>> subjectAlternativeNames, String hostName) throws CertificateException{
        
        // see https://docs.oracle.com/javase/7/docs/api/java/security/cert/X509Certificate.html#getSubjectAlternativeNames()
        int index = 0;
        final List<String> dnsEntries = new ArrayList<>();
        for( List<?> subjectAlternativeName : subjectAlternativeNames){
            
            // Expect length 2, first integer encoding, second value
            if( subjectAlternativeName.size() != 2){
                throw new CertificateException(
                            "Subject alternative names '" + getSANSummary() + "' entry: " + index + " has unexpected length: " + subjectAlternativeName.size());
            } else {
                final Object type = subjectAlternativeName.get(0);
                if( DNS.equals(type) ){
                    final Object value = subjectAlternativeName.get(1);
                    if( value instanceof String){
                        final String dnsName = (String)value;
                        if( dnsName.contains("*")){
                            throw new CertificateException(
                                "Subject alternative names '" + getSANSummary() + "' DNS entry: " + index + " has unsupported wildcard value: " + dnsName);
                        }
                        if( hostName.equals(dnsName)){
                            // Got a match. 
                            return;
                        }
                        dnsEntries.add(dnsName);
                    } else {
                        throw new CertificateException(
                                "Subject alternative names '" + getSANSummary() + "' DNS entry: " + index + " has non string value: " + value); 
                    }
                } else {
                    throw new CertificateException(
                            "Subject alternative names '" + getSANSummary() + "' entry: " + index + " has unsupported type: " + type); 
                }
                
            } 
            
        }
        throw new CertificateException(
                "No match for '" + hostName + "' in subject alternative names '" + getSANSummary() + "' DNS entries: " + dnsEntries); 
    }
    
    /**
     * Check just the common name field
     * @param allowedHost
     * @throws CertificateException
     */
    private void checkCommonName(String allowedHost) throws CertificateException {
        final String cn;
        try {
            cn = getCommonName();
        } catch (SSLException e) {
            throw new CertificateException("Unable to read common name from " + certificate.getSubjectDN().getName(), e);
        }

        if( !allowedHost.equals(cn)){
            throw new CNException(this.certificate, cn, allowedHost);
        }
    }
}
