package oracle.bi.ssl.logging;

/**
 * Controls whether we should echo to std out in addition to logging on completion.  
 * Echoing to stdout allows a command line tool to give much more timely indication of progress. 
 * However may not be appropriate for commands running within a tool, where the log file is sufficient. 
 */
public enum EchoMode {NO_ECHO, ECHO_INFO_TO_STD_OUT, ECHO_ALL_TO_STD_OUT};