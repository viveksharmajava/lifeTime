package oracle.bi.ssl.ping.java;


import java.security.cert.Certificate;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;

import oracle.bi.ssl.resources.SSLMsgId;
import oracle.bi.ssl.resources.SSLMsgResource;







/**
 * Contains result of running an ssl ping
 */
public abstract class JavaPingResult
{
   public enum JavaSSLState { 
      // Succeeded in connecting.  Exception will be null. 
      SSL_OK(SSLMsgId.SSL_OK), 
      
      // Probably ssl is not on in server, but server is listening.  This is a security hole. 
      // Exception will be timed out exception. 
      SSL_OFF(SSLMsgId.SSL_OFF),
      
      // handshake failed - certificates not trusted, hostname did not match certificate Subject Alternate Name, or server closed down connection
      // The precise cause is given by the nested exception.  We cannot distingusih the cases since the exact exception/exception text may vary by
      // SSL provider. 
      SSL_BAD_HANDSHAKE(SSLMsgId.SSL_BAD_HANDSHAKE),
            
      
      
      // Connection failed, either due to wrong ssl parameters or server not running. 
      // exception will hold underlying cause. 
      CONNECT_FAILURE(SSLMsgId.CONNECT_FAILURE),
      
      // A runtime exception not related to ssl protocol issues
      UNEXPECTED_FAILURE(SSLMsgId.UNEXPECTED_FAILURE);
      
      private final String msgId;
      
      private JavaSSLState(String msgId){
          this.msgId = msgId;
      }
      public String getMessage(){
          return SSLMsgResource.getMessage(msgId);
      }
   };
   
   

   private final JavaSSLState _sslState;
   
   protected JavaPingResult(JavaSSLState sslState){
       _sslState = sslState;
   }
   
   public final JavaSSLState getSSLState()
   {
      return _sslState;
   }
   
   /**
    * Short
    */
   public abstract String getSummary();
   
   
   /**
    * Override in derived class if more than the summary is available. 
    */
   @Override
   public String toString() {
       return getSummary();
   }
   
   /**
    * Return a string summarizing the ssl session
    */
   protected static String sessionSummary(SSLSession sslSession)
   {
      final StringBuilder detailBuilder = new StringBuilder();
      
      
      detailBuilder.append(" peer: " );
      detailBuilder.append(sslSession.getPeerHost());
      
      detailBuilder.append(":");
      detailBuilder.append(sslSession.getPeerPort());
      
      detailBuilder.append(" protocol: ");
      detailBuilder.append(sslSession.getProtocol());
      
      detailBuilder.append(" cipher suite: " );
      detailBuilder.append(sslSession.getCipherSuite());
      
      detailBuilder.append("\n local certificates:\n" );
      certificatesSummary( detailBuilder, sslSession.getLocalCertificates());
      
      
      
      
      try{      
         detailBuilder.append("\n peer certificates:\n" );
         certificatesSummary( detailBuilder, sslSession.getPeerCertificates());
         
      }
      catch (SSLPeerUnverifiedException e)
      {
         detailBuilder.append(" peer not verified");
      }
      
      
      return detailBuilder.toString();
      
   }
   
   
   /**
    * Dump summary information about certificates
    */
   private static void certificatesSummary( StringBuilder detailBuilder, Certificate[] certs)
   {
      if( certs == null )
      {
         detailBuilder.append("    null ");
      }
      else
      {
         
         for( Certificate certificate : certs)
         {
            
            if( certificate instanceof X509Certificate)
            {
               final X509Certificate x509Certificate = (X509Certificate)certificate;
               detailBuilder.append("   #");
               detailBuilder.append( x509Certificate.getSerialNumber() );
               detailBuilder.append( ", expires: " );
               detailBuilder.append( x509Certificate.getNotAfter() );
               detailBuilder.append( " subject: \"" );
               detailBuilder.append( x509Certificate.getSubjectDN() );
               detailBuilder.append( "\" issuer: \"" );
               detailBuilder.append( x509Certificate.getIssuerDN() );
               detailBuilder.append( "\"");
               if( x509Certificate.getSubjectDN().equals(x509Certificate.getIssuerDN() )){
                   detailBuilder.append(" (Self signed - root)");
               }
               detailBuilder.append("\n");
            }
            else
            {
               // Potentially ugly detail.  
               detailBuilder.append( certificate.toString() );
            }
         }
      }
   }

   
}
