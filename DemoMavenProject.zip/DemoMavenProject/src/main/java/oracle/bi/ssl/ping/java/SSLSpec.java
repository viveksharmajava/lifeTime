package oracle.bi.ssl.ping.java;

import java.security.KeyStoreException;
import java.util.Objects;

import javax.net.ssl.SSLContext;

import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.config.HostVerification;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLContextFactory;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.pub.SSLAlgorithms;
import oracle.bi.ssl.pub.SSLException;

/**
 * Defines SSL environment - trust, identity etc
 * 
 *
 */
public final class SSLSpec {
    private final KeyStoreType keyStoreType;
    private final SSLAlgorithms sslAlgorithms;
    private final KeyStoreAccessor identityKeyStore;
    private final String identityAlias;
    private final Passphrase identityKeystorePassphrase;
    private final Passphrase identityKeyPassphrase;
    private final KeyStoreAccessor trustKeyStore;
    private final HostVerification hostnameVerification;
    
    public SSLSpec(
            KeyStoreType keyStoreType,
            SSLAlgorithms sslAlgorithms,
            HostVerification hostnameVerification,
            KeyStoreAccessor identityKeyStore,
            String identityAlias,
            Passphrase identityKeystorePassphrase,
            Passphrase identityKeyPassphrase,
            KeyStoreAccessor trustKeyStore
            ){
        this.keyStoreType = Objects.requireNonNull(keyStoreType, "null keyStoreType");
        this.sslAlgorithms = Objects.requireNonNull(sslAlgorithms, "null sslAlgorithims");
        this.hostnameVerification = Objects.requireNonNull(hostnameVerification, "null hostnameVerification");
        this.identityKeyStore = Objects.requireNonNull(identityKeyStore, "null identityKeyStore");
        this.identityAlias = Objects.requireNonNull(identityAlias, "null identityAlias");
        this.identityKeystorePassphrase = Objects.requireNonNull(identityKeystorePassphrase, "null identityKeystorePassphrase");
        this.identityKeyPassphrase = Objects.requireNonNull(identityKeyPassphrase, "null identityKeyPassphrase");
        this.trustKeyStore = Objects.requireNonNull(trustKeyStore, "null trustKeyStore");
        
        try {
            if( !identityKeyStore.getKeyStore().isKeyEntry(identityAlias) ){
                // For testing this is legal - we want to test no identity.  Just warn.
                System.out.println("Identity keystore does not contain alias: " + identityAlias);
            }
            
            
        } catch (KeyStoreException e) {
            throw new IllegalArgumentException("Identity Keystore not accessible", e);
        }
    }
    

    public KeyStoreType getKeyStoreType() {
        return keyStoreType;
    }


    public SSLAlgorithms getSslAlgorithms() {
        return sslAlgorithms;
    }

    public KeyStoreAccessor getIdentityKeyStore() {
        return identityKeyStore;
    }

    public String getIdentityAlias() {
        return identityAlias;
    }

    public Passphrase getIdentityKeystorePassphrase() {
        return identityKeystorePassphrase;
    }

    public Passphrase getIdentityKeyPassphrase() {
        return identityKeyPassphrase;
    }

    public KeyStoreAccessor getTrustKeyStore() {
        return trustKeyStore;
    }

    public HostVerification getHostnameVerification() {
        return hostnameVerification;
    }
    
    /**
     * Depending on the security providers installed (eg FIPS vs default JDK) the hostname verification 
     * checks may need to use hostname stored in the SSLContext.  Therefore SSLContexts should be considered 
     * specific to one hostname.  Do not share between multiple targets with different hostname. 
     */
    public SSLContext getSSLContext(String hostname) throws SSLException{
        final SSLContext ctx = SSLContextFactory.getSSLContext(
                hostname,
                sslAlgorithms.getProtocols(),
                keyStoreType,
                hostnameVerification, 
                identityKeyStore,
                identityAlias,
                identityKeystorePassphrase,
                identityKeyPassphrase,
                trustKeyStore);
        return ctx;
    }
}
