package oracle.bi.ssl.certificate;

import java.io.File;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import oracle.bi.endpointmanager.pub.EndpointManager;
import oracle.bi.endpointmanager.pub.RegisteredEndpoint;
import oracle.bi.endpointmanager.pub.RegisteredEndpointList;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.config.SingleIdentityKeyStoreFactory;
import oracle.bi.ssl.files.AutoDeletingTempDir;
import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.jps.KeyStoreServiceAccessor;
import oracle.bi.ssl.locations.CertificateLocations;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.locations.KeystoreNames;
import oracle.bi.ssl.logging.EchoMode;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.logging.OnCompletionExecLogger;
import oracle.bi.ssl.openssl.OpensslCommands;
import oracle.bi.ssl.pub.CertOptions;
import oracle.bi.ssl.pub.SANOption;
import oracle.bi.ssl.pub.SSLException;



/**
 * Supports construction and storage of the certificates created for components using Java KeyStore certificates.
 * Also querying existing java certificates. 
 *  
 */
public final class JavaIdentityFactory
{
    private final static Logger logger = LoggerFactory.createLogger(JavaIdentityFactory.class);
    
    private final OpensslCommands opensslCommands;
    
    private final KeyStoreServiceAccessor keyStoreServiceAccessor;
    private final CertificateLocations certificateLocations;
    private final SSLEnvironment sslEnvironment;
    /** Where in JPS keystore service to store our JKS keystores
     * 
     */
    private final String stripe;
    private final ExecLogger execLogger;
    private final EndpointManager endpointManager;
    
    // Common name used for the internal CA certificate.  Includes the phrase 'Certificate Authority' since that makes 
    // understanding certificate chains in the output of openssl s_client -connect much easier. 
    final static String INTERNAL_CN = "OBIEE Internal Certificate Authority";
   
    
    
    /**
     * Allow stripe to be chosen.  If stripe is null default is used 
     */
    public JavaIdentityFactory(
            SSLEnvironment sslEnvironment,
            EndpointManager endpointManager) throws SSLException{    
        this.sslEnvironment = Objects.requireNonNull(sslEnvironment, "null sslEnvironment");
        this.endpointManager = Objects.requireNonNull(endpointManager, "null endpointManager");
        
        final Homes homes = this.sslEnvironment.getHomes();
        this.keyStoreServiceAccessor = new KeyStoreServiceAccessor(homes.getDomainLocations());
        this.certificateLocations = new CertificateLocations(homes.getDomainLocations());
        execLogger = new OnCompletionExecLogger(logger, EchoMode.NO_ECHO);
        opensslCommands = sslEnvironment.getOpensslCommands(homes.getDomainLocations().getSSLCommandDir(), execLogger);
        
        
        final String requestedStripe = sslEnvironment.getConfigWrapper().getStripe();
        if( requestedStripe == null){
            this.stripe = this.certificateLocations.getKeyStoreNames().getDefaultBiStripe();
        } else {
            this.stripe = requestedStripe;
        }
    }
    
    void cleanKeyStores(Passphrase passphrase) throws SSLException{
        logger.info("Deleting old bi internal keystores");
        keyStoreServiceAccessor.deleteBIInternalKeyStores(passphrase, stripe);
    }
    
    
    /**
     * We have seen cases where consumer gets corrupt password errors.  So check one at time of creation.     
     */
    void checkKeyStores(Passphrase sslPassphrase, KeyStoreType keyStoreType) throws SSLException{        
        try {
            
            final KeyStoreAccessor biIdentityKeyStore = this.sslEnvironment.getConfigWrapper().getBIIdentityKeyStoreAccessor();
            final KeystoreNames keyStoreNames = certificateLocations.getKeyStoreNames();
            final String alias = keyStoreNames.getServerIdentityAlias();
            final KeyStore singleEntryKeyStore =  
                    SingleIdentityKeyStoreFactory.createSingleIdentityKeyStore(
                            biIdentityKeyStore, keyStoreType, alias, sslPassphrase, sslPassphrase);
            if( singleEntryKeyStore.getCertificate(alias) == null){
                throw new SSLException("Alias " + alias + " not found");
            }
        } catch (Exception e) {
            // Some suggestion that problem is due to the chars in passphrase.  If failed here passphrase is not security sensitive. 
            throw new SSLException("Unable to read identity keystore immediately after creating it due to " + e.getMessage() + 
                    " with passphrase '" + new String(sslPassphrase.getPassphraseChars()) + "'", e);
        }
    }
    
    
    
    

    
    /**
     * Create any missing listener certificates, to allow for additional listeners.   
     * @param passphrases
     * @return
     * @throws SSLException
     */
    public List<DistinguishedName> topUpListenerCertificates(Passphrase caPassphrase, Passphrase sslPassphrase) throws SSLException {  
        final Homes homes = this.sslEnvironment.getHomes();
        
        // sslTmpDir is shared - cannot assume can delete it all. 
        final File sslTmpDir = homes.getDomainLocations().getTmpSSL();
        final File caDir = this.certificateLocations.getOpensslCertificateLocations().getInternalCADir();
        // Create a temp directory to hold our temp files so we can delete at end of try with resources block
        final int expiryDays = getExistingExpiry(sslPassphrase);
        try( final AutoDeletingTempDir certsTempDir = new AutoDeletingTempDir(sslTmpDir, "certs");){
            final CertificateAuthority privateCA = 
                    CertificateAuthority.reopenCA(
                            this.sslEnvironment, 
                            caDir,
                            execLogger, 
                            caPassphrase,
                            expiryDays);
            final SANOption sanOption;
            // The cert options file stores the certificate options used in the previous call to ssl.[sh] regenerate.  Regenerate
            // creates the certificates, either by from the config assistant or from the command line if the config assistant is not used.
            // If the file does not exist the certificates must have been generated in an older version of Oracle Analytics
            // before the sanOption and hence the cert properties file.  In that case just default.
            final File certOptionsFile = homes.getDomainLocations().getSSLCertOptions();
            if( !certOptionsFile.exists() ){
                // Do not use SANOption.getDefaultSANOption() - we want the default prior to addition of this feature, not the 
                // default now - which may change over time. 
                sanOption = SANOption.USE_COMMON_NAME;
                logger.info(
                        "No cert options at " + certOptionsFile.getAbsolutePath() +
                        ", certificates generated by earlier Oracle Analytics version which only supported common name");
            } else {
                final CertOptions certOptions;
                try {
                    certOptions = CertOptionsStore.readCertOptions(homes.getDomainLocations().getSSLCertOptions());
                } catch (IOException e) {
                    throw new SSLException("Unable to read cert options", e);
                }
                sanOption = certOptions.getSanOption();
                logger.info("Topping up listener certificates, using previous option: " + sanOption);
            }
            return createIdentityCertificatesForListenerAddresses(
                certsTempDir.getDir(),
                sanOption,
                sslPassphrase,
                sslPassphrase,
                privateCA);
        }
    }

    void addJavaInternalTrust(Passphrase keystorePassphrase, CertificateAuthority ca) throws SSLException {
        // Store in a dedicated trust store used just for trusting internal components. 
        final KeyStoreAccessor biTrustKeyStore = this.keyStoreServiceAccessor.getBIInternalTrustKeyStore(keystorePassphrase, stripe);
        
        final KeystoreNames keystoreNames = certificateLocations.getKeyStoreNames();        
        biTrustKeyStore.loadX509(ca.getCACertificate(), keystoreNames.getInternalCACertificateAlias() );
        
        // Store in the domain trust store.  This ensures that WebLogic will trust internal CA when using system/trust in case user selects that trust keystore. 
        // Only used if WebLogic has 'two way ssl' set (ie verify clients). 
        // If two way ssl is set WebLogic will check identity certificate of incoming calls from clients, for example calls to the BI Security Service.
        {
            final KeyStoreAccessor domainTrustKeyStore = this.keyStoreServiceAccessor.getDomainTrustKeyStore();
            domainTrustKeyStore.loadX509(ca.getCACertificate(), keystoreNames.getInternalCACertificateAlias() );
        }
        
        {
            // Do the same for the system/publiccacerts trust store so that if the customer changes trust to publiccacerts (eg to access 
            // a remote in the cloud oracle analytics system secured by a public CA) the two way still works.   Currently this is the default trust we set when creating custom channels. 
            final KeyStoreAccessor cacertsTrustKeyStore = this.keyStoreServiceAccessor.getSystemPubliccacertsKeyStore();
            // Although it is a standard trust store, customer could have deleted it
            if( cacertsTrustKeyStore != null){
                cacertsTrustKeyStore.loadX509(ca.getCACertificate(), keystoreNames.getInternalCACertificateAlias() );
            }
        }
    }

    /**
     * Create identity certificates for every managed WebLogic listener address.  We get the addresses from the endpoint manager, using the BI-SECURITY-SOAP 
     * endpoint as an example endpoint since that application is deployed to every managed WebLogic server. 
     * @param sslTempDir
     * @param keyPassphrase
     * @param keyStorePassphrase
     * @param ca
     * @return common names of created certificates
     * @throws SSLException
     */
    List<DistinguishedName> createIdentityCertificatesForListenerAddresses(
            File sslTempDir, 
            SANOption sanOption,
            Passphrase keyPassphrase, 
            Passphrase keyStorePassphrase, 
            CertificateAuthority ca) throws SSLException{
        
        final List<DistinguishedName> subjects = new ArrayList<>();
        
        final RegisteredEndpointList endpointList = endpointManager.getRegisteredEndpointsByComponentType("BI-SECURITY-SOAP");
        if( endpointList.getEndpoints().isEmpty()){
            throw new SSLException("No managed server endpoints to create certificates for");
        }
        
        
        
        // Create separate certificate for each different CN.  In a scaled out system each managed server can be 
        // configured to use a certificate matching it.  Endpoints may share the same address.
        final Set<String> uniquelListenerAddresses = new HashSet<String>();
        for(RegisteredEndpoint endpoint : endpointList.getEndpoints()){
            logger.info("Checking certificate exists for endpoint: " + endpoint);
            System.out.println("Checking certificate exists for endpoint: " + endpoint);
            uniquelListenerAddresses.add( EndpointHelper.getEffectiveClientListenAddress(endpoint));            
        }        
        
        for( String listenerAddress : uniquelListenerAddresses){
            // Use the listener address as the alias
            final String alias = listenerAddress;
            
            final String commonName;
            final CertificateExtensions certificateExtensions;
            if( sanOption == SANOption.USE_COMMON_NAME){
                commonName = listenerAddress;
                // DistingusihedName constructor will enforce length limit
                certificateExtensions = new CertificateExtensions();
            } else {
                // Listener address may exceed the 64 character common name limit, so use subject alternate name instead.
                // The common name is required by openssl, so create one which will not match any network address and is within the size limit
                String truncatedCommonName = "For " + listenerAddress;
                if( truncatedCommonName.length() > DistinguishedName.CN_MAX_LENGTH){
                    truncatedCommonName = truncatedCommonName.substring(0, DistinguishedName.CN_MAX_LENGTH);
                }
                commonName = truncatedCommonName;
                certificateExtensions = new CertificateExtensions(listenerAddress);
            }
            final DistinguishedName dn = new DistinguishedName(commonName, DistinguishedName.OU_VARIABLE);
            final boolean created = createJavaIdentityCertificate(
                    sslTempDir, keyPassphrase, keyStorePassphrase, ca, dn, certificateExtensions, alias);
            if( created ){
                logger.info("Created certificate with common name '" + dn.getCommonName() + "' cert extensions: " + certificateExtensions + " at alias '" + listenerAddress + "'");
                subjects.add(dn);
            }
        }
        return subjects;
    }
    
    
    
    /**
     * Return a list of all CA certificates.  If we have not created any certificates return the empty list.
     * @param keyStorePassphrase
     * @return
     * @throws SSLException
     */
    List<X509Certificate> listCACertificates(Passphrase keyStorePassphrase) throws SSLException{
        // Try with resources block so passphrase is cleared out after use
        final KeyStoreAccessor biIdentityKeyStoreAccessor = keyStoreServiceAccessor.getBIInternalTrustKeyStore(keyStorePassphrase, stripe);
        return listCertificates(biIdentityKeyStoreAccessor);
    }
    
    /**
     * Calculate expiry duration for new certificates to match existing certificates. 
     * @return
     */
    private int getExistingExpiry(Passphrase keyStorePassphrase) throws SSLException{
        final List<X509Certificate> caCerts = listCACertificates(keyStorePassphrase);
        final CertificateStats stats = new CertificateStats();
        stats.collectStatsOnCertificates(caCerts);
        final X509Certificate firstToExpire = stats.getFirstToExpire();
        final Date existingExpiry = firstToExpire.getNotAfter();
        int days = getDateDiffDays(new Date(), existingExpiry);
        if( days < 1){
            days = 1;
        }
        return days;
    }
    
    private static int getDateDiffDays(Date date1, Date date2) {
        final long diffInMillies = date2.getTime() - date1.getTime();
        final long days = TimeUnit.DAYS.convert(diffInMillies,TimeUnit.MILLISECONDS);
        if( days > Integer.MAX_VALUE){
            return Integer.MAX_VALUE;
        } else {
            return (int)days;
        }
    }
    
    /**
     * Return a list of all BI identity certificates in the Java keystore.
     * @param keyStorePassphrase
     * @return empty collection if never created any certificates, so don't even have a certificate store credential
     * @throws SSLException
     */
    List<X509Certificate> listIdentityCertificates(Passphrase sslPassphrase) throws SSLException{
        final KeyStoreAccessor biIdentityKeyStoreAccessor = keyStoreServiceAccessor.getBIIdentityKeyStore( sslPassphrase, stripe);
        return listCertificates(biIdentityKeyStoreAccessor);        
    }
    
    private List<X509Certificate> listCertificates(KeyStoreAccessor biKeyStoreAccessor) throws SSLException{
        final List<X509Certificate> ret = new ArrayList<X509Certificate>();
        final KeyStore biKeyStore = biKeyStoreAccessor.getKeyStore();
        final Enumeration<String> aliases;
        try {
            aliases = biKeyStore.aliases();
        } catch (KeyStoreException e) {
            throw new SSLException("Unable to read aliases from BI Identity keystore ", e);
        }
        while (aliases.hasMoreElements() ){
            final String alias = aliases.nextElement();
            final Certificate certificate;
            try {
                certificate = biKeyStore.getCertificate(alias);
            } catch (KeyStoreException e) {
                throw new SSLException("Unable to read alias '" + alias + "' from BI Identity keystore ", e);
            }
            if( certificate == null){
                throw new IllegalStateException("Null certificate at alias " + alias );
            }else if( certificate instanceof X509Certificate){
                final X509Certificate x509Cert = (X509Certificate)certificate;
                ret.add(x509Cert);
            } else {
                throw new IllegalStateException("Certificate at alias " + alias + " is of type " + certificate.getClass().getName() );
            }
        }
        return ret;
    }
    
    
    
    /**
     * Create an identity certificate if it does not already exist. 
     * Java identity certificates are all persisted in the KeyStore service.  This is provided via JPS config file. 
     * 
     * @param sslTempDir
     * @param keyPassphrase
     * @param keyStorePassphrase
     * @param ca
     * @param dn distingusihed name.  The DN's commonName is used as the host verification name if no subject alternate names are given. 
     * @param certificateExtensions allows subject alternate names to support wildcards, multiple names, and names longer than the 64 limit on common name.   
     * @return true if certificate created, false if it already exists
     * @throws SSLException
     */
    boolean createJavaIdentityCertificate(
            File sslTempDir, 
            Passphrase keyPassphrase, 
            Passphrase keyStorePassphrase, 
            CertificateAuthority ca,
            DistinguishedName dn,
            CertificateExtensions certificateExtensions,
            String alias) throws SSLException{
        // Underlying code reports errors badly, so be very protective here. 
        if( sslTempDir == null){
            throw new IllegalArgumentException("null sslTempDir");
        }
        if( keyPassphrase == null){
            throw new IllegalArgumentException("null keyPassphrase");
        }
        if( keyStorePassphrase == null){
            throw new IllegalArgumentException("null keyStorePassphrase");
        }
        if( ca == null){
            throw new IllegalArgumentException("null ca");
        }
        if( dn == null){
            throw new IllegalArgumentException("null dn");
        }
        if( alias == null){
            throw new IllegalArgumentException("null alias");
        }
        if( alias.isEmpty()){
            throw new IllegalArgumentException("empty alias");
        }
        
       
        final KeyStoreAccessor biKeyStore = keyStoreServiceAccessor.getBIIdentityKeyStore( keyStorePassphrase, stripe);
        final boolean hasAlias;
        try {
            hasAlias = biKeyStore.getKeyStore().containsAlias(alias);
        } catch (KeyStoreException e) {
            throw new SSLException("containsAlias for " + alias + " failed", e);
        }
        if( hasAlias){
            logger.info("Certificate at alias " + alias + " already exists. Not regenerating.");
            return false;
        } else {
            final File javaCertRequest = SSLFileUtils.unusedFile(sslTempDir, "javacertreq.txt");
            final File javaServerCertificateFile = SSLFileUtils.unusedFile(sslTempDir, "javasignedCert.pem");
    
            // For loading a private key into Java KeyStore need binary (DER) format.
            final File javaServerPrivateKeyfileDER = SSLFileUtils.unusedFile(sslTempDir, "javakey.der");
            final File javaServerPrivateKeyFile = SSLFileUtils.unusedFile(sslTempDir, "javakey.pem");
            
            
            
            // Create the Java stack certificate.  This creates the private key, and 
            // the certificate request. 
            opensslCommands.createOpensslUnsignedCertificate(
                    javaServerPrivateKeyFile, 
                    javaCertRequest, 
                    keyPassphrase,
                    dn,
                    certificateExtensions);
    
            // Sign java stack certificate
            ca.signCertificate(javaCertRequest, certificateExtensions, javaServerCertificateFile);
    
            opensslCommands.convertKeyToDERpkcs8( javaServerPrivateKeyFile, javaServerPrivateKeyfileDER, keyPassphrase);
            
            biKeyStore.loadPrivateKey(javaServerPrivateKeyfileDER, javaServerCertificateFile, keyPassphrase, alias );
            return true;
        }
    }





    


}
