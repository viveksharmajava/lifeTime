package oracle.bi.ssl.certificate;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.logging.Logger;

import oracle.bi.ssl.certificate.CertificateSpec.CertificateEncoding;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.locations.CertificateLocations;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.locations.OpensslCertificateFileLocations;
import oracle.bi.ssl.logging.EchoMode;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.logging.OnCompletionExecLogger;
import oracle.bi.ssl.openssl.OpensslCommands;
import oracle.bi.ssl.pub.SANOption;
import oracle.bi.ssl.pub.SSLException;



/**
 * Supports construction and storage of the certificates created for the BI components using the 
 * openssl stack.
 * 
 *  
 *  
 */
public final class OpenSSLIdentityFactory
{
    private final static Logger logger = LoggerFactory.createLogger(OpenSSLIdentityFactory.class);
    
    private final OpensslCommands opensslCommands;
    
    private final OpensslCertificateFileLocations opensslCertificateFileLocations;
    
    
    private final ExecLogger execLogger;
    
    // Common name used for the internal CA certificate.  Includes the phrase 'Certificate Authority' since that makes 
    // understanding certificate chains in the output of openssl s_client -connect much easier. 
    final static String INTERNAL_CN = "OBIEE Internal Certificate Authority";
   
    
    
    /**
     * 
     */
    public OpenSSLIdentityFactory(SSLEnvironment sslEnvironment) throws SSLException{    
        Objects.requireNonNull(sslEnvironment, "null sslEnvironment");
        
        final Homes homes = sslEnvironment.getHomes();
        
        final CertificateLocations certificateLocations = new CertificateLocations(homes.getDomainLocations());
        opensslCertificateFileLocations = certificateLocations.getOpensslCertificateLocations();
        execLogger = new OnCompletionExecLogger(logger, EchoMode.NO_ECHO);
        opensslCommands = sslEnvironment.getOpensslCommands(homes.getDomainLocations().getSSLCommandDir(), execLogger); 
       
        
    }
    
    

    
    
    
   
    
    

    

    public void cleanOpensslCertificates() throws SSLException {
        
        SSLFileUtils.createPrivateCleanDir(opensslCertificateFileLocations.getLocalhostIdentityDir());
        SSLFileUtils.createPrivateCleanDir(opensslCertificateFileLocations.getInternalIdentityDir());
        SSLFileUtils.createPrivateCleanDir(opensslCertificateFileLocations.getClientIdentityDir());
        SSLFileUtils.createPrivateCleanDir(opensslCertificateFileLocations.getInternalCADir());
    }
    
    

    
    

    
    
    


    /**
     * Store hashed form of ca certificate in a trust directory.  Since only one certificate is being stored we do not need to worry about 
     * clashing hashes.  The certificate will also be stored in a file with a human readable name.  This is for users who wish to refer to 
     * one CA by file name, rather than use the openssl trust dir mechanism. 
     * @param ca certificate authority whose CA certificate will be stored
     * @param internalTrust will be created if necessary.  Will be cleared out.
     * @param pemFileName name for ca file within the trust dir.
     * @throws SSLException
     */
    
    public void addOpensslInternalTrust(CertificateAuthority ca, File internalTrust, String pemFileName ) throws SSLException{
        
        SSLFileUtils.createPrivateCleanDir(internalTrust);       

        final File pemFile = new File(internalTrust, pemFileName);
        
        // In this case original and target file are same format, so we only really need the hash part of this utility. 
        final CertificateSpec inputSpec = new CertificateSpec(ca.getCACertificate(), CertificateEncoding.PEM);
        final CertificateSpec outputSpec = new CertificateSpec(pemFile, CertificateEncoding.PEM);
        final String hash = opensslCommands.convertCertificate(inputSpec, outputSpec);

        // Leave the original in place.  Does not clash with hashing name syntax and for clients who only care about the 
        // internal CA it's convenient to have a known filename. 
        final File hashFile = new File(internalTrust, hash + ".0");
        SSLFileUtils.copyFilePrivate(pemFile, hashFile);
        

    }



   
    
    
   
    
    

    /**
     * 
     * @param sslTempDir
     * @param serverKeyPassphrase
     * @param ca
     * @return subject DNs of generated certificates
     * @throws SSLException
     */
    public List<DistinguishedName> createOpensslIdentities(File sslTempDir, Passphrase serverKeyPassphrase, CertificateAuthority ca) throws SSLException{
        // Create the openssl stack server certificate.  This creates the private key, and 
        // the certificate request. 
        
        final List<DistinguishedName> subjects = new ArrayList<>();
        
        // sslTempDir should be cleared out after each run (for security) so should not be an existing file of this name. 
        // If there is don't just delete here - need to find why tidy up not working. 
        {
            final File opensslServerCertRequest = new File(sslTempDir, "opensslservercertreq.txt");
            // We do not match host address to this certificate, so no subject alternative name and the common name (which must still be <= 64 long)
            // is arbitrary. 
            final String serverCommonName = "OBIEE Server Openssl";
           // OU here acts as a namespace to differentiate this cert from others that may otherwise coincide
            final DistinguishedName dn = new DistinguishedName(serverCommonName, DistinguishedName.OU_FIXED);
            final CertificateExtensions certificateExtensions = new CertificateExtensions();
            opensslCommands.createOpensslUnsignedCertificate(
                    opensslCertificateFileLocations.getOpensslServerKey(), 
                    opensslServerCertRequest, 
                    serverKeyPassphrase,
                    dn,
                    certificateExtensions);
    
            ca.signCertificate(opensslServerCertRequest, certificateExtensions, opensslCertificateFileLocations.getOpensslServerCertificate());
            subjects.add(dn);
        }

        {
            final File opensslClientCertRequest = new File(sslTempDir, "opensslclientcertreq.txt");
            final String clientCommonName = "OBIEE Client";
            // OU here acts as a namespace to differentiate this cert from others that may otherwise coincide
            final DistinguishedName dn = new DistinguishedName(clientCommonName, DistinguishedName.OU_FIXED);
            // No subject alternate names needed because (1) only one name (2) length is fixed so don't need to worry about CN field length being exceeded
            final CertificateExtensions certificateExtensions = new CertificateExtensions();
            // The client certificate is used in both openssl and Java forms.  So do not include tech stack in the certificate CN.
            opensslCommands.createOpensslUnsignedCertificate(
                    opensslCertificateFileLocations.getOpensslClientKey(),
                    opensslClientCertRequest,
                    serverKeyPassphrase,
                    dn,
                    certificateExtensions);

            ca.signCertificate(opensslClientCertRequest, certificateExtensions, opensslCertificateFileLocations.getOpensslClientCertificate());
            subjects.add(dn);
        }
        return subjects;
    }

    /**
     * HTTPS servers conforming to the standard HTTPS rules require identity certificates whose subject name (neither in the common name or 
     * Subject Alternative Name fields) matches the address the client uses to connect to the server.  Due to how we launch some newer 
     * processes in their own docker images some servers are addressed at 'localhost'.  So we need a special 'localhost' certificate. 
     *
     */
    public DistinguishedName createOpensslLocalhostIdentity(SANOption sanOption, File sslTempDir, Passphrase serverKeyPassphrase, CertificateAuthority ca) throws SSLException{
        // creates the private key, and the signed certificate.  The certificate is signed using a certificate signing request sent to 
        // the input certificate authority. 

        
        // sslTempDir should be cleared out after each run for security, so should not be an existing file of this name.
        // If there is don't just delete here - need to find why tidy up not working.
        
        final File opensslLocalhostServerCertRequest = new File(sslTempDir,
                "openssllocalhostservercertreq.txt");
        // Since 'localhost' is guaranteed to fit into a CN field in this case we don't really need to support SAN.  
        // We have chosen to make this certificate consistent with the other HTTPS conformant certificates (eg WebLogic listener certificates)
        // which must support the SAN option to avoid CN field overflow.  
        
        final String serverCommonName;
        final CertificateExtensions certificateExtensions;
        if (SANOption.USE_COMMON_NAME.equals(sanOption)) {
            // if san is not enabled we need to use server common name and vacate the san
            serverCommonName = "localhost";
            certificateExtensions = new CertificateExtensions();
        } else {
            serverCommonName = "For localhost";
            certificateExtensions = new CertificateExtensions("localhost");
        }
        // OU here acts as a namespace to differentiate this cert from others that may otherwise coincide
        
        final DistinguishedName dn = new DistinguishedName(serverCommonName, DistinguishedName.OU_FIXED);
        opensslCommands.createOpensslUnsignedCertificate(
                opensslCertificateFileLocations.getLocalhostIdentityServerKey(),
                opensslLocalhostServerCertRequest,
                serverKeyPassphrase,
                dn,
                certificateExtensions);

        ca.signCertificate(opensslLocalhostServerCertRequest, certificateExtensions,
                opensslCertificateFileLocations.getLocalhostIdentityServerCertificate());
        return dn;
        
    }

}
