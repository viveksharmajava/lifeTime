package oracle.bi.ssl.locations;

import oracle.bi.ssl.pub.SSLException;



/**
 * Defines locations of certificates - either in the file system, or within the keyStore service. 
 * Java stack uses KeyStore service.  OpenSSL (C++/C) components use the file system. 
 */
public final class CertificateLocations {

    private final OpensslCertificateFileLocations opensslCertificateFileLocations;
    private final KeystoreNames keystoreNames;
    private final WalletLocations walletLocations;
    
    
    /**
     * Constructor.  
     */
    public CertificateLocations(DomainLocations domainLocations) throws SSLException
    {
        opensslCertificateFileLocations = new OpensslCertificateFileLocations(domainLocations);
        keystoreNames = new KeystoreNames();
        walletLocations = new WalletLocations(domainLocations);
        
        
    }
    
    public WalletLocations getWalletLocations(){
        return walletLocations;
    }

    public OpensslCertificateFileLocations getOpensslCertificateLocations() {
        return opensslCertificateFileLocations;
    }

    public KeystoreNames getKeyStoreNames() {
        return keystoreNames;
    }
    
    

    
    
}