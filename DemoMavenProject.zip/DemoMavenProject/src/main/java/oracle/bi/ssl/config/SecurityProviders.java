package oracle.bi.ssl.config;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.security.CodeSource;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Provider.Service;
import java.security.Security;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.TrustManagerFactory;

import oracle.bi.ssl.logging.LoggerFactory;

import com.rsa.jsafe.provider.JsafeJCE;
import com.rsa.jsse.JsseProvider;


/**
 * Provides utilities to check and debug security providers. 
 * Security providers are configured in the JRE's jre/lib/security/java.security file, possibly overridden by 
 * a file pointed to by system property java.security.properties or programmatically.  For example:
 * <pre>
 *    security.provider.1=sun.security.provider.Sun
 *    security.provider.2=sun.security.rsa.SunRsaSign
 *    security.provider.3=sun.security.ec.SunEC
 *    security.provider.4=com.sun.net.ssl.internal.ssl.Provider
 *    security.provider.5=com.sun.crypto.provider.SunJCE
 *    security.provider.6=sun.security.jgss.SunProvider
 *    security.provider.7=com.sun.security.sasl.Provider
 *    security.provider.8=org.jcp.xml.dsig.internal.dom.XMLDSigRI
 *    security.provider.9=sun.security.smartcardio.SunPCSC
 * </pre>
 * Dumps out information about the security providers.  Providers change how SSL connections - especially certificates - are 
 * handled.  Eg allow specific crypto algorithms.  
 * <p>
 * The security providers are found by looking up the highest precedence provider registered as providing service.algorithm.
 * Most importantly for this project all the SSL crypto algorithms and protocols are implemented by security providers. 
 * </P>
 * <p>
 * If a configured security provider is not available on the classpath that security provider will be silently ignored.
 * </p>
 */
public final class SecurityProviders {
    public enum DumpScope {SERVICES, CLASSPATH};
    
    private static final Logger logger = LoggerFactory.createLogger(SecurityProviders.class);
    
    private static final String PROVIDER_KEY_PREFIX = "security.provider.";
    
    private static final String ERROR_PREFIX = "FIPS 140 SSL incorrectly configured.  ";
    
    /**
     * System property defining additional java.security file
     */
    private static final String JAVA_SECURITY_OVERRIDE = "java.security.properties";
    
    private static final String PKCS12_SERVICE_KEY = "KeyStore.pkcs12";
    
    /**
     *  Will sneak to the top if not previously configured
     */
    private static final String ORACLE_KPI_PROVIDER_NAME = "OraclePKI";
    
    /**
     *  Will sneak to the top  class com.bea.common.security.jdkutils.X509CertificateFactory$MyJDKSecurityProvider
     * correcting lack or order in PKCS7 certificate formats.  It is again dynamically added. 
     * See https://docs.oracle.com/middleware/11119/wls/WLMCT/Security.html :
     * 
     *     BEA-090823: Could not register the WLS X509CertificateFactory as the default X509CertificateFactory for this JVM.
     *     Cause: Could not register the WLS X509CertificateFactory as the default X509CertificateFactory for this JVM.
     *     Action: The WLS X509CertificateFactory orders the certificates in a CertPath that was created from PKCS7. 
     *     Specify -Dweblogic.security.RegisterX509CertificateFactory=false on the command line for booting this 
     *     server to indicate that WLS should not register the WLS X509CertificateFactory as the default X509CertificateFactory 
     *     when the server boots (since your JDK does not support this). Also, since the WLS X509CertificateFactory cannot 
     *     be registered with the JDK as the default X509CertificateFactory, the JDK will use its current default X509CertificateFactory. 
     *     The default one (e.g. the SUN implementation) may not properly convert PKCS7 to an ordered CertPath.
     */
    private static final String  CSSX509_FIX_ORDER_PROVIDER = "CSSX509CertificateFactoryProvider";
           
    private static final SecurityProviders instance = new SecurityProviders();
    
    private boolean checkCompleted = false;
    private RuntimeException checkException = null;
    
    /**
     * Force access vis singleton. 
     */
    private SecurityProviders(){
        
    }
    
    /**
     * Get the singleton.  No need to synchronize since constructed by the static initializer. 
     * @return
     */
    public static SecurityProviders getInstance(){
        return instance;
    }
    
    /**
     * The provider.toString method is excessive, but getName omits useful information such as the classname.  
     * Classname is particularly germane since that is what is used in the configuration settings. 
     */
    public static String getProviderIdSummary(Provider provider){
        return "'" + provider.getName() + "' (" + provider.getClass().getName() + ")";
    }
    
    /**
     * Perform check on first call only.  Subsequent calls will re-throw a previous exception - with stack trace to equal current. 
     */
    public synchronized void checkOnce(SSLConfigWrapper sslConfig){
        if( this.checkCompleted){
            if( this.checkException != null){
                checkException.fillInStackTrace();
                throw checkException;
            }
        } else {
            this.checkCompleted = true;
            try {
                this.check(sslConfig);
            } catch (RuntimeException e){
                this.checkException = e;
                throw e;
            }
        }
    }
    
    /**
     * Check security providers for current SSL configuration. 
     * FIPS systems are currently only in GOV cloud, entirely under our control. 
     * So we can require specific configuration.  Non FIPS systems could be in OAS, configured by a customer using their choice of 
     * security providers.  So for backward compatibility do not check non-FIPS configuration.  
     *  
     */
    public void check(SSLConfigWrapper sslConfig){
        if( sslConfig.isFIPSEnabled()){
            checkFips();
        }
    }
    
    /**
     * Filter out providers which are known to be benign - can safely appear above the FIPS ones. 
     * 
     */
    private static List<Provider> getSubstantiveProviders(){
        final List<Provider> ret = new ArrayList<>();
        for( Provider provider : Security.getProviders() ){
            if(isBenign(provider) ){
                logger.fine("Ignoring benign provider " + getProviderIdSummary(provider));
            } else {
                ret.add(provider);
            }
        }
        return ret;
    }
    
    /**
     * Get first substantive security provider
     * 
     */
    public static Provider getFirstSubstantiveProvider(){
        for( Provider provider : Security.getProviders() ){
            if(!isBenign(provider) ){
                return provider;
            }
        }
        throw new IllegalStateException("No substantive security providers");
    }
    
    /**
     * Our cross checks require that the JsafeJCE is the first substantive provider.  So this is 
     * a simple check that we are using FIPS security providers.  Arguable that it would be better to go to 
     * SSLConfigWrapper and check isFipsEnabled.  But then config wrapper needs to be available. 
     * @return
     */
    public static boolean isFipsSecurityProvider() {
        // Don't let JRE try to resolve JsafeJCE as the security providers' JAR may not be available on OAS, because
        // JDK is controlled by the customer
        return getFirstSubstantiveProvider().getClass().getName().equals("com.rsa.jsafe.provider.JsafeJCE");
    }
    
    private static boolean isBenign(Provider provider){
        return CSSX509_FIX_ORDER_PROVIDER.equals(provider.getName());
    }
    
    /**
     * Throw if FIPS 140 security providers are not correctly configured.  This will check afresh each time. Useful for tests 
     * where the FIPS configuration is programmatically changed repeatedly.  To guard SSL code against missconfiguration 
     * use checkFipsOnce().  
     */
    public void checkFips(){
        // FIPS 140 configuration states JsafeJCE and JsseProvider security providers, in that order. 
        final List<Provider> providers = getSubstantiveProviders();
        if( providers.size() < 2){
            reportProblem("Only " + providers.size() + " substantive security providers");
        }
        
        {
            final Provider topProvider = providers.get(0);
            if( !(topProvider instanceof JsafeJCE) ){
                reportProblem("Top substantive security provider is " + getProviderIdSummary(topProvider) + " expected " + JsafeJCE.class.getName());
            }
        }
        
        {
            final Provider secondProvider = providers.get(1);
            if( !(secondProvider instanceof JsseProvider) ){
                reportProblem("Second substantive security provider is " + getProviderIdSummary(secondProvider) + " expected " + JsseProvider.class.getName());
            }
        }
        
        // The OraclePKI security provider (oracle.security.pki.OraclePKIProvider)will be programmatically added to the top of the list, usurping the FIPS required 
        // providers.   Appears to happen if wallets manipulated.  This is a horrible feature.  Prevent it happening by 
        // ensuring it is already on the list. 
        {
            if( Security.getProvider(ORACLE_KPI_PROVIDER_NAME) == null){
                reportProblem("To prevent later disruption of the FIPS security providers the '" + 
                              ORACLE_KPI_PROVIDER_NAME + "' (oracle.security.pki.OraclePKIProvider) provider must be pre-configured");
            };
        }
        {
            // The checks on SecurityStore by PKCS12_SERVICE_KEY are implied by the KeyStoreType.getDefaultKeyStoreType()
            // but it does no harm to cross check here. 
            
            final Provider[] keyStoreProviders = Security.getProviders(PKCS12_SERVICE_KEY);
            
            if(keyStoreProviders.length == 0){
                reportProblem("No security provider for " + PKCS12_SERVICE_KEY);
            }
            final Provider topKeyStoreProvider = keyStoreProviders[0];
            if( !(topKeyStoreProvider instanceof JsafeJCE) ){
                reportProblem( 
                    "Top " + PKCS12_SERVICE_KEY + " provider is " + getProviderIdSummary(topKeyStoreProvider) + 
                    " expected " + JsafeJCE.class.getName());
            }
        }
        
        if( KeyStoreType.getDefaultKeyStoreType() != KeyStoreType.pkcs12){
            reportProblem("Security providers not configured to enable PKCS12 KeyStore type");
        }
        
    }
    
    /**
     * Log and throw problem
     * @param description
     */
    private void reportProblem(String description){
        final String fullDescription = ERROR_PREFIX + description + "\n\n";
        
        final String debugInfo = doDumpToString(EnumSet.of(DumpScope.CLASSPATH));
        
        IllegalStateException e = new IllegalStateException(fullDescription + debugInfo);
        
        logger.log(Level.SEVERE, fullDescription, e);
        throw e;
    }
    
    private String doDumpToString(EnumSet<DumpScope> dumpScopes){
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        final String utf8 = StandardCharsets.UTF_8.name();
        try {
            try (PrintStream ps = new PrintStream(baos, true, utf8)) {
                this.doDump(ps, dumpScopes);
            }
            return baos.toString(utf8);
        } catch (IOException e2){
           return "Failed to dump security providers due to: " + e2.getMessage(); 
        }
    }
    
    
    public void doMinimalDump(PrintStream ps){
        doDump(ps, EnumSet.noneOf(DumpScope.class));
    }
    /**
     * Dump everything - including classpath diagnostics and services/algorithms each provider is registered to provide.  
     * 
     */
    public void doFullDump(PrintStream ps){
        doDump(ps, EnumSet.allOf(DumpScope.class));
    }
    /**
     * Dump information to stdout.  This can be very extensive - especially if the configured providers do not match the 
     * current providers.  In a real system this is indicative of miss-configuration, so is worth dumping.  In a test system 
     * where the FIPS sceanrio is programmatically achieved its a distraction. 
     * @param scopes
     */
    public void doDump(PrintStream ps, Set<DumpScope> scopes){
        // Java SSL connection depends on security providers configured, and which of those are available on the 
        // classpath.  So list them, and also list those not found.  
        ps.println("Running Java version: " + System.getProperty("java.version") + " from: " + System.getProperty("java.home"));
        ps.println("With security providers: ");
        final List<String> activeProviders = new ArrayList<>();
        
        for( Provider provider : Security.getProviders()){
            final String providerClassName = provider.getClass().getName();
            activeProviders.add(providerClassName);
            final String benign = isBenign(provider) ? " - benign " : "";
            ps.println("  " + provider + " (" + providerClassName + ")" +benign);
            if( scopes.contains(DumpScope.SERVICES)){
                for (Service service : provider.getServices()){
                   ps.println("      Type: " +  service.getType() + " Algorithm: " + service.getAlgorithm() + " Class: " + service.getClassName());
                }
            }
        }
        
        
        // Now check for consistency with the configured providers - has classpath disabled one?  Have they been 
        // programmatically changed?
        int counter = 1;
        final List<String> configuredProviders = new ArrayList<>();
        
        
        while( counter != 0 ){
            final String key = PROVIDER_KEY_PREFIX + counter;
            final String providerClassName = Security.getProperty(key);
            if( providerClassName == null){
                // Reach end of configuration list
                counter = 0;
            } else {
                configuredProviders.add(providerClassName);
                
                counter++;
            }
        }
        
        if( !activeProviders.equals(configuredProviders)){
            ps.println("Active providers");
            ps.print("  ");
            ps.println(activeProviders);
            ps.println("Does not match configured providers:");
            ps.print("  ");
            ps.println(configuredProviders);
            
            if( scopes.contains(DumpScope.CLASSPATH)){
                // Checking if we can access a provider class is not a definitive test of whether claspath is correct - 
                // we may be running in a child classloader.  What 
                // matters is can the code which actually loads providers access the class.  
                ps.println("Checking security providers accessible from classloader ");
                for( String providerClassName : configuredProviders){
                    try{
                        final boolean initialize = true;
                        final Class<?> fromMyClassloader = Class.forName(providerClassName, initialize, this.getClass().getClassLoader());
                        // Protect from possible null codeSource
                        final CodeSource codeSource = fromMyClassloader.getProtectionDomain().getCodeSource();
                        final String source;
                        if( codeSource == null){
                            source = "Null code source";
                        } else {
                            source = codeSource.getLocation().toString();
                        }
                        ps.println("Provider '" + providerClassName + "' is available on class loader " + 
                                fromMyClassloader.getClassLoader() + " at " + source);
                    } catch (ClassNotFoundException e){
                        ps.println("Warning: provider class " + providerClassName + " not found");
                        
                    }
                }
            
                ps.println();
                ps.println("Classloader tree:");
                // A missing provider is most often due to classloader issues, so dump the classloader tree.
                dumpClassloader(ps, this.getClass().getClassLoader());
                ps.println();
            }
        }
        
        
        
        final String override = System.getProperty(JAVA_SECURITY_OVERRIDE);
        if( override != null){
            ps.println("JRE java.security file overridden by " + JAVA_SECURITY_OVERRIDE + " = " + override);
        }
        
        final String algorithm = TrustManagerFactory.getDefaultAlgorithm();
        ps.println("Default trust manager algorithm: " + algorithm);
        try {
            final TrustManagerFactory tmf = TrustManagerFactory.getInstance(algorithm);
            ps.println("  Trust manager factory: " + tmf.getClass().getName() );
        } catch (NoSuchAlgorithmException e) {
            ps.println("  Algorithm " + algorithm + " not supported");
        }
        
        
    }
    
    /**
     * Dump brief information about the classloader hierarchy, including the jars directly referenced by URLClassLoaders.
     * The indirect jars referenced by manifests are not listed. 
     * @param classLoader loader to dump
     */
    private static void dumpClassloader(PrintStream ps, ClassLoader classLoader)  { 
       
        if( classLoader == null){
            ps.println( "null (bootstrap) classloader");
        } else {
            
            ClassLoader cl = classLoader;
            while (cl != null){
                ps.print("Classloader " + cl);
                // The weblogic global parent is a PolicyClassLoader - which does not derive from URLClassLoader and of course does not 
                // exist in non WebLogic based deployments (eg those on Jetty).  So we cannot refer to that class here unless we get in to 
                // reflective invocations or customize classloader handling in the Actio setup class. 
                if( cl instanceof URLClassLoader){
                    ps.println();
                    // Despite IDE warnings about leaks, do NOT close the classloader.  This results in subtle failures later, especially in JUnit 
                    // with junit runner and error reporting classes not found.  We have just accessed the classloader for read only inspection - we 
                    // should not interfere with the life cycle of the classloaders.  
                    final URLClassLoader urlClassLoader = (URLClassLoader)cl;
                    for( URL url : urlClassLoader.getURLs()){
                        ps.println("  " + url);
                        
                    }
                } else {
                    ps.println( "  -- not a URLClassLoader");
                }
                cl = cl.getParent();
            }
        }    
        
    }
    
    
    
    /**
     * Support trivial main to dump full information about the currently configured security providers.  Note that this only 
     * confirms the configuration of the JRE - other environments such as WebLogicv may have dramatically different configurations, in 
     * particular vastly larger classpaths. 
     * 
     */
    public static void main(String[] args){
        final SecurityProviders securityProviderDump = new SecurityProviders();
        securityProviderDump.doFullDump(System.out);
        
       
    }
}
