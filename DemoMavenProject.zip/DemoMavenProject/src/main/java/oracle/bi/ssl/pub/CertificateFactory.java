package oracle.bi.ssl.pub;


import java.io.File;
import java.io.PrintStream;

import oracle.bi.endpointmanager.pub.EndpointManager;
import oracle.bi.endpointmanager.pub.EndpointManagerFactory;
import oracle.bi.ssl.certificate.IdentityFactory;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.config.SecurityProviders;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.ping.Report;





/**
 * Supports construction and storage of the many certificates.  Certificates are created in a temporary directory
 *  
 * There are two SSL stacks - openssl used by the C++ components, and 
 * keytool used by the Java components.  They store the certificates in different store types.
 * 
 * This is the public api for performing the ssl initialization at config assistant time.  
 * 
 * 
 */
public final class CertificateFactory
{
    private final SSLEnvironment sslEnvironment;
    private final EndpointManager endpointManager;
    // Give or take leap years which do not occur every 4th year, 20 years.   
    public final static int TWENTY_YEARS_IN_DAYS = 365 * 20 + 5;
    /**
     * Constructor
     * @param oracleHome
     * @param domainHome We do not use DomainLocations in the api since that includes lots of internal location information and so is not in the pub package.
     */
    public CertificateFactory(File oracleHome, File domainHome) throws SSLException{
        this(new Homes(oracleHome, domainHome));
    }
    
    /**
     * Hide the constructor taking the non-public Homes. 
     * @param homes
     * @throws SSLException
     */
    private CertificateFactory(Homes homes) throws SSLException {
        this(homes, getEndpointManager(homes));
    }
    
    /**
     * Constructor for testing.  Allows endpoint manager to be mocked. 
     */
    public CertificateFactory(Homes homes, EndpointManager endpointManager) throws SSLException{   
        if( homes == null){
            throw new IllegalArgumentException("null homes");
        }
        if( endpointManager == null){
            throw new IllegalArgumentException("null endpointManager");
        }
        this.endpointManager=endpointManager;
        sslEnvironment = new SSLEnvironment(homes);
    }
    
       
    /**
     * Convenience method to do all the ssl steps, including initializing the config and creating certificates.  
     * @throws SSLException
     * @deprecated Use {@link #initializeSSL(SANOption)}
     */
    @Deprecated
    public void initializeSSL() throws SSLException {
        initializeSSL(SANOption.getDefaultSANOption());
    }
    
    /**
     * Convenience method to do all the ssl steps, including initializing the config and creating certificates.  
     * @throws SSLException
     */
    public void initializeSSL(SANOption sanOption) throws SSLException {
        // bi-ssl.xml is included in the base bi template.
        // openssl.cnf is included in the base bi template.
        
        
        // Public entry point for configuration.  Protect against bad Security providers.  If miss-configured these would give very 
        // subtle errors such as silently ignoring identitiy entries in wrong type of KeyStore, or failure to create key entries 
        // in keystores. 
        
        final SecurityProviders securityProviders = SecurityProviders.getInstance();
        securityProviders.checkOnce(sslEnvironment.getConfigWrapper());
        
        
        final IdentityFactory identityFactory = 
                new IdentityFactory(sslEnvironment, KeyStoreType.getDefaultKeyStoreType(), endpointManager);
        identityFactory.generateInternalCertificates(new CertOptions(TWENTY_YEARS_IN_DAYS, sanOption));
        
        // Out the box we use internal channels, using internal certificates.  So we only need internal certificates.  
    }

    /**
     * Human readable report on ssl health. 
     * @throws SSLException 
     */
    public void runSSLReport(PrintStream ps) throws SSLException{
        final Report report = new Report(ps, this.sslEnvironment, KeyStoreType.getDefaultKeyStoreType(), endpointManager, false);
        report.scanAllTypes();
    }
    
    
    private static EndpointManager getEndpointManager(Homes homes){
    
        final EndpointManagerFactory emFactory = new EndpointManagerFactory();
        final EndpointManager endpointManager = 
                emFactory.getEndpointManager(homes.getDomainLocations().getDomainHome(), homes.getOracleHomeLocations().getBiProductHome() );
        return endpointManager;
        
    }
    
    

}
