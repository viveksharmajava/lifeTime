package oracle.bi.ssl.certificate;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.util.Enumeration;

public class JKStoPKCS12Converter {

    public static KeyStore convertKeystore(
            KeyStore sourceKeystore,
            char[] keystorePassword
            ) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableEntryException{

        

        KeyStore destKeystore = KeyStore.getInstance("pkcs12");
        destKeystore.load(null, keystorePassword);

        // Assume each alias in a keystore has the same password
        // as the keystore itself.
        KeyStore.ProtectionParameter sourceAliasPassword =
                new KeyStore.PasswordProtection(keystorePassword);
        KeyStore.ProtectionParameter destAliasPassword =
                new KeyStore.PasswordProtection(keystorePassword);

        Enumeration<String> aliasList = sourceKeystore.aliases();
        while (aliasList.hasMoreElements()) {
            String alias = aliasList.nextElement();
            KeyStore.Entry entry =
                    sourceKeystore.getEntry(alias, sourceAliasPassword);
            destKeystore.setEntry(alias, entry, destAliasPassword);
        }

        return destKeystore;
    }
}
