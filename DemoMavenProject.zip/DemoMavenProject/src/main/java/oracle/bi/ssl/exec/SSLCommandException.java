package oracle.bi.ssl.exec;

import oracle.bi.ssl.pub.SSLException;
/**
 * Openssl command line returned non-zero exit status
 *
 */
public class SSLCommandException extends SSLException{
   
    private static final long serialVersionUID = 1L;

    public SSLCommandException(int status, String cmdLine, String stderr){
        super("SSL command " + cmdLine + " returned non-zero status " + Integer.toString(status) + "\nStderr:\n" + stderr);
    }
}
