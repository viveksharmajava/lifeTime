package oracle.bi.ssl.pub;

/**
 * SSL Config wrong, or SSL operation failed. 
 */
public class SSLException extends Exception
{
   /**
     * 
     */
   private static final long serialVersionUID = 1L;

   public SSLException(String reason)
   {
      super(reason);
   }

   public SSLException(String reason, 
                       Exception e)
   {
      super(reason, e);
   }
   
   public SSLException(Exception e) {
       super(e.getMessage(), e);
   }
}


