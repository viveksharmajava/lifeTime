package oracle.bi.ssl.openssl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.ssl.certificate.CertificateExtensions;
import oracle.bi.ssl.certificate.CertificateSpec;
import oracle.bi.ssl.certificate.DistinguishedName;
import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.exec.ExecOpenssl;
import oracle.bi.ssl.exec.Executable;
import oracle.bi.ssl.exec.ProcessKiller;
import oracle.bi.ssl.exec.SSLCommandException;
import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;
import oracle.bi.ssl.resources.SSLLogMsgID;

import org.apache.commons.io.FileUtils;



/**
 * Provides certificate manipulations based on openssl command line tool. 
 * 
 */
public final class OpensslCommands {
    private static final Logger _logger = LoggerFactory.createLogger(OpensslCommands.class);
    
    
    

    // Utility to launch command line execution of openssl. 
    private final ExecOpenssl _execOpenssl;

    private final File _opensslCnf;
    private final SSLEnvironment _sslEnvironment;
    

    /**
     * Do not create an OpensslCommands object directly - always go via the SSLEnvironment so that version checks can be carried out. 
     * <p> 
     * Since the openssl sub-process working directory may be different from the current working directory, all 
     * paths should be converted into absolute paths PRIOR to being given as arguments on the openssl command line.  This conversion is done 
     * within this class - callers don't need to worry about relative versus absolute paths. 
     * </p>
     * @param homes defines domain and oracle homes
     * @param workingDir where intermediate files eg custom .cnf settings files will be stored
     * @param execLogger 
     * 
     */
    public OpensslCommands(SSLEnvironment sslEnvironment, File workingDir, ExecLogger execLogger) throws SSLException {
        Objects.requireNonNull(execLogger, "null execLogger");
        _sslEnvironment = Objects.requireNonNull(sslEnvironment, "null sslEnvironment");
        
        _logger.info("Running openssl from working directory: " + workingDir.getAbsolutePath() );
        
        final Homes homes = sslEnvironment.getHomes();
        FilePrereqs.checkNonEmptyFile(homes.getOracleHomeLocations().getOracleHome(), "oracleHome ");
        
        
        // For non-fips use the openssl executable packaged with the biserver project. 
        final File binDir = homes.getOracleHomeLocations().getServerBinDir();
        FilePrereqs.checkDirExists(binDir, "binDir"); 

        File openssllocation = new File(homes.getOracleHomeLocations().getOracleHome() , "bi/modules/oracle.bi.openssl/bin");
        
        final File linuxExecutable;
        final File windowsExecutable;
        if( sslEnvironment.getConfigWrapper().isFIPSEnabled()){
            linuxExecutable = new File("/usr/bin/openssl");
            // No support for FIPS on windows.  Make sure we don't fall back onto non-fips openssl. 
            windowsExecutable = null;
        } else {
            if(openssllocation.exists())
            {
                linuxExecutable = new File(openssllocation, "openssl");
                windowsExecutable = new File(openssllocation, "openssl.exe");
            }
            else
            {
                linuxExecutable = new File(binDir, "openssl");
                windowsExecutable = new File(binDir, "openssl.exe");
            }
        }
        final Executable executable = new Executable(linuxExecutable, windowsExecutable);
        _execOpenssl = new ExecOpenssl(homes, executable, workingDir, execLogger);
        
        _opensslCnf = homes.getDomainLocations().getOpensslCnf();
    }


    private File getWorkingDir(){
        return _execOpenssl.getWorkingDir();
    }

    /**
     * Log openssl version and if in fips mode check openssl is a fips build.
     * @throws SSLException
     */
    public void checkVersion() throws SSLException {
        final String version = getVersion();
        _logger.info("Using Openssl executable at: " + _execOpenssl.getExecutable().getExecutableFile() + ", version: " + version);
        if( this._sslEnvironment.getConfigWrapper().isFIPSEnabled()){
            if( !version.toLowerCase().contains("fips")){
                throw new SSLException("Openssl executable at: " + _execOpenssl.getExecutable().getExecutableFile() + ", version: " + version + " not fips");
            }
        }
    }
    /**
     * @return the version string from the OpenSSL command line. 
     * @throws SSLException 
     */
    public String getVersion() throws SSLException{
        final List<String> cmdargs = Arrays.asList
                ( "version"  );
        
        final List<String> output = _execOpenssl.runOpensslCommand( cmdargs, Collections.emptyList(), "version" );
        if( output.isEmpty() ){
            throw new SSLException("No output from openssl version command");
        }
        // Example output:
        //
        // OpenSSL 1.0.1e-fips 11 Feb 2013
        // 
        // OpenSSL 1.0.2u  20 Dec 2019
        // 
        // Openssl versions we build and install into bi/foundation/server/bin will also output the scary but benign:
        // 
        // WARNING: can't open config file: /tmp/bi-openssl/openssl-libs/build/dist/linux64/release/openssl.cnf
        //
        // Fortunately the warning is output on stderr so does not get in the way.  
        return output.get(0);
    }

    /**
     * Create a certificate authority.  This is just a self signed private key/certificate pair. 
     * Openssl stores key and certificate in two files.  
     * @param cn the common name
     */
    public void createCA(
            File keyFile, 
            File certificateFile, 
            Passphrase keyPassPhrase,
            DistinguishedName dn,
            int days)
            throws SSLException {
        _logger.log(Level.INFO, " Creating CA private key \n" + 
                "     " + keyFile + "\n" +
                "and public CA certificate \n" + 
                "     " + certificateFile );
        if( dn == null){
            throw new IllegalArgumentException("null dn");
        }
        
        FilePrereqs.checkIsPemFile(keyFile);
        FilePrereqs.checkIsPemFile(certificateFile);
        
        FilePrereqs.checkNoOverwrite(keyFile, "createCA keyFile");
        FilePrereqs.checkNoOverwrite(certificateFile, "createCA certificateFile");

        // See http://www.openssl.org/docs/apps/openssl.html

        // The distinguished name field types must be in capitals.  If you use lower case eg /cn=  get 
        // error message: Subject Attribute cn has no known NID, skipped
        // The req command does not use the default_days setting - this is for signing individual certs only. 
        // So set a very long lifespan here of 20 years.  If a customer wants to invalidate the CA just 
        // regenerate all certificates which will result in a new CA so any old CA cert becomes 
        // irrelevant.   Since the CA expiry is so long, validity becomes controlled by the individual 
        // certificate expiries which is configurable via openssl.conf.  This is consistent with 
        // public CAs which are typically valid for long periods, eg until 2036.   
        final List<String> cmdargs = Arrays.asList
            ( "req",
                "-new",
                "-x509",
                "-sha256", // sha1 the default now considered insecure. 
                "-keyout", keyFile.getAbsolutePath(),
                "-out", certificateFile.getAbsolutePath(),
                "-days", Integer.toString(days),
                "-passout", "stdin", 
                "-subj", dn.toString()
                );



        _execOpenssl.runOpensslCommand( cmdargs, Arrays.asList(keyPassPhrase.getPassphraseChars()), "createCA" );

        SSLFileUtils.checkNewlyCreatedFile(keyFile, "createCA keyFile");
        SSLFileUtils.checkNewlyCreatedFile(certificateFile, "createCA certificateFile");

    }

    

    /**
     * Change the passphrase protecting a private key
     */
    public void changeKeyPassphrase(File originalFile, File newFile, Passphrase originalPassphrase, Passphrase newPassphrase) throws SSLException{
        _logger.log(Level.INFO, " Copying, with passphrase change, key file " + newFile.getAbsolutePath() +  " to " + newFile.getAbsolutePath() );
                
        FilePrereqs.checkIsPemFile(originalFile);
        FilePrereqs.checkNoOverwrite(newFile, "changeKeyPassphrase newFile");
        final List<String> cmdargs = Arrays.asList
                  ( "rsa", 
                    "-des3", 
                    "-in", originalFile.getAbsolutePath(),
                    "-passin", "stdin",
                    "-out", newFile.getAbsolutePath(),
                    "-passout", "stdin"
                    );
        final List<char[]> stdinLines = 
                Arrays.asList(
                        originalPassphrase.getPassphraseChars(),
                        newPassphrase.getPassphraseChars());
        
        _execOpenssl.runOpensslCommand( cmdargs, stdinLines, "changeKeyPassphrase");

        SSLFileUtils.checkNewlyCreatedFile(newFile, "changeKeyPassphrase, newFile");
    }
    
    /**
     * Validate client trust directory configuration by connecting to a server. 
     * Each s_client command can take 30 to 60 seconds if the endpoint is not an SSL one.  There can be two so thats about 
     * 90 seconds.  s_client does not provide an option to change timeouts.  
     */
    public void validateClient( OpensslEndpoint opensslEndpoint, 
                                String host, 
                                int port,
                                String ... inputs)
            throws SSLException {
        _logger.log(Level.INFO, " Attempting to connect to " + host + ":" + Integer.toString(port) + " using trust directory \n" + 
                "     " + opensslEndpoint.getTrustDir() );
        Objects.requireNonNull(opensslEndpoint, "null opensslEndpoint");
        Objects.requireNonNull(host, "null host");


        // See http://www.openssl.org/docs/apps/openssl.html


        // Verification only behaves like the real connect - ie fails to connect - if the undocumented verify_return_error is used.  If 
        // verify_return_error is not used, return status is 0 even if certificates are not ok.  
        // However the detail of the certificates is only displayed if showcerts is used without verify_return_error.  So use first form 
        // to see if there is a problem, and second to get details. 

        final List<String> cmdargsShared = new ArrayList<String>();
        
        cmdargsShared.addAll( Arrays.asList(
                "s_client",
                "-verify","9", // 9 is the default but user could override by manual config settings for individual connections.  Ideal would be to use min of all configured/default values. 
                "-connect", host + ":" + Integer.toString(port), // s_client runtime usage says use in preference to -host -port
                "-CApath", opensslEndpoint.getTrustDir().getAbsolutePath(),
                "-cert", opensslEndpoint.getCertFile().getAbsolutePath(),
                "-key", opensslEndpoint.getKeyFile().getAbsolutePath(),
                "-pass", "stdin"
               )
        );

        final String ciphers = opensslEndpoint.getCiphers();
        // If list empty do not restrict ciphers from default.
        if( !ciphers.isEmpty() ){
            cmdargsShared.addAll( Arrays.asList(
                "-cipher", ciphers));
        }
        
        // -verify_hostname in doc page,but not supported according to runtime usage
        final List<String> cmdargsVerify = new ArrayList<String>();
        cmdargsVerify.addAll(cmdargsShared);
        cmdargsVerify.add("-verify_return_error"); // Fail process if certificate verification fails (reduces output diagnostics but makes fail clearer).
        
        final List<String> cmdargsShowCerts = new ArrayList<String>();
        cmdargsShowCerts.addAll(cmdargsShared);
        
        final Passphrase keyPassphrase = opensslEndpoint.getKeyPassphrase();
        final List<char[]> combinedInputs = new ArrayList<char[]>();
        combinedInputs.add(keyPassphrase.getPassphraseChars());
        for(String input : inputs){
            combinedInputs.add(input.toCharArray());
        }
        // Ensure openssl s_client terminates by giving it a single Q
        final String quitCommand = "Q"; 
        combinedInputs.add( quitCommand.toCharArray() );
        
        
          
        _logger.info("Sending passphrase plus Q quit strings to openssl s_client command");
        try{
            _execOpenssl.runOpensslCommand( cmdargsVerify, combinedInputs, "verify web server certs");
        } catch(SSLCommandException e){
            // This at WARNING level, so translate it (we should really translate 
            // INFO and up - but the ssl code never has)
            _logger.log(Level.WARNING, SSLLogMsgID.SSL_PING_DETAILS, 
                    new String[]{host, Integer.toString(port), opensslEndpoint.getTrustDir().getAbsolutePath()} );
            try{
                // TBD.  We know there is a problem, so we would like to up logging level??  
                _execOpenssl.runOpensslCommand( cmdargsShowCerts, combinedInputs, "show web server certs");
            } catch (SSLException nested){
                // do not obscure original exception with nested
                e.addSuppressed(nested);
            }
            
            throw e;
        }
   }

    
    
    /**
     * Validate server configuration by running a server.  
     */
    public void runServer( ProcessKiller processKiller, OpensslEndpoint endpoint, int port, OpensslProtocol[] opensslProtocolOptions)
            throws SSLException {
        _logger.log(Level.INFO, " Running " + Arrays.toString(opensslProtocolOptions) + " server on port " + Integer.toString(port) + " using certificate:\n" + 
                "     " + endpoint.getCertFile() + "\n" +
                " key:\n" +
                "     " + endpoint.getKeyFile() + "\n" +
                " trust:\n" +
                "     " + endpoint.getTrustDir() );

        


        // See http://www.openssl.org/docs/apps/openssl.html


        // Verification only behaves like the real connect - ie fails to connect - if the undocumented verify_return_error is used.  If 
        // verify_return_error is not used, return status is 0 even if certificates are not ok.  
        // However the detail of the certificates is only displayed if showcerts is used without verify_return_error.  So use first form 
        // to see if there is a problem, and second to get details. 


        final List<String> cmdargsServer = new ArrayList<String>();
        cmdargsServer.addAll( Arrays.asList(
             "s_server",
                "-accept", Integer.toString(port),
                // "-naccept_count", "1", Do not set -naccept_count - run indefinitely - use processKiller to stop
                "-cert", endpoint.getCertFile().getAbsolutePath(), 
                "-key", endpoint.getKeyFile().getAbsolutePath(),
                "-pass", "stdin",
                "-CApath", endpoint.getTrustDir().getAbsolutePath(),
                "-www", // Echo back in html format ssl handshake information
                "-Verify", "9" // Note Verify not verify so client certificate is compulsory
               
                //"-debug"
                // Do not fail if verification fails - leave that to the client.
                // "-verify_return_error" 
            )
        );
        for(OpensslProtocol protocol : opensslProtocolOptions){
            cmdargsServer.add( "-" + protocol);
        }
       
        
        try{
            _execOpenssl.runKillableOpensslCommand( processKiller, cmdargsServer, Arrays.asList(endpoint.getKeyPassphrase().getPassphraseChars()), "s_server");
        } catch(SSLException e){
            // This at WARNING level, so translate it (we should really translate 
            // INFO and up - but the ssl code never has)
            _logger.log(Level.WARNING, "s_server failed with " + e);
            
        }
   }


    /**
     * Create an openssl key/certificate request pair using openssl.  
     * @param certificateExtensions contains subject alternate names. If non empty, certificate will be given subject alternative names (SANs).  A SAN allows listener addressses which do not 
     * fit into the subject name length limits to be supported.  They also allow wild cards - although we have no plans to use wildcards. 
     * If subjectAltNames are given the distinguishedName should not include a common name. 
     * See https://support.dnsimple.com/articles/what-is-common-name/:
     * "The CA/Browser Forum has since mandated that the SAN would also include any value present in the common name, effectively
     *  making the SAN the only required reference for a certificate match with the server name. 
     *  The notion of the common name survives mostly as a legacy of the past."
     *  @param distinguishedName openssl fails with "The commonName field needed to be supplied and was missing" if CN= is not 
     *  included in the distinguished name. 
     */
    public void createOpensslUnsignedCertificate(
            File keyFile, 
            File certRequest, 
            Passphrase keyPassphrase,
            DistinguishedName distinguishedName,
            CertificateExtensions certificateExtensions )
                    throws SSLException {
        _logger.log(Level.INFO, " Creating openssl private key \n" + 
                "      " + keyFile + "\n" +
                " and certificate request \n" + 
                "      " + certRequest );
        FilePrereqs.checkIsPemFile(keyFile);
        FilePrereqs.checkIsPemFile(keyFile);
        
        FilePrereqs.checkNoOverwrite(keyFile, "createOpensslUnsignedCertificate, keyFile");
        FilePrereqs.checkNoOverwrite(certRequest, "createOpensslUnsignedCertificate, certRequest");

        // See http://www.openssl.org/docs/apps/openssl.html

        // The distinguished name field types must be in capitals.  If you use lower case eg /cn=  get 
        // error message: Subject Attribute cn has no known NID, skipped
        final List<String> cmdargs = new ArrayList<>();
        cmdargs.addAll(Arrays.asList
            ( "req", 
                "-new", 
                "-sha256", // Default sha1 considered insecure
                "-keyout", keyFile.getAbsolutePath(),
                "-out", certRequest.getAbsolutePath(),
                "-passout", "stdin", 
                "-subj", distinguishedName.toString()
            )
        );
 
        final List<String> subjectAltNames = certificateExtensions.getSubjectAlternativeNames();
        if( !subjectAltNames.isEmpty() ){
            // Openssl 1.1.1 supports adding extension arguments direct to the command line with -addext.  In earlier versions 
            // we must put the information into a config file
            final File sanConfig = new File(this.getWorkingDir() + "san.cnf");
            
            // Start with the default config file contents
            try {
                FileUtils.copyFile(this._opensslCnf, sanConfig);
            } catch (IOException e) {
                throw new SSLException("Unable to copy openssl cnf file " + this._opensslCnf + " to create san config file " + sanConfig, e);
            }
            
            final boolean append = true;
            
            final List<String> lines = new ArrayList<>();
            lines.add("");
            lines.add("[ req ]");  // We can add additional entries by repeating existing section headings - avoids editing depths of default file
            lines.add("req_extensions = san_req_ext");
            lines.add("[ san_req_ext ]");
            
            final StringBuilder sanLine = new StringBuilder();
            sanLine.append("subjectAltName = ");
            // Only the last SAN is taking effect.  Have tried both one line and separate line formms
            int sanCounter = 0;
            for( String san : subjectAltNames){
                if( sanCounter > 0){
                    sanLine.append(",");
                }
                sanLine.append("DNS:");
                sanLine.append(san);
            }
            lines.add(sanLine.toString());
            
            /*
            lines.add("subjectAltName = @alt_names");
            lines.add("");
            lines.add("[alt_names]");
            int sanCounter = 1;
            for( String san : subjectAltNames){
                final String sanLine = "DNS." + sanCounter + " = " + san;
                lines.add(sanLine);
                sanCounter++;
            }
            */
            try {
                FileUtils.writeLines(sanConfig, lines, append);
            } catch (IOException e) {
                throw new SSLException("Unable to add SAN definition to " + sanConfig, e);
            }
            cmdargs.addAll(Arrays.asList
                ( "-config",
                  sanConfig.getAbsolutePath()
                 )
            );
        }


        _execOpenssl.runOpensslCommand( cmdargs, Arrays.asList(keyPassphrase.getPassphraseChars()), "createOpensslUnsignedCertificate");

        SSLFileUtils.checkNewlyCreatedFile(keyFile, "createOpensslUnsignedCertificate, keyFile");
        SSLFileUtils.checkNewlyCreatedFile(certRequest, "createOpensslUnsignedCertificate, certRequest");


    }
    
    /**
     * To assist debugging, dump content of a signing request. 
     * @param keyFile
     * @param certSigningRequest
     */
    public void dumpSigningRequest(
            File certSigningRequest) throws SSLException{
        final List<String> cmdargs = new ArrayList<>();
        cmdargs.addAll(Arrays.asList
            ( "req", 
              "-in", certSigningRequest.getAbsolutePath(),
              "-noout",
              "-text",
              "-verify"
            )
        );
        
        _execOpenssl.runOpensslCommand( cmdargs, Collections.emptyList(), "dumpSigningRequest");

        
    }
    
    /**
     * To assist debugging, dump content of a X509 pem certificate. 
     * @param keyFile
     * @param certSigningRequest
     */
    public void dumpX509Certificate(
            File cert) throws SSLException{
        final List<String> cmdargs = new ArrayList<>();
        cmdargs.addAll(Arrays.asList
            ( "x509", 
              "-in", cert.getAbsolutePath(),
              "-noout",
              "-text"
            )
        );
        
        _execOpenssl.runOpensslCommand( cmdargs, Collections.emptyList(), "dumpX509Certificate");

        
    }

    /**
     * List cipher names supported by openssl  
     * @return : separated list
     */
    public String listCiphers(
            OpensslProtocol protocol)
                    throws SSLException {
        
        // See https://www.openssl.org/docs/apps/ciphers.html

        final List<String> cmdargs = Arrays.asList
            ( "ciphers", 
              //"HIGH",
              "-" + protocol.toString()  
                );



        final List<String> result =  _execOpenssl.runOpensslCommand( cmdargs, new ArrayList<char[]>(), "listCiphers");

        if( result.isEmpty() ){
            throw new SSLException("No ciphers returned");
        }

        final String ret = result.get(0);        
        return ret;
   }

    /**
     * Convert a private key in pkcs8 (as used by the WebLogic demo CA) to openssl's internal form  
     * 
     */
    public void convertPrivateKey(
            File pkcs8DerKeyFile, 
            File opensslPemKeyFile, 
            Passphrase keyPassphrase)
                    throws SSLException {
        _logger.log(Level.INFO, " Converting private key \n" + 
                "      " + pkcs8DerKeyFile + "\n" +
                " to \n" + 
                "      " + opensslPemKeyFile );
        FilePrereqs.checkIsDerFile(pkcs8DerKeyFile);
        FilePrereqs.checkIsPemFile(opensslPemKeyFile);
        
        FilePrereqs.checkNonEmptyFile(pkcs8DerKeyFile, "convertPrivateKey, pkcs8KeyFile");
        FilePrereqs.checkNoOverwrite(opensslPemKeyFile, "convertPrivateKey opensslKeyFile");

        // See http://www.openssl.org/docs/apps/openssl.html
        
        // The distinguished name field types must be in capitals.  If you use lower case eg /cn=  get 
        // error message: Subject Attribute cn has no known NID, skipped
        final List<String> cmdargs = Arrays.asList
            ( "pkcs8", 
                "-in", pkcs8DerKeyFile.getAbsolutePath(),
                "-inform", "DER",
                "-out", opensslPemKeyFile.getAbsolutePath(),
                "-passin", "stdin"
                );



        _execOpenssl.runOpensslCommand( cmdargs, Arrays.asList(keyPassphrase.getPassphraseChars()), "convertPrivateKey");

        SSLFileUtils.checkNewlyCreatedFile(opensslPemKeyFile, "convertPrivateKey, opensslKeyFile");
   }




    /**
     * Convert private key format
     * @param pemFile 'readable' hex with header and tail line
     * @param derFile binary
     */
    public void convertKeyToDERpkcs8( 
            File pemFile, 
            File derFile,
            Passphrase keyPassphrase ) throws SSLException {
        _logger.log(Level.INFO, "Convert pem file " + 
                pemFile.getAbsolutePath() + 
                " to der " + 
                derFile);

        FilePrereqs.checkIsPemFile(pemFile);
        FilePrereqs.checkIsDerFile(derFile);
        
        FilePrereqs.checkNoOverwrite(derFile, "derFile");

        // Transmit  passphrase via a file to avoid passing on command line - which can be seen with ps
        final List<String> cmdargs = Arrays.asList
            ( "pkcs8",
                "-passin", "stdin", 
                "-topk8",
                "-nocrypt",
                "-inform", "PEM", 
                "-in", pemFile.getAbsolutePath(), 
                "-outform", "DER",
                "-out",  derFile.getAbsolutePath() 
            );



        _execOpenssl.runOpensslCommand( cmdargs, Arrays.asList(keyPassphrase.getPassphraseChars()), "convertKeyToDER");


        SSLFileUtils.checkNewlyCreatedFile(derFile, "derFile" );


   }
    
    /**
     * Convert private key file and corresponding certificate file to a PKCS12 files. 
     * @param keyFile pem format
     * @param certFile perm format
     * @param pkcs12File output file
     */
    public void convertKeyToPkcs12( 
            File keyFile, 
            File certFile,
            File combinedFile,
            File pkcs12File,
            String alias,
            Passphrase keyPassphrase ) throws SSLException {
        _logger.log(Level.INFO, "Convert key file: " + keyFile.getAbsolutePath() + 
                " and cert: " + certFile.getAbsolutePath() + " to PKCS12 file: " + pkcs12File.getAbsolutePath() );

        FilePrereqs.checkIsPemFile(keyFile);
        FilePrereqs.checkIsPemFile(certFile);
        FilePrereqs.checkNoOverwrite(combinedFile, "combinedFile");
        FilePrereqs.checkNoOverwrite(pkcs12File, "pkcs12File");
        
        try {
            final String keyString = FileUtils.readFileToString(keyFile);
            final String certString = FileUtils.readFileToString(certFile);
    
            // Write the file
            FileUtils.write(combinedFile, keyString);
            final boolean append = true;
            FileUtils.write(combinedFile, certString, append); 
        } catch(IOException e){
            throw new SSLException("Failed to combine key file and cert file", e);
        }
                
        /*
        This command also uses the openssl pkcs12 command to generate a PKCS12 KeyStore with the private key and certificate. 
        This entry contains the private key and the certificate provided by the -in argument. The 
        noiter and nomaciter options must be specified to allow the generated KeyStore to be recognized properly by JSSE.
        Transmit  passphrase via a file to avoid passing on command line - which can be seen with ps
        */
        final List<String> cmdargs = Arrays.asList
            ( "pkcs12",
                "-passin", "stdin",
                "-passout", "stdin",
                "-export",                  
                "-in", combinedFile.getAbsolutePath(), 
                "-out",  pkcs12File.getAbsolutePath(),
                "-name", alias,
                "-noiter",
                "-nomaciter"
            );



        _execOpenssl.runOpensslCommand( 
                cmdargs, 
                Arrays.asList(keyPassphrase.getPassphraseChars(), keyPassphrase.getPassphraseChars()), 
                "convertKeyToPKCS12");


        SSLFileUtils.checkNewlyCreatedFile(pkcs12File, "pkcs12File" );


   }

    /**
     * Convert public certificate format.  If both formats are the same this provides a simple 
     * certificate format validation.  Returns hash code of subject, as required for file name in trust directories. 
     * @param inCertificateSpec input file location and format
     * @param outCertificateFile output file location and format
     */
    public String convertCertificate( 
            CertificateSpec inCertificateSpec, 
            CertificateSpec outCertificateSpec ) throws SSLException {
        _logger.log(Level.INFO, "Convert certificate file " + 
                inCertificateSpec + 
                " to " + 
                outCertificateSpec);

        FilePrereqs.checkNonEmptyFile(inCertificateSpec.getCertificateFile(), "convertCertificate in");

        FilePrereqs.checkNoOverwrite(outCertificateSpec.getCertificateFile(), "convertCertificate out");



        // Transmit  passphrase via a file to avoid passing on command line - which can be seen with ps
        final List<String> cmdargs = Arrays.asList
            ( "x509", 
                "-hash",
                "-inform", inCertificateSpec.getCertificateEncoding().getOpensslFormString(), 
                "-in", inCertificateSpec.getCertificateFile().getAbsolutePath(), 
                "-outform", outCertificateSpec.getCertificateEncoding().getOpensslFormString(),
                "-out",  outCertificateSpec.getCertificateFile().getAbsolutePath()
            );


        // If command fails with status not 0, we don't want the generic command failed error.  Want to add our own advice. 
        final List<String> lines = _execOpenssl.runOpensslCommand( cmdargs, new ArrayList<char[]>(), "convertCertificate");
        

        SSLFileUtils.checkNewlyCreatedFile(outCertificateSpec.getCertificateFile(), "outCert" );
        
        if(lines.isEmpty())
        {
            if(outCertificateSpec.getCertificateFile().getAbsolutePath()!=null)
            {
                BufferedReader br;
                try 
                {
                    br = new BufferedReader(new InputStreamReader(new FileInputStream(outCertificateSpec.getCertificateFile().getAbsolutePath()), StandardCharsets.UTF_8));
                    String line = br.readLine();
                    br.close();
                    return line;
                } 
                catch (FileNotFoundException e) 
                {
                    _logger.log(Level.INFO, "Hashing failed as certificate file is not found", e.getMessage());
                }
                catch (IOException e) 
                {
                    _logger.log(Level.INFO, "Hashing failed due to error" , e.getMessage());
                }
            }
            else
            {
               throw new SSLException("Failed to get hash for: " +  inCertificateSpec.toString() );
            }
        }        
        
        return lines.get(0);
    }

    /**
     * Signs a certificate request. 
     * The ca command is used since this gives full control of the signing process. 
     * Unfortunately this means we do not have control of the output format, so 
     * x509 must be run separately if file format needs to be changed. 
     * @param caKeyPassphrase file containing password for the CA authority's key file. 
     * @param resultFile name of certificate file.  Must not exist.
     * @param days lifetime of certificate.  Note that browsers are now rejecting excessively long duration certificates.  
     * Eg Safari complains about certificates with a duration longer than 13 months.  
     */
    public void signCertificate( 
            File certRequest, 
            Passphrase caKeyPassphrase, 
            File resultFile,
            int days,
            CertificateExtensions certificateExtensions) throws SSLException {


        _logger.log(Level.INFO, "Sign certificate request " + 
                certRequest.getAbsolutePath() + 
                " resulting in certificate \n" + 
                "      " + resultFile.getAbsolutePath());
        FilePrereqs.checkIsPemFile(resultFile);
        FilePrereqs.checkNoOverwrite(resultFile, "resultFile" );

        // The sign command uses the ca defined in the openssl.cnf file.   
        // This points to the demoCA directory.      

        // -notext
        //    Do not output textual form of certificate - just output encoded between 
        //    -----BEGIN CERTIFICATE----- and 
        // -  ----END CERTIFICATE----- markers.  This format can be understood by the java keytool. 
        //
        // -batch 
        //    avoids all confirmation answers, which would block until input by user. 
        // 
        // -infiles
        //    takes 1 or more args, so must appear last in the options list or other options 
        //    will be interpretted as file names. 
        // Note explicit use of -days.  This overrides the setting in openssl.cnf, which means a customer cannot 
        // choose their own certificate lifespan via openssl.cnf.
        final List<String> cmdargs = new ArrayList<>();
        cmdargs.addAll(Arrays.asList
            ( "ca", 
                "-policy", "policy_anything", 
                "-passin", "stdin", 
                "-out",  resultFile.getAbsolutePath(), 
                "-verbose", 
                "-notext", 
                "-batch", 
                "-days", Integer.toString(days)               
                )
        );

        final List<String> subjectAlternateNames = certificateExtensions.getSubjectAlternativeNames();
        if( !subjectAlternateNames.isEmpty() ){
            // Openssl signing requires explicit extensions to be in config files even though they are already included in 
            // the signing request. 
            final File sanConfig = new File(this.getWorkingDir() + "sansigning.cnf");
            
            final List<String> lines = new ArrayList<>();
            lines.add("");
            lines.add("[ req ]");  // We can add additional entries by repeating existing section headings - avoids editing depths of default file
            lines.add("req_extensions = san_req_ext");
            lines.add("[ san_req_ext ]");
            lines.add("subjectAltName = @alt_names");
            lines.add("");
            lines.add("[alt_names]");
            int sanCounter = 1;
            for( String san : subjectAlternateNames){
                final String sanLine = "DNS." + sanCounter + " = " + san;
                lines.add(sanLine);
            }
            try {
                FileUtils.writeLines(sanConfig, lines);
            } catch (IOException e) {
                throw new SSLException("Unable to add SAN definition to " + sanConfig, e);
            }
            cmdargs.addAll(Arrays.asList
                ( "-extfile",
                  sanConfig.getAbsolutePath(),
                  "-extensions",
                  "san_req_ext"
                 )
            );
        }

        
        cmdargs.addAll(Arrays.asList
                ( "-infiles", certRequest.getAbsolutePath()
                )
        );
        
        _execOpenssl.runOpensslCommand( cmdargs, Arrays.asList(caKeyPassphrase.getPassphraseChars()), "signCertificate"); 

        SSLFileUtils.checkNewlyCreatedFile(resultFile, "resultFile");

        _logger.log(Level.INFO, "Successfully signed " + resultFile);
        
   }

    





    



}
