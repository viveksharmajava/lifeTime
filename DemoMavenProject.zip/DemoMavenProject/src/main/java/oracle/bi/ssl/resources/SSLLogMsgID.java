package oracle.bi.ssl.resources;

public class SSLLogMsgID {

    

    public static final String SSL_PING_DETAILS = "SSL_PING_DETAILS";

    
}
