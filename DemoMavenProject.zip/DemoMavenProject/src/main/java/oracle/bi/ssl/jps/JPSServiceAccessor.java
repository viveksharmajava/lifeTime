package oracle.bi.ssl.jps;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.locations.DomainLocations;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;
import oracle.security.jps.JpsContext;
import oracle.security.jps.JpsContextFactory;
import oracle.security.jps.JpsException;
import oracle.security.jps.JpsStartup;


/**
 * Access the JPS service.   When running in the WebLogic container the JPS config file will already 
 * have been defined by system property oracle.security.jps.config.  
 * 
 * For processes running in a self contained java process (JSE) we will if necessary set the property ourselves. 
 * @author pharry
 *
 */
public final class JPSServiceAccessor {
    private final static Logger logger = LoggerFactory.createLogger(JPSServiceAccessor.class);
    
    private final static String CONFIG_FILE_KEY = "oracle.security.jps.config";
    //private final static String COMMON_COMPONENTS_HOME_KEY = "common.components.home";
    
    private final DomainLocations domain;
    

    public JPSServiceAccessor(DomainLocations domain){
        if(domain == null){
            throw new IllegalArgumentException("null domain");
        }
        

        this.domain = domain;
    }

    /**
     * Bootstrap context is the local file system copy.  A non file system KeyStore service (eg a database)
     * has to be synced to the local file system copy. 
     * @return
     * @throws SSLException
     */
    public JpsContext getBootstrapJpsContext() throws SSLException {
        return getNamedJpsContext("bootstrap_credstore_context");
    }
    
    
    /**
     * By default returns the java platform security context for a standalone JSE process.
     * @return . 
     */
    public JpsContext getRuntimeJpsContext() throws SSLException {
        return getNamedJpsContext("default");
    }
    
    /**
     * 
     * If system property defining jps config file location is set (eg in WebLogic) uses that. 
     * Otherwise defaults to standalone (JSE) jps config file. 
     * @return . 
     */
    private JpsContext getNamedJpsContext(String contextName) throws SSLException {
        if( contextName == null){
            throw new IllegalArgumentException("null contextName");
        }
        
        final File jpsConfigJseFile = domain.getJpsConfigJse();
        final File jpsConfigFile = domain.getJpsConfig();
        
        

        // Setting a system property is horrid - callers do not expect java classes to overwrite their settings.  But we do not 
        // want to require user to set this obscure setting. 
        
        
        final File activeJspConfig = setJPSConfigLocation( jpsConfigJseFile, jpsConfigJseFile, jpsConfigFile);
        
        // For jps-config.xml need env variabale set to avoid audit service failure.  System property fails. 
        //final File commonComponentsHome = homes.getOracleHomeLocations().getOracleCommon();
        FilePrereqs.checkNonEmptyFile(activeJspConfig, "activeJspConfig");
        
        // Can't set this property now since it is used in static initializer of oracle.security.audit.util.AuditConstants.
        // Absence only seems to cause failure with jps-config-jse.xml for expanded domain - compact domain appears fine. 
        // So set this or equivalent environment variable COMMON_COMPONENTS_HOME in wrapper script.  
        //setConsistentProperty(COMMON_COMPONENTS_HOME_KEY, commonComponentsHome.getAbsolutePath());
        
        try {
            // Get the default context (can have multiple named contexts)
            if (activeJspConfig!=null && activeJspConfig.getAbsolutePath() != null && activeJspConfig.getAbsolutePath().endsWith("jps-config-jse.xml"))
            {   
                new JpsStartup().start();
            }

            final JpsContextFactory contextFactory = JpsContextFactory.getContextFactory();           
            
            final JpsContext context = contextFactory.getContext(contextName);
            return context;
        } catch (JpsException e) {
            throw new SSLException("Unable to get JPS context using config file " + jpsConfigFile.getAbsolutePath(), e);
        }
    }
    
    /**
     * Set the jps config file location system property - throwing if it is already set to something incompatible.  
     * Setting properties in code thus overriding properties set by the user 
     * is undesirable.  Unfortunately the JPS api does not provide an alternative mechanism.
     * @param allowedValues values we can accept
     * 
     */
    private static File setJPSConfigLocation( File defaultJseValue, File... allowedValues) throws SSLException{
        final String existingValue = System.getProperty(CONFIG_FILE_KEY);
        if( existingValue == null){   
            // Set for first time
            System.setProperty(CONFIG_FILE_KEY, defaultJseValue.getAbsolutePath() );
            logger.info("No JSE config property set, so setting to jse " + defaultJseValue.getAbsolutePath() );
            return defaultJseValue;
        } else {
            final File existingFile = new File(existingValue);
            // Compare canonical forms - otherwise use of .. or similar will confuse us. 
            File existingCanonicalFile;
            try {
                existingCanonicalFile = existingFile.getCanonicalFile();
            } catch (IOException e) {
                throw new SSLException("Unable to canonicalise jse config location " + existingFile, e);
            }
            
            for( File allowed : allowedValues){
                File allowedCanonical;
                try {
                    allowedCanonical = allowed.getCanonicalFile();
                } catch (IOException e) {
                    throw new SSLException("Unable to canonicalise expected jse config location " + allowed, e);
                }
                if( allowedCanonical.equals(existingCanonicalFile)){
                    return existingCanonicalFile;
                }
            }
            throw new IllegalArgumentException(
                    "Contradictiory configuration properties.  System property " + CONFIG_FILE_KEY + " has " + existingValue + " allowed values " + Arrays.toString(allowedValues) );
        }
    }
}
