package oracle.bi.ssl.config;

import java.net.Socket;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Objects;
import java.util.logging.Logger;

import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509ExtendedTrustManager;

import oracle.bi.ssl.logging.LoggerFactory;





/**
 * A trust manager which checks host.  Rather than encoding our own host check, which has become increasingly complex with the addition of 
 * Subject Alternate Names (SANs) including wildcards, we simply ensure that the default extended trust managers are configured to perform the 
 * additional host check.  This is done by setting a config parameter on the SSL Socket.  Unfortunately we have to wrap the 
 * whole trust manager to have an appropriate hook for modifying the SSL socket configuration. 
 * <p>
 * Extend X509ExtendedTrustManager not X509TrustManager to trigger use of the socket based checks, 
 * potentially including host checks.  The older X509TrustManager only checks certificate signing and 
 * basic validity such as date.  The need to use an ExtendedTrustManager means that this class cannot be used with our older FIPS 
 * security provider. 
 */
final class ExtendedHostTrustManager extends X509ExtendedTrustManager
{
    private static final Logger logger = LoggerFactory.createLogger(ExtendedHostTrustManager.class);
    
    private final static String HTTPS = "https";
    
    private final X509ExtendedTrustManager baseTrustManager;

    public ExtendedHostTrustManager(
            X509ExtendedTrustManager baseTrustManager)
    {
        this.baseTrustManager = Objects.requireNonNull(baseTrustManager, "null baseTrustManager");
    
    }


    

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType) 
            throws CertificateException
    {
        baseTrustManager.checkClientTrusted(chain, authType);
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType) 
            throws CertificateException
    {
        baseTrustManager.checkServerTrusted(chain, authType);
        
    }

    @Override
    public X509Certificate[] getAcceptedIssuers()
    {
        return baseTrustManager.getAcceptedIssuers();
    }
    
    
    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType, Socket socket) throws CertificateException {
        baseTrustManager.checkClientTrusted(chain, authType, socket);
        
        
    }


    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType, SSLEngine engine) throws CertificateException {
        baseTrustManager.checkClientTrusted(chain, authType, engine);
    }


    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType, Socket socket) throws CertificateException {
        
        
        // The base trust manager will check host in common name/subject alternate names/subject alternate name wildcards
        // but only if ssl parameters, endpoint identification algorithm set to https.  Check not 
        // at default of null.  
    
        if (socket.isConnected() && (socket instanceof SSLSocket)) {
            final SSLSocket sslSocket = (SSLSocket)socket;
            
            final SSLParameters parameters = sslSocket.getSSLParameters();
            final String idAlgorithm = parameters.getEndpointIdentificationAlgorithm();
            if( idAlgorithm == null){
                logger.fine("Setting endpointIdentificateionAlgorithm to " + HTTPS);
                parameters.setEndpointIdentificationAlgorithm(HTTPS);
                // The returned SSLParameters are a copy.  So must set back to take effect. 
                sslSocket.setSSLParameters(parameters);
            } else if ( !HTTPS.equalsIgnoreCase(idAlgorithm)){
                throw new CertificateException("Non '" + HTTPS + "' https identification algorithm '" + idAlgorithm + "'");
            }
        }
            
        baseTrustManager.checkServerTrusted(chain, authType, socket);
        
    }


    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType,
            SSLEngine engine) throws CertificateException {
        baseTrustManager.checkServerTrusted(chain, authType, engine);
        
    }
}
