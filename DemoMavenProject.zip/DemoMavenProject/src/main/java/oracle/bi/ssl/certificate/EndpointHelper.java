package oracle.bi.ssl.certificate;

import java.util.Objects;

import oracle.bi.endpointmanager.pub.RegisteredEndpoint;

public final class EndpointHelper {

    /**
     * No instances
     */
    private EndpointHelper(){
        
    }
    
    
    public static String getEffectiveClientListenAddress(RegisteredEndpoint endpoint){
        // Endpoint api should isolate us from this fiddle. 
        if( endpoint.getClientListenAddress() == null){
            final String ret =  endpoint.getListenAddress();
            Objects.requireNonNull(ret, "null endpoint listen address for endpoint " + endpoint);
            return ret;
        } else {
            return endpoint.getClientListenAddress();
        }
    }
}
