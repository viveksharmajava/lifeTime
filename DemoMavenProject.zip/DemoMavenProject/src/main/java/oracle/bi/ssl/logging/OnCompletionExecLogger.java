package oracle.bi.ssl.logging;


import java.util.logging.Level;
import java.util.logging.Logger;



/**
 * Echo lines to java.util.Logger in one big batch on failed or successful completion.  This avoids repeatedly 
 * prefixing each line with the same log context which makes the log file hard to read.  
 * 
 * For why every data modifying method is synchronized see ExecLogger.
 */
public final class OnCompletionExecLogger implements ExecLogger
{
   private final static String INFO_PREFIX = "[INFO]";
   private final static String WARN_PREFIX = "[WARN]";
   
   private final Logger logger;
   
   private final Level successLevel;
   private final Level failLevel;
   private final EchoMode echoMode;
   
   // Combined - stderr and stdout.  May be quite large. 
   private StringBuilder combined = new StringBuilder();
   
   // Expect to be small.  May be included in exceptions. 
   private StringBuilder stderr = new StringBuilder();
   
   
   
   /**
    * 
    * @param logger
    * @param successLevel level completion success is logged at
    * @param failLevel level completion failure is logged at
    */
   public OnCompletionExecLogger(Logger logger, EchoMode echoMode){
       this.logger = logger;
       this.successLevel = Level.INFO;
       this.failLevel = Level.SEVERE;
       this.echoMode = echoMode;
   }
  

   
   
   private static final String LS = System.getProperty("line.separator");
   
   
    private void echo(String line){
        if( echoMode == EchoMode.ECHO_INFO_TO_STD_OUT){
            // Crude but effective way of only echoing more important stuff.  WLST scripts use logging.py info method to prefix 
            //  with INFO_PREFIX/WARN_PREFIX. 
            if( line.startsWith(INFO_PREFIX)){
                 System.out.println(line.substring(INFO_PREFIX.length()));
            } else if ( line.startsWith(WARN_PREFIX)){
                 System.out.println(line.substring(WARN_PREFIX.length()));
            }
        } else if ( echoMode == EchoMode.ECHO_ALL_TO_STD_OUT){
            System.out.println(line);
        }
    }
   

    @Override
    public synchronized void stdErr(String source, String line) {
        combined.append( "["+source + "-ERR] " );
        combined.append(line);
        combined.append(LS);
        
        stderr.append(line);
        stderr.append(LS);
        
        echo(line);
    }
    
    
    @Override
    public synchronized void stdOut(String source, String line) {
        combined.append( "["+source + "-OUT]" );
        combined.append(line);
        combined.append(LS);
        
        echo(line);
    }
    
    @Override
    public synchronized void clear(){
        combined = new StringBuilder();
        stderr = new StringBuilder();
    }
    
    /**
     * Return the combined output.
     */
    @Override 
    public synchronized String toString(){
        return combined.toString();
    }
    
    @Override
    public synchronized String getStderr(){
        return stderr.toString();
    }
    
    @Override
    public synchronized void completed(boolean success) {
        final Level logLevel = success ? successLevel : failLevel;
        logger.log(logLevel, combined.toString());        
    }
}

