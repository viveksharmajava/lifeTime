package oracle.bi.ssl.config;

import java.security.KeyStore;
import java.util.logging.Logger;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509TrustManager;

import oracle.bi.ssl.logging.LoggerFactory;

/**
 * Return trust managers, either default ones or enhanced wrapper trust managers adding additional checks. 
 * 
 *
 */
public final class WrapperTrustManagerFactory {

    final private static Logger logger = LoggerFactory.createLogger(WrapperTrustManagerFactory.class);
    /**
     * No instances
     */
    private WrapperTrustManagerFactory(){
        
    }
    
    /**
     * Return trust managers which in addition to the default checks (eg certificate is signed by a trusted CA) also guarantees checks on the host name of the server. 
     * Note that even if we only use the default trust managers, clients may still configure host name checks by setting 
     * SSLParameters EndpointIdentificationAlgorithm to https on the SSLSocket.  HTTP centric clients 
     * such as Jersey do this.  Non HTTP clients, such as our own custom RPC over TCP client used 
     * to communicate from the analytics web app to OBIPS, do not. 
     * @param trustKeyStore
     * @param requiredHostname if non-null force host checks.   Host checks should be enabled for talking to any server whose identity certificate is signed 
     * by a public certificate authority (CA).  A public CA means that being signed by a CA we trust is not sufficient to ensure that this endpoint 
     * is not part of a person in the middle attack.  Identity certificates signed by a private CA do not need host name checks.  The is the CA trusted check is 
     * sufficient since we know that no outsider can have used the private CA. 
     * @return
     * @throws Exception
     */
    public static TrustManager[] getTrustManagers(
            KeyStore trustKeyStore,
            String requiredHostname) 
                    throws Exception
    {
        // Do not specify provider as "SunJSSE" since this is not available on AIX.
        final String algorithm = TrustManagerFactory.getDefaultAlgorithm();
        final TrustManagerFactory tmf = TrustManagerFactory.getInstance(algorithm);
        tmf.init(trustKeyStore);   
        final TrustManager[] trustManagers = tmf.getTrustManagers();

        wrapTrustManagers(requiredHostname, trustManagers);

        return trustManagers;
    }

    public static void wrapTrustManagers(String requiredHostname, TrustManager[] trustManagers) {
        // If hostVerification required, wrap with our trust manager which guarantees checking of the host, irrespective of whether the client sets
        // https identification algorithm on the SSLSocket.  The trust manager does this simply by setting exactly that option
        // on the incoming SSLSocket.
        if (requiredHostname != null){
            for (int i = 0; i< trustManagers.length; ++i){
                final TrustManager tm = trustManagers[i];
                if( tm instanceof X509ExtendedTrustManager){
                    // X509ExtendedTrustManagers - as used by the default JDK's security providers - do subject name validation
                    // for both common name (CN) and Subject Alternative Name (SAN) certificates.  The extended verification
                    // methods taking a socket parameter are called.
                    trustManagers[i] = new ExtendedHostTrustManager((X509ExtendedTrustManager) trustManagers[i] );
                } else if ( tm instanceof X509TrustManager ){
                    logger.fine("tm " + tm.getClass().getName() + "not an X509ExtendedTrustManager.  Providing own subject name verificaton.");
                    trustManagers[i] = new HostTrustManager(requiredHostname, (X509TrustManager) trustManagers[i]);
                } else {
                    throw new IllegalStateException("Trust manager " + tm.getClass().getName() + " not supported");
                }
            }
        }
    }

}
