package oracle.bi.ssl.certificate;


/**
 * Holds passphrases for accessing all BI SSL certificates keys and keystores. 
 *
 */

public final class Passphrases implements AutoCloseable{
    /**
     * Crown jewels - allows opening of private CA and hence signing of new certificates. Only ever used 
     * by SSL setup code.  Needed after setup to top up with new certificates for new listener addresses. 
     */
    private final Passphrase caKeyPassphrase;
    
    /**
     * Used by servers to open their private key files, and hence assert their identity. Needed by anyone asserting their identity.  
     * Will be reused if certificates are regenerated. 
     */
    private final Passphrase serverKeyPassphrase;

    
    
    public Passphrases(Passphrase caKeyPassphrase, Passphrase serverKeyPassphrase) {
        if( caKeyPassphrase == null){
            throw new IllegalArgumentException("null caKeyPassphrase");
        }
        if( serverKeyPassphrase == null){
            throw new IllegalArgumentException("null serverKeyPassphrase");
        }
        this.caKeyPassphrase = caKeyPassphrase;
        
        this.serverKeyPassphrase = serverKeyPassphrase;
        
    }

    public Passphrase getCaKeyPassphrase() {
        return caKeyPassphrase;
    }
    
    

    public Passphrase getServerKeyPassphrase() {
        return serverKeyPassphrase;
    }
    
    /**
     * Use same as the server key passphase. Having a non-null keystore passphrase prevents users from 
     * accidentally changing the internal trust and identity keystores.
     * 
     *  
     * @return
     */
    public Passphrase getKeystorePassphrase() {
        return serverKeyPassphrase;
    }
    
    /**
     * Should always be called once the passphrases are no longer required.  Avoids leaving them in memory. 
     * This is most reliably done using a try with resources block. 
     */
    @Override
    public void close(){
        caKeyPassphrase.close();
        serverKeyPassphrase.close();
    }
}
