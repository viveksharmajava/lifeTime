package oracle.bi.ssl.jps;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.ssl.certificate.CertificateReader;
import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.files.FilePermissions;
import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;


/**
 * 
 * Utilities to manipulate a single Java KeyStore - importing and exporting certificates. 
 * The Java key store is only used by Java components.  The C++ openssl runtime stack 
 * (and its certificate signing tool) manipulate individual 
 * certificates stored in separate files.  
 *
 * 
 */
final public class SingleKeyStoreAccessor implements KeyStoreAccessor
{
   private final static Logger logger = LoggerFactory.createLogger(SingleKeyStoreAccessor.class);
   private final KeyStore keyStore;
   private final File logDir;
   private final String comment;
   
   
   /**
    * Create a keystore from a file system file
    */
   public static SingleKeyStoreAccessor createFileKeyStore(File logDir, KeyStoreType keyStoreType, Passphrase passphrase, File sourceFile) throws SSLException{
       try (FileInputStream keystoreInputStream = new FileInputStream(sourceFile);){
           final KeyStore ks =  KeyStore.getInstance(keyStoreType.name());

           ks.load(keystoreInputStream, passphrase.getPassphraseChars());
           return new SingleKeyStoreAccessor("File based keystore from: " + sourceFile.getAbsolutePath(), logDir, ks);
       } catch (Exception e) {
           throw new SSLException("Unabled to create KeyStoreAccessor from file " + sourceFile.getAbsoluteFile(), e);
       }
   }
   /**
    * Create an in memory keystore which can then be saved to file by calling saveKeyStore. 
    * @return
    */
   public static SingleKeyStoreAccessor createInMemoryKeyStore(File logDir, KeyStoreType keyStoreType, Passphrase passphrase)throws SSLException{
        KeyStore ks;
        try {
            ks = KeyStore.getInstance(keyStoreType.name());
        } catch (KeyStoreException e) {
            throw new SSLException("Unable to create empty JKS keystore", e);
        }
        try {
            ks.load(null, passphrase.getPassphraseChars());
        } catch (Exception e) {
            throw new SSLException("Unable to initialize empty JKS keystore", e);
        }
        
        final SingleKeyStoreAccessor ret = new SingleKeyStoreAccessor("In memory keystore", logDir, ks);
        return ret;
   }
           
   
   /**
    * Wrap a KeyStore with convenience commands.  If the keyStore is in the keystore service then writes are automatically persisted.
    * @param comment describes where the keystore comes from.  Used in logging. 
    */   
   public SingleKeyStoreAccessor(String comment, File logDir, KeyStore keyStore) throws SSLException
   {
      this.keyStore = Objects.requireNonNull(keyStore, "null keyStore");
      this.logDir = Objects.requireNonNull(logDir, "null logDir");
      this.comment = Objects.requireNonNull(comment, "null comment");
   }
   
   public String getComment(){
       return comment;
   }
   
   @Override
   public KeyStore getKeyStore(){
       return keyStore;
   }
    
   @Override
   public void exportKeyStoreToFile(File destFile, Passphrase passphrase) throws SSLException
   {

       try (OutputStream outputStream = new FileOutputStream(destFile);){
           final char[] password = passphrase.getPassphraseChars();
           keyStore.store(outputStream, password );
           outputStream.close();
           FilePermissions.setPrivateFilePermissions(destFile);
       }
       catch(Exception e)
       {
           throw new SSLException("Failed to save keystore to file " + destFile, e);
       }
   }

   
   
   /*
    * Load a private key, in DER (binary) format with pkcs8 encoding together with its 
    * associated certificate chain in pem format. 
    */
   @Override
   public void loadPrivateKey(File keyFile, File certificateFile, Passphrase keyPassword, String alias) throws SSLException
   {
//      System.out.println("+++ Importing private key in " + keyFile.toString() + 
//         " to keystore " + _keyStoreSpec.getLocation().toString() + 
//         " alias " + alias);

      FilePrereqs.checkNonEmptyFile(keyFile, "keyFile");
      FilePrereqs.checkNonEmptyFile(certificateFile, "certificateFile");
      
      // loading Key
      final byte[] keyData = SSLFileUtils.readBinaryFile(keyFile);
      logger.info("Keyfile is of length " + keyData.length);
      KeyFactory keyFactory;
      try
      {
          keyFactory = KeyFactory.getInstance("RSA");
      }
      catch (NoSuchAlgorithmException e)
      {
          throw new SSLException("RSA algorithm does not exist", e);
      }
   
      final PKCS8EncodedKeySpec keysp = new PKCS8EncodedKeySpec( keyData );
      PrivateKey privateKey;
      try
      {
          privateKey = keyFactory.generatePrivate(keysp);
      }
      catch (InvalidKeySpecException e)
      {
          throw new SSLException("Invalid key spec in " +  keyFile, e);
      }

      // loading CertificateChain
      final Certificate cert = CertificateReader.readX509Certificate(certificateFile );
   
      
      final Certificate[] authenticationChain = new Certificate[]{ cert };
      this.loadKey(alias, privateKey, keyPassword, authenticationChain);
   
   
   }
   
   
   /**
    * Load a certificate in x509 format, into an existing keystore.
    * Allows us to sign a certificate using openssl, then load into the java world. 
    * 
    * 
    * @param certificateFile should contain a single x509 certificate
    * @param alias name for certificate entry in keystore.  This alias must be unused. 
    */
   @Override
   public void loadX509(File certificateFile, 
                               String alias) throws SSLException
   {
    
      final Certificate cert = CertificateReader.readX509Certificate(certificateFile );
      this.loadCertificate(alias, cert);
   }
   
   
   
   
   /** 
    * Load a private key, with its corresponding certificate chain.  
    * For our simple local Certificate Authority the certificate chain will consist of a 
    * single certificate - which is the corresponding public key.
    */
   @Override
   public void loadKey(String alias, Key key, Passphrase keyPassword, Certificate[] authenticationChain)
   throws SSLException
   {
       try {
           if( this.containsAlias(alias) ){
               this.keyStore.deleteEntry(alias);
           }
       } catch (KeyStoreException e) {
           throw new SSLException("Failed to delete existing key at " + alias, e);
       }

       try{
           this.keyStore.setKeyEntry(alias,
                   key,
                   keyPassword.getPassphraseChars(),
                   authenticationChain);
       } catch (KeyStoreException e) {
           throw new SSLException("Failed to store key at " + alias, e);
       }


   }
   
   /**
    * Writes summary of keystore, listing alias and the certificate subjects. 
    * @param w destination.  Will not be closed. 
    */
   @Override
   public void dumpKeyStoreDiagnostics(Writer w) throws SSLException{
       // Beware wrapping writer (eg with PrintWriter - must not close the underlying writer. 
       try {
            w.write("Key store: " + this.comment + "\n");
            final Enumeration<String> enumeration = this.keyStore.aliases();
            
            // Sort first - the number of certs can be large, and dumping in arbitrary order makes things needlessly hard
            final SortedSet<String> sortedAliasses = new TreeSet<>();
            while( enumeration.hasMoreElements()){
                final String alias = enumeration.nextElement();
                sortedAliasses.add(alias);
            }
            
            for( String alias: sortedAliasses){
                w.write("  " + alias);
                final Certificate certificate = this.keyStore.getCertificate(alias);
                if( certificate instanceof X509Certificate ){
                    final X509Certificate x509Certificate = (X509Certificate)certificate;
                    w.write("\n    Subject: " + x509Certificate.getSubjectDN());
                    w.write("\n    Issuer: " + x509Certificate.getIssuerDN());
                }else {
                    w.write("Certificate of type: " + certificate.getClass().getName());
                }
                if(keyStore.isKeyEntry(alias)){
                    w.write(" - key");
                }
                // keyStore.
                w.write("\n");
            }
       }catch (IOException | KeyStoreException e){
           throw new SSLException("Failed to dump key store contents", e);
       }
   }
   
   
   @Override
   public Set<Principal> getCertificateSubjects() throws SSLException{
       final Set<Principal> ret = new HashSet<>(); 
       try {
            final Enumeration<String> enumeration = this.keyStore.aliases();
            while( enumeration.hasMoreElements()){
                final String alias = enumeration.nextElement();
                final Certificate certificate = this.keyStore.getCertificate(alias);
                if( certificate instanceof X509Certificate ){
                    final X509Certificate x509Certificate = (X509Certificate)certificate;
                    ret.add(x509Certificate.getSubjectDN());
                }
            }
            return ret;
       }catch (KeyStoreException e){
           throw new SSLException("Failed to enumerate key store certificates", e);
       }
   }
   
   
   /**
    * Load a single trusted certificate
    * @param alias local name
    * @param certificate 
    * @throws SSLException
    */
   @Override
   public void loadCertificate( String alias, Certificate certificate) throws SSLException
   {  
         try{            
             keyStore.setCertificateEntry(alias, certificate);
         } 
         catch (KeyStoreException e){
            throw new SSLException("Failed to load certificate at " + alias, e);
         }
   }


   public boolean containsAlias(String targetAlias) throws SSLException {
    /*
     
      keyStore.containsAlias( unknown alias)  throws:
      
      java.lang.NullPointerException
        at oracle.security.jps.internal.keystore.util.KeyStoreServiceUtil.getTarget(KeyStoreServiceUtil.java:1280)
        at oracle.security.jps.internal.keystore.provider.FarmKeyStoreSpi.engineContainsAlias(FarmKeyStoreSpi.java:141)
        at java.security.KeyStore.containsAlias(KeyStore.java:1242)
        at oracle.bi.ssl.jps.SingleKeyStoreAccessor.containsAlias(SingleKeyStoreAccessor.java:237)
        at oracle.bi.ssl.jps.MirroredKeyStoreAccessor.containsAlias(MirroredKeyStoreAccessor.java:140)
        at oracle.bi.ssl.certificate.IdentityFactory.createJavaIdentityCertificate(IdentityFactory.java:412)
        at oracle.bi.ssl.certificate.IdentityFactory.createIdentityCertificatesForListenerAddresses(IdentityFactory.java:363)
        at oracle.bi.ssl.certificate.IdentityFactory.topUpCertificatesImpl(IdentityFactory.java:256)
        at oracle.bi.ssl.certificate.IdentityFactory.topUpCertificates(IdentityFactory.java:148)
        at oracle.bi.ssl.commands.SSLCommand.mainEx(SSLCommand.java:206)
        at oracle.bi.ssl.commands.SSLCommand.main(SSLCommand.java:52)

     same for isKeyEntry
      at oracle.security.jps.internal.keystore.util.KeyStoreServiceUtil.getTarget(KeyStoreServiceUtil.java:1280)
        at oracle.security.jps.internal.keystore.provider.FarmKeyStoreSpi.engineIsKeyEntry(FarmKeyStoreSpi.java:344)
        at java.security.KeyStore.isKeyEntry(KeyStore.java:1282)
        at oracle.bi.ssl.jps.SingleKeyStoreAccessor.containsAlias(SingleKeyStoreAccessor.java:256)
        at oracle.bi.ssl.jps.MirroredKeyStoreAccessor.containsAlias(MirroredKeyStoreAccessor.java:140)
        at oracle.bi.ssl.certificate.IdentityFactory.createJavaIdentityCertificate(IdentityFactory.java:412)
        at oracle.bi.ssl.certificate.IdentityFactory.createIdentityCertificatesForListenerAddresses(IdentityFactory.java:363)
        at oracle.bi.ssl.certificate.IdentityFactory.topUpCertificatesImpl(IdentityFactory.java:256)
        at oracle.bi.ssl.certificate.IdentityFactory.topUpCertificates(IdentityFactory.java:148)
        at oracle.bi.ssl.commands.SSLCommand.mainEx(SSLCommand.java:206)
        at oracle.bi.ssl.commands.SSLCommand.main(SSLCommand.java:52)

     */
    try {
        //return keyStore.containsAlias(alias);
        //return keyStore.isKeyEntry(alias);
        
        final Enumeration<String> aliasesEnumeration = keyStore.aliases();
        while( aliasesEnumeration.hasMoreElements()){
            String alias = aliasesEnumeration.nextElement();
            if( alias.equals(targetAlias)){
                return true;
            }
        }
        return false;
    } catch (KeyStoreException e) {
        throw new SSLException("Unable to check contains alias " + targetAlias + " due to " + e, e);
    }
}

@Override
public void dumpKeyStoreDiagnosticsToFile(String name){
    // Want to get as much diagnostics as possible, so do not give up on exceptions. 
    final File summaryFile = new File(logDir, name + ".txt");
    logger.info("Keystore implemented by " + this.keyStore.getClass().getName());
    try( 
        final OutputStream os = new FileOutputStream(summaryFile);
        final OutputStreamWriter osw = new OutputStreamWriter(
                os,
                Charset.defaultCharset()/*make it explicit that we're relying on default encoding*/);
        final BufferedWriter bw = new BufferedWriter(osw);){
        logger.info("Dumping key store summary to " + summaryFile.getAbsolutePath());
        this.dumpKeyStoreDiagnostics(bw);
    } catch (RuntimeException e){
        logger.log(Level.SEVERE, "Failed to dump KeyStore summary to file due to RuntimeException" + summaryFile.getAbsolutePath(), e);
        throw e;
    } catch (Exception e){
        logger.log(Level.SEVERE, "Failed to dump KeyStore summary to file " + summaryFile.getAbsolutePath(), e);
    }
    
    // Can't dump key store since 
    // oracle.security.jps.internal.keystore.provider.FarmKeyStoreSpi.engineStore(FarmKeyStoreSpi.java:595)
    // throws java.io.IOException: Method not implemented
    
    
    
    
}
   
   
   
}
