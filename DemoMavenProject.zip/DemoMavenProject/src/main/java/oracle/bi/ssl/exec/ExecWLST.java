package oracle.bi.ssl.exec;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.pub.SSLException;


/**
 * Invokes WLST command.  WLST commands are invoked via script rather than directly running a Jython interpretter in 
 * the java process.  This ensures that we get the same environment. 
 */
public final class ExecWLST 
{
   // OS dependent arguments
   private final List<String> _launchArgs;   
   
   private final File _workingDir;
   private final ExecLogger _execLogger;
   
   
   
   /**
    * Initialize location of executable
    * @throws SSLException 
    */
   public ExecWLST(Homes homes, File workingDir, ExecLogger execLogger) throws SSLException  {      
      _execLogger = execLogger;
            
      FilePrereqs.checkDirExists(workingDir, "workingDir"); 
      _workingDir = workingDir;
            
      final File binDir = new File(homes.getOracleHomeLocations().getOracleHome(), "/oracle_common/common/bin");
      final Executable executable = new Executable(new File(binDir, "wlst.sh"), new File(binDir, "wlst.cmd"));
      _launchArgs = executable.getExecutableLaunchArgs();      
   }
   
       
   /**
    * Run wlst command. 
    * @param args command line arguments
    * @param inputs security sensitive inputs passed via stdin
    * @comment Included at trace level. So not translated. 
    * @return stdout lines
    */
   public List<String> runWLSTCommand(
                                        List<String> args, 
                                        List<char[]>inputs,
                                        String comment) throws SSLException{     
      final List<String> cmdArgs = new ArrayList<String>();
      cmdArgs.addAll(_launchArgs);
      cmdArgs.addAll(args);
     
      final Map<String, String> env = new HashMap<String, String>();
      
      _execLogger.clear();
      final Exec exec = new Exec(_execLogger);
      final ExecResult execResult = exec.runCommandSynchronously(_workingDir, new ProcessKiller(), env, cmdArgs, comment, inputs);      
      
      return execResult.getLines();
   }
}


