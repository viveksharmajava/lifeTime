package oracle.bi.ssl.resources;

import java.util.ListResourceBundle;



public class SSLLogMsg extends ListResourceBundle{

    @Override
    protected Object[][] getContents()
    {
        return contents;
    }
 
    static final Object[][] contents =
    {

        {SSLLogMsgID.SSL_PING_DETAILS,
             "Dumping certificate chain and CA certificate after failure to connect to {0}:{1} using trust directory {2}.  "},
       
    };
    
}
