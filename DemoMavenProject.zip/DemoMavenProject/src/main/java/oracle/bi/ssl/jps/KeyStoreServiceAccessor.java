package oracle.bi.ssl.jps;



import java.io.File;
import java.security.AccessControlException;
import java.security.KeyStore;
import java.security.UnrecoverableKeyException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.locations.DomainLocations;
import oracle.bi.ssl.locations.KeystoreNames;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;
import oracle.security.jps.JpsContext;
import oracle.security.jps.JpsException;
import oracle.security.jps.service.keystore.KeyStoreService;
import oracle.security.jps.service.keystore.KeyStoreServiceException;

/**
 * Provides access to the JPS keystore service.  This holds multiple keystores identified by separate stripes and id. 
 * You can see these in the EM UI by right clicking the domain node, select security, keystore. 
 * See 
 *     http://docs.oracle.com/middleware/1213/idm/app-security/devkss.htm
 *     http://docs.oracle.com/cd/E27559_01/apirefs.1112/e27155/oracle/security/jps/service/keystore/KeyStoreService.html
 *     
 * In a compact domain the JPS stores, including the keystore, are held in local files.  This single KeyStore is only 
 * referenced by the default JPS context.  It is not referenced by the bootstrap_credstore_context. 
 * 
 * In an expanded domain the JPS stores, including the keystore, are held in the database.  WebLogic uses a file based 
 * copy.  The file based copy has to be manually synced using the WLST syncKeyStores function.  Function syncKeyStores is only 
 * available online - and requires a restart for any changes to take effect. 
 * 
 * The default JPS context points to the db keystore service.
 * The bootstrap_credstore_context points to the file based copy.
 *     <jpsContext name="bootstrap_credstore_context">
 *        <serviceInstanceRef ref="bootstrap.credstore"/>
 *        <serviceInstanceRef ref="keystore"/>
 *     </jpsContext>
 *     
 * We avoid having to call the syncKeyStores function by syncing as we go - simply by writing to both bootstrap and default (db) keystores. 
 */
public final class KeyStoreServiceAccessor {
    private final static Logger logger = LoggerFactory.createLogger(KeyStoreServiceAccessor.class);
    
    private final static String PUBLICCACERTS = "publiccacerts";
    private final static String SYSTEM = "system";
    
    /**
     * We do not want to accidentally create one of the standard keystores. 
     *
     */
    public enum KeyStoreCreationMode {ALLOW_CREATE, NO_CREATE};
    
    
    private final KeyStoreService primaryKeyStoreService;
    private final String primarySource;
    
    /**
     * May be null.  In compact domain there is no mirror -  only a file based primary. 
     */
    private final KeyStoreService bootstrapKeyStoreService;
    private final String bootstrapSource;
    
    private final KeystoreNames keystoreNames;

    private final File logDir;
    
    /** If Keystore is in bootstrap context, return that.  Otherwise use runtime one. 
     * 
     */
    public KeyStoreServiceAccessor(DomainLocations domain) throws SSLException{
        final JPSServiceAccessor jps = new JPSServiceAccessor(domain);
        final JpsContext jpsRuntimeContext = jps.getRuntimeJpsContext();
        primaryKeyStoreService = jpsRuntimeContext.getServiceInstance(KeyStoreService.class);
        if( primaryKeyStoreService == null){
            throw new SSLException("Failed to get KeyStore service instance from JPS context " + jpsRuntimeContext.getName());
        }
        primarySource = "Default JPS keystore service: " + primaryKeyStoreService.getName();
        
        final JpsContext jpsBootstrapContext = jps.getBootstrapJpsContext();
        
        bootstrapKeyStoreService = jpsBootstrapContext.getServiceInstance(KeyStoreService.class);   
        
        if( bootstrapKeyStoreService == null){
            logger.info("No keystore in bootstrap JPS context (expected case for compact domain).");
            bootstrapSource = null;
        } else {
            bootstrapSource = "Bootstrap JPS keystore service: " + bootstrapKeyStoreService.getName();
        }
        
        keystoreNames = new KeystoreNames();
        logDir = domain.getBILogs();
    }
    
   

    /**
     * In the EM (Fusion Middle ware control) this is known as the KSS://system/trust keystore.  It is the default 
     * out the box trust store configured to be use by all WebLogic servers. 
     * @return
     * @throws SSLException
     */
    public KeyStoreAccessor getDomainTrustKeyStore() throws SSLException {
        try {
            final KeyStore trustStore = primaryKeyStoreService.getDomainTrustStore();            
            final KeyStoreAccessor primaryTrustStoreAccessor = 
                    new SingleKeyStoreAccessor(primarySource + " system/trust", logDir, trustStore);
            
            final KeyStoreAccessor bootstrapTrustStoreAccessor;
            if( bootstrapKeyStoreService == null){
                bootstrapTrustStoreAccessor = null;
            } else {
                final KeyStore mirroredTrustStore = bootstrapKeyStoreService.getDomainTrustStore();
                bootstrapTrustStoreAccessor = 
                        new SingleKeyStoreAccessor(bootstrapSource + " system/trust", logDir, mirroredTrustStore);
            }
            
            return new MirroredKeyStoreAccessor(primaryTrustStoreAccessor, bootstrapTrustStoreAccessor);
        } catch (JpsException e) {
            throw new SSLException("Failed to read trust store", e);
        } 
    }
    
    /**
     * Look up keystore
     * @return null if keystore does not exist.
     * @throws SSLException
     */
    public KeyStoreAccessor getSystemPubliccacertsKeyStore() throws SSLException {
        try {
            final KeyStore trustStore = getOptionalKeyStore(primaryKeyStoreService, SYSTEM, PUBLICCACERTS);   
            if( trustStore == null){
                logger.warning("No " + SYSTEM +"/" + PUBLICCACERTS + " keystore in default keystore service");
                return null;
            }
            final KeyStoreAccessor primaryTrustStoreAccessor = 
                    new SingleKeyStoreAccessor(primarySource + " system/publiccacerts", logDir, trustStore);
            
            final KeyStoreAccessor bootstrapTrustStoreAccessor;
            if( bootstrapKeyStoreService == null){
                bootstrapTrustStoreAccessor = null;
            } else {
                
                final KeyStore bootstrapTrustStore = getOptionalKeyStore(bootstrapKeyStoreService, SYSTEM, PUBLICCACERTS);
                if( bootstrapTrustStore == null){
                    logger.warning("No " + SYSTEM +"/" + PUBLICCACERTS + " keystore in default keystore service");
                    bootstrapTrustStoreAccessor = null;
                } else {
                    bootstrapTrustStoreAccessor = 
                        new SingleKeyStoreAccessor(bootstrapSource + " system/publiccacerts", logDir, bootstrapTrustStore);
                }
            }
            
            return new MirroredKeyStoreAccessor(primaryTrustStoreAccessor, bootstrapTrustStoreAccessor);
        } catch (JpsException e) {
            throw new SSLException("Failed to read trust store", e);
        } 
    }
    
    /**
     * User may have deleted a keystore.  Rather than throwing an KeyStoreServiceException/IOException, check existence first. 
     * @param keyStoreService
     * @param name
     * @return null if named keystore does not exist
     * @throws AccessControlException 
     * @throws KeyStoreServiceException 
     */
    private KeyStore getOptionalKeyStore(KeyStoreService keyStoreService, String map, String name) throws KeyStoreServiceException, AccessControlException{
        final String[] keystores = keyStoreService.listKeyStores(map);
        final List<String> keystoresList = Arrays.asList(keystores);
        
        if(keystoresList.contains(name)){
            return keyStoreService.getKeyStore(map,  name, null);
        } else {
            return null;
        }
        
    }

    /**
     * A new identity keystore created for internal use only. 
     * @param keystorePassphrase
     * @param stripe which stripe to use.  Non default stripes are currently only used for testing. If null use default. 
     * @return
     * @throws SSLException
     */
    public KeyStoreAccessor getBIIdentityKeyStore(Passphrase keystorePassphrase, String stripe) 
            throws SSLException {
        final String defaultedStripe = (stripe == null) ? keystoreNames.getDefaultBiStripe() : stripe;
        final String name = keystoreNames.getBIIdentityKeyStoreName();
        return getKeyStoreAccessor(defaultedStripe, name, keystorePassphrase, KeyStoreCreationMode.ALLOW_CREATE);
    }

    
    private void deleteKeyStore(Passphrase keystorePassphrase, String stripe, String name) throws SSLException {
        final KeyStore.PasswordProtection protection = new KeyStoreProtection(keystorePassphrase).getProtection();
        deleteFromKeyStoreService(primaryKeyStoreService, protection, stripe, name);
        if( bootstrapKeyStoreService != null){
            deleteFromKeyStoreService(bootstrapKeyStoreService, protection, stripe, name);
        }
    }
    
    /**
     * 
     * @param keystorePassphrase
     * @param stripe if null use default stripe.
     */
    public void deleteBIInternalKeyStores(Passphrase keystorePassphrase, String stripe) throws SSLException{
        final String defaultedStripe = (stripe == null) ? keystoreNames.getDefaultBiStripe() : stripe;
        deleteKeyStore(keystorePassphrase, defaultedStripe, keystoreNames.getBIInternalTrustKeyStoreName());
        deleteKeyStore(keystorePassphrase, defaultedStripe, keystoreNames.getBIIdentityKeyStoreName());
    }
    
  
    
    /**
     * If keystore exists, delete it. 
     * @param service
     * @param protection
     * @param stripe
     * @param name
     * @throws SSLException
     */
    private static void deleteFromKeyStoreService(KeyStoreService service, KeyStore.PasswordProtection protection, String stripe, String name)
    throws SSLException{
        
        // Cannot check existence up front - see comment in getKeyStore
        boolean exists;
        try {
            service.getKeyStore(stripe, name, protection);
            exists = true;
            
        } catch (KeyStoreServiceException e){
            // If caused by protection exception (access control for non passphrase, last thing we want to do is further complicate matters by trying to create the 
            // keystore.  
            if( causedByAccessControlException(e)){
                throw new SSLException("Keystore " + stripe + " - " + name + " cannot be accessed due to access control exception", e);
            } else if ( causedByPassphraseException(e) ){
                throw new SSLException("Keystore " + stripe + " - " + name + " cannot be accessed due to passphrase", e);
            } else {
                // Assume does not exist.  So do not need to delete. 
                exists = false;
            }
        }
        
        if( exists){
            try {
                service.deleteKeyStore(stripe, name, protection);
            } catch (KeyStoreServiceException | AccessControlException e) {
                throw new SSLException("Unable to delete keystore " + name + " in stripe " + stripe + " due to " + e, e);
            }
        }  
    }
    
    
    /**
     * Trust store which only stores our internal BI internal CA . 
     * @param keystorePassphrase
     * @param stripe which stripe to use.  Non default stripes are currently only used for testing.  If null use default. 
     * @return
     * @throws SSLException
     */
    public KeyStoreAccessor getBIInternalTrustKeyStore(Passphrase keystorePassphrase, String stripe) 
            throws SSLException {
        final String defaultedStripe = (stripe == null) ? keystoreNames.getDefaultBiStripe() : stripe;
        final String name = keystoreNames.getBIInternalTrustKeyStoreName();
        return getKeyStoreAccessor(defaultedStripe, name, keystorePassphrase, KeyStoreCreationMode.ALLOW_CREATE);

    }

    
    
    /**
     * Return the WebLogic demo identity keystore
     * @param keystorePassphrase
     * @return
     * @throws SSLException
     */
    public KeyStoreAccessor getDemoIdentityKeyStore(Passphrase keystorePassphrase) 
            throws SSLException {
        final String stripe = keystoreNames.getSystemStripe();
        final String name = keystoreNames.getDemoIdentityKeyStoreName();
        return getKeyStoreAccessor(stripe, name, keystorePassphrase, KeyStoreCreationMode.NO_CREATE);
    }
    
    
    
    
    /**
     * Note there are convenience methods for well known keystores. 
     * @param stripe
     * @param keyStoreName
     * @param keyStorePassphrase
     * @return
     * @throws SSLException
     */
    public KeyStoreAccessor getKeyStoreAccessor(
            String stripe, 
            String keyStoreName, 
            Passphrase keyStorePassphrase, 
            KeyStoreCreationMode creationMode) throws SSLException {
        final KeyStoreAccessor primaryKeyStore = getOrCreateKeyStore(this.primarySource, this.primaryKeyStoreService, stripe, keyStoreName, keyStorePassphrase, creationMode);
        
        final KeyStoreAccessor mirroredKeyStore;
        if( bootstrapKeyStoreService == null){
            mirroredKeyStore = null;
        } else {
            mirroredKeyStore = getOrCreateKeyStore(this.bootstrapSource, this.bootstrapKeyStoreService, stripe, keyStoreName, keyStorePassphrase, creationMode);
        }
        
        return new MirroredKeyStoreAccessor(primaryKeyStore, mirroredKeyStore);
    }
    
    /**
     * Returns all keystore names in the form stripe/name
     */
    public Set<String> getKeyStores() throws SSLException{
        // listKeyStores has a strange API with special behaviour if stripe name is "*"
        final String[] names;
        try {
            names = primaryKeyStoreService.listKeyStores("*");
        } catch (KeyStoreServiceException | AccessControlException e) {
            throw new SSLException("Cannot list keystores", e);
        }
        final Set<String> ret = new HashSet<String>();
        for(String name: names){
            ret.add(name);
        }
        return ret;
    }
    
    /**
     * Read only peaking behind the one consistent service api.   primarily for testing. 
     */
    public boolean isMirrored(){
        return bootstrapKeyStoreService != null;
    }
    
    
    /**
     * Return a keystore, if necessary initializing it.  Does not clear out any existing content. 
     * 
     * @param keyStorePassphrase if null, KeyStore is protected by policy (ie code grants) not passphrase
     * @return
     * @throws SSLException
     * @throws KeyStoreServiceException
     * @throws AccessControlException
     */
    private  KeyStoreAccessor getOrCreateKeyStore(
            String source,
            KeyStoreService keyStoreService, 
            String stripe, 
            String keyStoreName, 
            Passphrase keyStorePassphrase,
            KeyStoreCreationMode creationMode) 
            throws SSLException {

        
        final KeyStoreProtection keyStoreProtection = new KeyStoreProtection(keyStorePassphrase);
        
        // If a keystore does not exist get a KeyStoreServiceException.  We would like to check up front since 
        // there are many other reasons, including lack of code grants, that prevent key store access.  Unfortunately 
        // while we can list keystores in a stripe cannot list stripes.  Listing keystores requires read access to all the 
        // keystores.  Minimizing code grants to only allow access to specific keystores means that keyStoreService.listKeyStores should 
        // not be used. 
        
        
        
        // oracle.security.jps.service.keystore.KeyStoreServiceException: JPS-06562: Failed to load the keystore.
        //
        try {
            final KeyStore existingKeyStore = keyStoreService.getKeyStore(stripe, keyStoreName, keyStoreProtection.getProtection());
            return new SingleKeyStoreAccessor(source, logDir, existingKeyStore);
        } catch (KeyStoreServiceException e){
            // If caused by protection exception (access control for non passphrase, last thing we want to do is further complicate matters by trying to create the 
            // keystore.  
            if( causedByAccessControlException(e)){
                throw new SSLException("Keystore " + stripe + " - " + keyStoreName + " cannot be accessed due to access control exception", e);
            } else if ( causedByPassphraseException(e) ){
                throw new SSLException("Keystore " + stripe + " - " + keyStoreName + " cannot be accessed due to passphrase", e);
            } else {
                // Assume does not exist.  Create (if this fails then there is different problem which will propagate). 
                if( creationMode == KeyStoreCreationMode.NO_CREATE){
                    throw new IllegalStateException("Expected existing keystore " + stripe + " - " + keyStoreName + " not found");
                }
                // We require that all our new keystores have password protection. 
                if( keyStoreProtection.getProperties().isPermissionProtected() ){
                    throw new IllegalStateException("Attempt to create new keystore " + stripe + " - " + keyStoreName + " with only policy protection");
                }
                // If keystore already exists get:
                // oracle.security.jps.service.keystore.KeyStoreServiceException: JPS-06501: Keystore internalssl in stripe OBI already exists
                try {
                    keyStoreService.createKeyStore(stripe,  keyStoreName,  keyStoreProtection.getProtection(), keyStoreProtection.getProperties());
                    final KeyStore newKeyStore = keyStoreService.getKeyStore(stripe, keyStoreName, keyStoreProtection.getProtection());
                    return new SingleKeyStoreAccessor(source, logDir, newKeyStore);
                } catch (KeyStoreServiceException  eFollowOn) {
                    final SSLException reportedException = new SSLException("Failed to access key store", e);
                    reportedException.addSuppressed(eFollowOn);
                    throw reportedException;
                }
            } 
        }


    }

    private static boolean causedByPassphraseException(Throwable e){
        if ( e instanceof UnrecoverableKeyException){
            return true;
        }
        
        final Throwable cause = e.getCause();
        if( cause == null){
            return false;
        } 
        
        return causedByPassphraseException(cause);
    }
    
    /**
     * Access control exceptions may be underlying cause - but may be nested deeply
     * @param e
     * @return
     */
    private static boolean causedByAccessControlException(Throwable e){
        if ( e instanceof AccessControlException){
            return true;
        }
        
        final Throwable cause = e.getCause();
        if( cause == null){
            return false;
        } 
        
        return causedByAccessControlException(cause);
    }
    


}
