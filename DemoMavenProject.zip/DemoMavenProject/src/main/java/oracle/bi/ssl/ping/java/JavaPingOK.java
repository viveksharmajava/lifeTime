package oracle.bi.ssl.ping.java;

import java.io.ByteArrayInputStream;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;

import oracle.bi.ssl.certificate.CertificateSubjectNames;





public final class JavaPingOK extends JavaPingResult{
    
    private final SSLSession _sslSession;
    
    public JavaPingOK(SSLSession sslSession){
        super(JavaSSLState.SSL_OK);
        if( sslSession == null){
            throw new IllegalStateException("null sslSession");
        }
        _sslSession = sslSession;
    }
    
    public SSLSession getSSLSession(){
        return _sslSession;
    }
    
    @Override
    public String getSummary() {
        final StringBuilder buff = new StringBuilder();
        buff.append(getSSLState().getMessage());
       
        buff.append("\n    ");
        buff.append("Protocol: " + getSSLSession().getProtocol());
        buff.append(". Cipher: " + getSSLSession().getCipherSuite());
        if( getSSLSession().getLocalCertificates() == null){
            buff.append(". One way SSL.  ");
        } else {
            buff.append(". Two way SSL.  ");
        }
        buff.append("\n    ");
        final javax.security.cert.X509Certificate[] peerCerts;
        try {
            peerCerts = getSSLSession().getPeerCertificateChain();
            // The peers own certificate is first
            if(peerCerts!=null)
            {
                if( peerCerts.length == 0){
                    buff.append("No peer certificate");
                } else {
                    final javax.security.cert.X509Certificate peerCert = peerCerts[0];
                    buff.append("Peer certificate: " );
                    buff.append("\n     - ");
                    buff.append( toBasicCertSummary(peerCert));
                    buff.append("\n     - ");
                    buff.append( toAdvancedCertSummary(peerCert));
                }
            }
        } catch (UnsupportedOperationException e) {
            try {
                Certificate[] pCerts =  getSSLSession().getPeerCertificates();
                if(pCerts!=null)
                {
                    if( pCerts.length == 0){
                        buff.append("No peer certificate");
                    } else {
                        final Certificate pCert = pCerts[0];
                        //converting Certificate to X509Certificate format
                        CertificateFactory cf = CertificateFactory.getInstance("X.509");
                        ByteArrayInputStream inputstream = new ByteArrayInputStream(pCert.getEncoded());
                        X509Certificate x509 =  (X509Certificate) cf.generateCertificate(inputstream);
                        buff.append("Peer certificate: " );
                        buff.append("\n     - ");
                        buff.append( toBasicCertSummary(x509));
                        buff.append("\n     - ");
                        buff.append( toCertSummary(x509));
                    }
                }
            } catch (CertificateEncodingException e1) {
                buff.append("Certificate Encoding Exception" + e1.getMessage());
            } catch (CertificateException e1) {
                buff.append("CertificateException" + e1.getMessage());
            } catch (SSLPeerUnverifiedException e1) {
                buff.append("Peer not verified");
            }
        } catch (SSLPeerUnverifiedException e) {
            buff.append("Peer not verified");
        }
        
        return buff.toString();
    }
    
    /**
     * Return key information from the certificate, using just the javax.security.cert fields.  If anything goes wrong, return a brief error message. 
     * In a diagnostic tool better to report and keep going than give up immediately. 
     * @param javaxX509Cert
     * @return
     */
    private String toBasicCertSummary(javax.security.cert.X509Certificate javaxX509Cert){
        final StringBuilder buff = new StringBuilder();
        buff.append("Subject: ");
        buff.append(javaxX509Cert.getSubjectDN());
        buff.append(". ");
        
        buff.append("Issuer: ");
        buff.append(javaxX509Cert.getIssuerDN());
        buff.append(". ");
        return buff.toString();
    }
    
    private String toBasicCertSummary(java.security.cert.X509Certificate javaxX509Cert){
        final StringBuilder buff = new StringBuilder();
        buff.append("Subject: ");
        buff.append(javaxX509Cert.getSubjectDN());
        buff.append(". ");
        
        buff.append("Issuer: ");
        buff.append(javaxX509Cert.getIssuerDN());
        buff.append(". ");
        return buff.toString();
    }
    
    private String toAdvancedCertSummary(javax.security.cert.X509Certificate javaxX509Cert){   
        // Unfortunately the advanced options are only readable from the more recent java.security.cert.X509Certificate - 
        // note the java not javax.  So convert.
        CertificateFactory certificateFactory;
        try {
            certificateFactory = CertificateFactory.getInstance("X.509");
        } catch (CertificateException e) {
            return "Failed to get cert factory: " + e.getMessage();
        }

        java.security.cert.X509Certificate modernX509Cert;
        try
        {
            final ByteArrayInputStream bais = new ByteArrayInputStream(javaxX509Cert.getEncoded());
            modernX509Cert = (java.security.cert.X509Certificate) certificateFactory.generateCertificate(bais);
        }
        catch (Exception e)
        {
            return "Bad certificate binary format " + e.getMessage();
        }

        return toCertSummary(modernX509Cert);
    }
    
    private String toCertSummary(java.security.cert.X509Certificate modernX509Cert){
        final CertificateSubjectNames certificateSubjectNames = new CertificateSubjectNames(modernX509Cert);
        return "Subject Alternative Names: " + certificateSubjectNames.getSANSummary();
    }
    
    @Override
    public String toString()
    {
       final StringBuilder stringBuilder = new StringBuilder();
       stringBuilder.append(getSSLState().getMessage() );
       
      
       if(_sslSession != null){
           stringBuilder.append("\n");
           stringBuilder.append( sessionSummary(_sslSession));
       }
       
       return stringBuilder.toString();
     
    }
}
