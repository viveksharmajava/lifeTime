package oracle.bi.ssl.jps;

import java.security.KeyStore;

import oracle.bi.ssl.certificate.Passphrase;
import oracle.security.jps.service.keystore.KeyStoreProperties;

/**
 * Creates the protection fields necessary to create or access a keystore.
 * 
 *
 */
public final class KeyStoreProtection {
    private final KeyStore.PasswordProtection protection;
    private final KeyStoreProperties properties = new KeyStoreProperties();
    
    public KeyStoreProtection(Passphrase keyStorePassphrase){
        if( keyStorePassphrase == null){
            // Keystore protected by policy, so passphrase (which must still not be null) ignored.
            protection = new KeyStore.PasswordProtection("".toCharArray());
            properties.setPermissionProtected(true);
        } else {
            final char[] chars = keyStorePassphrase.getPassphraseChars();
            if( chars == null){
                throw new IllegalArgumentException("null passphrase");
            }
            if( chars.length == 0){
                throw new IllegalArgumentException("empty passphrase");
            }
            protection = new KeyStore.PasswordProtection(chars);
            properties.setPermissionProtected(false);
        }
        
    }
    
    
    public KeyStore.PasswordProtection getProtection(){
        return protection;
    }
    
    public KeyStoreProperties getProperties(){
        return properties;
    }
}
