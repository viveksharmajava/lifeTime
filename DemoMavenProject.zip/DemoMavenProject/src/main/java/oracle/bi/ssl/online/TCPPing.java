package oracle.bi.ssl.online;

import java.io.IOException;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.endpointmanager.pub.RegisteredEndpoint;
import oracle.bi.ssl.logging.LoggerFactory;

/**
 * Perform a low level TCP ping.  Does not perform any SSL handshake, and does not send any application level payload, 
 * This makes the ping cheap and simple.  A timeout is applied so that a dead machine will not result in a long wait. 
 * Machines which are alive will return quick connection refusals from the operating system if no process is listening on the port. 
 * 
 *
 */
public final class TCPPing {
    private final static Logger logger = LoggerFactory.createLogger(TCPPing.class);
    
    public boolean isReachableEndpoint(RegisteredEndpoint endpoint){
        final URL url = endpoint.getURL();
        return isReachable(url.getHost(), url.getPort());
    }
    
    /**
     * java.net.ConnectException
     * java.net.UnknownHostException
     * java.net.SocketTimeoutException
     * @param host
     * @param port
     * @return
     */
    public boolean isReachable(String host, int port){
        
        // We want to know if the server is listening, irrespective of whether it is using SSL or not.  
        // If using ssl we might not know the certificates 
        try (Socket socket = new Socket();){
            final int timeoutMillisecs = 2000; 
            // This limits the time allowed to establish a connection in the case
            // that the connection is refused or server doesn't exist.
            socket.connect(new InetSocketAddress(host, port), timeoutMillisecs );
            // This stops the request from dragging on after connection succeeds.
            socket.setSoTimeout(timeoutMillisecs);
        } catch (ConnectException e) {
            // Expected when machine up, but no one on port. 
            logger.fine("Endpoint port " + host + ":" + port + " down: " + e);
            return false;
        } catch (UnknownHostException e) {
            // Not expected.  We should not have any bad domain names.  
            logger.severe("Endpoint " + host + ":" + port + " has bad host: " + e);
            return false;
        } catch (SocketTimeoutException e) {
            // expected when machine or networking down. 
            logger.fine("Endpoint " + host + ":" + port + " down: " + e);
            return false;
        } catch (IOException e){
            // Base class so must be last in catches
            // Not expected so log at severe level
            logger.log(Level.SEVERE, "Endpoint " + host + ":" + port + " gives exception: " + e, e);
            return false;
        }
        return true;
    }
    
    
    
    
   
}
