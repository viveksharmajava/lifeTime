package oracle.bi.ssl.credentials;

import oracle.bi.ssl.pub.SSLException;

/**
 * A credential was not found in the credential store. 
 *
 */
public final class SSLCredentialMissingException extends SSLException{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private final String key;
    
    public SSLCredentialMissingException(String key){
        super("SSL passphrase " + key + " missing.   Run command: <DomainHome>/bitools/bin/ssl[.sh] regenerate <days>");
        this.key = key;
    }
    
    public String getKey(){
        return this.key;
    }
}
