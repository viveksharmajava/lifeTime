/**
 * Wrapper for invocation of openssl command lines.  Ensures that details of the command lines such as order of options and their 
 * spelling is in one place.  
 */

package oracle.bi.ssl.openssl;