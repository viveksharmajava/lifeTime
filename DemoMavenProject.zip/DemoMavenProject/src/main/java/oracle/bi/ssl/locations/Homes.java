package oracle.bi.ssl.locations;

import java.io.File;

import oracle.bi.ssl.pub.SSLException;

/**
 * Provides access to both oracle home (binary files) and domain home (variable configuration)
 *
 */
public final class Homes {
    
    private final OracleHomeLocations oracleHomeLocations;
    private final DomainLocations domainLocations;
    
    
    public Homes(File oracleHome, File domainHome) throws SSLException{
        this(new OracleHomeLocations(oracleHome), new DomainLocations(domainHome));
    }
    
    public Homes(
            OracleHomeLocations oracleHomeLocations,
            DomainLocations domainLocations) {
        this.oracleHomeLocations = oracleHomeLocations;
        this.domainLocations = domainLocations;
    }
    
    


    public OracleHomeLocations getOracleHomeLocations() {
        return oracleHomeLocations;
    }


    public DomainLocations getDomainLocations() {
        return domainLocations;
    }
    
    
    
}
