package oracle.bi.ssl.locations;

import java.io.File;

import oracle.bi.ssl.pub.SSLException;


/**
 * Defines locations of certificates in the file system. 
 * Java stack uses KeyStore service.  OpenSSL (C++/C) components use the file system. 
 */
public final class OpensslCertificateFileLocations {



    // C++ OpenSSL technology stack
    // ====================================

    
    /**
     * Directory holding all external trust certificates.  These are used to define trust of WebLogic.  Extracted from the 
     * JPS KeyStore system trust. 
     */
    private final File externalTrustDir;


    /**
     * Internal trust certificates.  Private CA certificates for internal use.  
     */
    private final File internalTrustDir;

    /**
     * Certificate/keys for use by internal BIEE servers such as obips.  Ultimately internal identities may be used to replace use of shared BI system 'user'
     * secret to allow BI Servers privileged access to each other.  Currently there is no automatic granting of privileges. 
     */
    private final File internalIdentityDir;

    /**
     * Locations of certificate/keys for openssl identity for docker based servers such as
     * Node.js, operating from localhost
     */
    private final File localhostIdentityDir;
    private final File localhostIdentityServerKey;
    private final File localhostIdentityServerCertificate;

    /**
     * Certificates/keys for use by BIEE clients such as admin tool.  Clients are used by customers and do not get any automatic privilege grants.  
     *  
     */
    private final File clientIdentityDir;
    
    /**
     * Location of openssl server certificate
     */
    private final File opensslServerCertificate;
    
    /**
     * Location of openssl server identity.  This is protected by a passphrase stored in the credential store.  We do not store the 
     * passphrase in clear text in a file system file since this does not conform to Oracle Secure coding guidelines. 
     */
    private final File opensslServerKey;
    
    /**
     * Client certificates/keys are protected internally by the same passphrase.  When exported the new copies are protected by a user selected 
     * passphrase. 
     */
    private final File opensslClientCertificate;
    private final File opensslClientKey;

    
    /**
     * CA is persisted so that when new machines/listeners are added we can create new HTTPS certificates for use by the 
     * WebLogic internal channels with correct common name = listener address.   If we recreated all certificates including the internal CA from 
     * scratch trust certificates installed at admin clients would be invalidated.  Strictly only needs to be accessible on maaster server? So being in 
     * replicated config dir is unnecessary. 
     */ 
    private final File internalCADir;
    
    /**
     * Constructor.  
     */
    public OpensslCertificateFileLocations(DomainLocations domainLocations) throws SSLException
    {
        
        final File sslConfigDir = domainLocations.getSSLConfigDir();
        internalCADir = new File(sslConfigDir, "internalca");
        // CAs which may be public, ie may have been used to sign many certificates.  Any user of a CA from here must 
        // check that the certificate common name is the expected one - ie matches the endpoint address.  This is the standard HTTPS approach. 
        // Note that we include the internal CA here, but only for communicating with endpoints with server certificates with correct CN.   
        externalTrustDir = new File(sslConfigDir, "externaltrust");
        // CAs which we know have only signed our server certificates.  Server certificates signed by internal CAs may have a 
        // shared CN not equal to the endpoint address.  Therefore clients  should not check certificate CN.  
        internalTrustDir = new File(sslConfigDir, "internaltrust");
        internalIdentityDir = new File(sslConfigDir, "internalidentity");
        clientIdentityDir = new File(sslConfigDir, "clientidentity");
        localhostIdentityDir = new File(sslConfigDir, "localhostidentity");
        localhostIdentityServerCertificate = new File(localhostIdentityDir, "servercert.pem");
        localhostIdentityServerKey = new File(localhostIdentityDir, "serverkey.pem");
        opensslServerCertificate = new File(internalIdentityDir, "servercert.pem");
        opensslServerKey = new File(internalIdentityDir, "serverkey.pem");
        opensslClientCertificate = new File(clientIdentityDir, "clientcert.pem");
        opensslClientKey = new File(clientIdentityDir, "clientkey.pem");
    }

    public File getInternalCADir(){
        return internalCADir;
    }

    public File getOpensslServerKey() {
        return opensslServerKey;
    }

    public File getOpensslServerCertificate() {
        return opensslServerCertificate;
    }

    public File getOpensslClientKey() {
        return opensslClientKey;
    }

    public File getOpensslClientCertificate() {
        return opensslClientCertificate;
    }

    public File getExternalTrustDir() {
        return externalTrustDir;
    }

    public File getInternalTrustDir() {
        return internalTrustDir;
    }
    
    public File getInternalTrustCert(){
        return new File( getInternalTrustDir(), "internalca.pem");
    }
   
    public File getInternalIdentityDir() {
        return internalIdentityDir;
    }
    
    public File getClientIdentityDir() {
        return clientIdentityDir;
    }

    public File getLocalhostIdentityDir() {
        return localhostIdentityDir;
    }

    public File getLocalhostIdentityServerKey() {
        return localhostIdentityServerKey;
    }

    public File getLocalhostIdentityServerCertificate() {
        return localhostIdentityServerCertificate;
    }
}
