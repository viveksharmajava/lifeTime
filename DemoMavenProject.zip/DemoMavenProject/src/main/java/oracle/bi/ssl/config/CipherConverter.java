package oracle.bi.ssl.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;



/**
 * Converts between openssl and Java cipher names. 
 *
 */
public final class CipherConverter {
    
    private final Map<String, String> opensslToJava = new HashMap<String, String>();
    private final Map<String, String> javaToOpenssl = new HashMap<String, String>();
    
    // For list of ciphers allowed by Oracle standards see
    // https://gps.oracle.com/ossa/farm/standards/doku.php?id=ats:tls_table
    
    // In JDK 1.8.151 and JKD 9 Java Cryptography Extension (JCE) can be enabled using this property
    public final static String CRYPTO_POLICY_KEY = "crypto.policy";
    
    
    public CipherConverter(){
        // Only convert to Java ciphers supported by TLSv1, 1.1 and 1.2 family in openssl v 1.0.1
        // and JDK 1.8u51 see http://www.oracle.com/technetwork/java/javase/8u51-relnotes-2587590.html
        
        
        // RC4 ciphers removed from default supported list in 1.8u51
        // addOpensslToJavaMapping("RC4-SHA", "SSL_RSA_WITH_RC4_128_SHA");
        // addOpensslToJavaMapping("ECDHE-RSA-RC4-SHA", "TLS_ECDHE_RSA_WITH_RC4_128_SHA");
        
        // Extra ciphers supported by optional Java Cryptography Extension (JCE) from 1.8u151
        addOpensslToJavaMapping("DES-CBC3-SHA", "SSL_RSA_WITH_3DES_EDE_CBC_SHA");
        addOpensslToJavaMapping("DHE-RSA-AES128-GCM-SHA256", "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256");
        addOpensslToJavaMapping("AES256-GCM-SHA384", "TLS_RSA_WITH_AES_256_GCM_SHA384");
        addOpensslToJavaMapping("AES256-SHA", "TLS_RSA_WITH_AES_256_CBC_SHA");
        addOpensslToJavaMapping("ECDHE-RSA-AES256-GCM-SHA384", "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");
        addOpensslToJavaMapping("ECDHE-RSA-AES128-SHA", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA");
        addOpensslToJavaMapping("ECDHE-RSA-AES256-SHA384", "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384");
        addOpensslToJavaMapping("DHE-RSA-AES128-SHA256", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256");
        addOpensslToJavaMapping("EDH-RSA-DES-CBC3-SHA", "SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA");
        addOpensslToJavaMapping("ECDHE-RSA-AES256-SHA", "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA");
        addOpensslToJavaMapping("DHE-RSA-AES256-GCM-SHA384", "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384");
        addOpensslToJavaMapping("AES128-GCM-SHA256", "TLS_RSA_WITH_AES_128_GCM_SHA256");
        addOpensslToJavaMapping("AES256-SHA256", "TLS_RSA_WITH_AES_256_CBC_SHA256");
        addOpensslToJavaMapping("ECDHE-RSA-AES128-GCM-SHA256", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256");
        addOpensslToJavaMapping("ECDHE-RSA-AES128-SHA256", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256");
        addOpensslToJavaMapping("DHE-RSA-AES256-SHA", "TLS_DHE_RSA_WITH_AES_256_CBC_SHA");
        addOpensslToJavaMapping("DHE-RSA-AES128-SHA", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA");
        addOpensslToJavaMapping("AES128-SHA256", "TLS_RSA_WITH_AES_128_CBC_SHA256");
        addOpensslToJavaMapping("AES128-SHA", "TLS_RSA_WITH_AES_128_CBC_SHA");
        addOpensslToJavaMapping("DHE-RSA-AES256-SHA256", "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256");
        addOpensslToJavaMapping("ECDHE-RSA-DES-CBC3-SHA", "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA");
    }
    
    
    public Set<String> getOpensslCiphers(){
        return opensslToJava.keySet();
    }
    
    public Set<String> getJavaCiphers(){
        return javaToOpenssl.keySet();
    }
    
    
    
    /**
     * Parse a  colon (:) separated ciphers list
     * @return
     */
    public List<String> parseCiphersList(String ciphers){
        if( ciphers == null){
            throw new IllegalArgumentException("null ciphers");
        }
        if( ciphers.isEmpty() ){
            return new ArrayList<String>();
        }
        final String[] cipherArray = ciphers.split(":");
        final List<String> cipherList = new ArrayList<String>();
        for( String cipher : cipherArray){
            cipherList.add(cipher);
        }
        return cipherList;
    }
    
    /**
     * Create a ':' separated cipher list from an array of individual cipher names.  Cipher names must not include ':'. 
     * @param ciphers
     * @return
     */
    public String toCipherList(String ... ciphers){
        final StringBuilder buff = new StringBuilder();
        for( String cipher : ciphers){
            if( buff.length() > 0){
                buff.append(":");                
            }
            if( cipher.contains(":")){
                throw new IllegalArgumentException("Cipher " + cipher + " contains ':' character.");
            }
            buff.append(cipher);
        }
        return buff.toString();
    }
    
    /**
     * 
     * @param openssl
     * @return null if not found
     */
    public String getOpensslCipher(String java){
        return javaToOpenssl.get(java);
    }
    
    /**
     * 
     * @param openssl
     * @return null if not found
     */
    public String getJavaCipher(String openssl){
        return opensslToJava.get(openssl);
    }
    
    public List<String> convertToJava(List<String> opensslCiphers){
        final List<String> javaCiphers = new ArrayList<String>();
        
        for(String opensslCipher: opensslCiphers){
            final String javaCipher = getJavaCipher(opensslCipher);
            if( javaCipher == null){
                throw new IllegalArgumentException("Openssl cipher '" + opensslCipher + "' has no Java supported equivalent");
            } else {
                javaCiphers.add(javaCipher);
            }
        }
        
        return javaCiphers;
    }
    
    private void addOpensslToJavaMapping(String openssl, String java){
        if( openssl == null){
            throw new IllegalArgumentException("null openssl");
        }
        if( java == null){
            throw new IllegalArgumentException("null java");
        }
        final String oldJava = opensslToJava.put(openssl, java);
        if( oldJava != null){
            throw new IllegalStateException("Already got mapping for openssl " + openssl + " to " + oldJava);
        };
        final String oldOpenssl = javaToOpenssl.put(java,  openssl);
        if( oldOpenssl != null){
            throw new IllegalStateException("Already got mapping for java " + java + " to " + oldOpenssl);
        };
    }
    
    @Override
    public String toString(){
        final StringBuilder buff = new StringBuilder();
        int maxWidth = 0;
        for( String openssl : opensslToJava.keySet()){
            maxWidth = Math.max( maxWidth, openssl.length());
        }
        final String opensslHeading = "OpenSSL Cipher Name";
        final String javaHeading = "Java Cipher Name";
        maxWidth = Math.max( maxWidth, opensslHeading.length());
        buff.append( pad(opensslHeading, maxWidth));
        buff.append( " ");
        buff.append( javaHeading);
        buff.append("\n\n");
        
        for( Map.Entry<String, String> entry : opensslToJava.entrySet()){
            buff.append( pad(entry.getKey(), maxWidth));
            buff.append( " ");
            buff.append( entry.getValue() );
            buff.append("\n");
        }
        return buff.toString();
    }
    
    /**
     * Pad out a string with spaces so it is width characters wide.  If already wider return full.  
     * @param s
     * @param width
     * @return
     */
    private static String pad(String s, int width){
        if( s.length() > width){
            return s;
        } else {
            return s + repeat(' ', width - s.length());
        }
    }
    
    private static String repeat(char c, int count){
        char[] chars = new char[count];
        Arrays.fill(chars, c);
        String result = new String(chars);
        return result;
    }
}
