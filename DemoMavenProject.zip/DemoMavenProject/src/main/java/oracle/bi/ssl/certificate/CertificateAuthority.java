package oracle.bi.ssl.certificate;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.openssl.OpensslCommands;
import oracle.bi.ssl.pub.SSLException;

import org.apache.commons.io.FileUtils;

/**
 * A certificate authority is able to sign certificates.  All certificates signed by the CA will have the same expiryDays.  
 * 
 * The certificate authority will leave security sensitive files in the CA dir.  If the CA certificate authority is no longer required, 
 * delete the CA dir.  This can be automated using an AutoDeletingTempDir for the CA dir enclosing the CA usage. 
 */
public final class CertificateAuthority{
    private static final Logger logger = LoggerFactory.createLogger(CertificateAuthority.class);
    
    private final Passphrase caKeyPassphrase;
    private final OpensslCommands opensslCommands;
    private File caCertificate = null;
    private final int expiryDays;
    
    private final File caDemoDir;
    
    
    
    /**
     * Create a new root certificate authority with a newly created private key and certificate.  
     * @param homes
     * @param execLogger
     * @param caName used to name working directories
     * @param caKeyPassphrase
     * @param cn the common name included in the CA certificate.  It helps understand CA chains if this include 'Certificate Authority' but this is not required. 
     * @return
     * @throws SSLException
     */
    public static CertificateAuthority mkNewRootCA(
            SSLEnvironment sslEnvironment,
            File caDir, 
            ExecLogger execLogger, 
            Passphrase caKeyPassphrase, 
            DistinguishedName dn,
            int expiryDays) throws SSLException{
        logger.info("Creating CA in directory " + caDir.getAbsolutePath() + " with CN " + dn);
        final CertificateAuthority ca = new CertificateAuthority( sslEnvironment, caDir, execLogger, caKeyPassphrase, expiryDays);
        ca.createNewCAKey(dn);
        
        return ca;
    }
    
    /**
     * Continue using an existing CA.  This allows new certificates to be signed with the existing key, thus avoiding distributing a new 
     * CA certificate to client trust stores. 
     * @param sslEnvironment
     * @param caDir
     * @param execLogger
     * @param caKeyPassphrase
     * @return
     * @throws SSLException
     */
    public static CertificateAuthority reopenCA(SSLEnvironment sslEnvironment, File caDir, ExecLogger execLogger, Passphrase caKeyPassphrase, int expiryDays) 
            throws SSLException {
        final CertificateAuthority ca = new CertificateAuthority( sslEnvironment , caDir, execLogger, caKeyPassphrase, expiryDays);
        // Do not call ca.createCAHousekeeping(); - want to use existing certs. 
        return ca;
    }
    
    /**
     * Create a certificate certificate authority defined by existing key and certificate.  May either be a root or intermediate CA.  
     * For example allows us to use the weblogic demo CA. 
     * @param sslEnvironment
     * @param execLogger
     * @param caName
     * @param caKeyPassphrase
     * @param certKey
     * @return
     * @throws SSLException
     */
    public static CertificateAuthority importCA(
            SSLEnvironment sslEnvironment, File caDir, ExecLogger execLogger, Passphrase caKeyPassphrase, CertKey certKey, int expiryDays) throws SSLException{
        if( certKey == null){
            throw new IllegalArgumentException("null certKey");
        }
        final CertificateAuthority ca = new CertificateAuthority(sslEnvironment, caDir, execLogger, caKeyPassphrase, expiryDays);
        ca.importKeys(certKey);
        return ca;
    }
    
    /**
     * Points at ca directory.  Does not initialize any ca contents.  
     * @param caName used solely to give a unique working directory
     * @throws SSLException
     */
    private CertificateAuthority(
            SSLEnvironment sslEnvironment,
            File caDir, 
            ExecLogger execLogger, 
            Passphrase caKeyPassphrase,
            int expiryDays) throws SSLException{
        if( expiryDays <= 0){
            throw new IllegalArgumentException("expiryDays " + expiryDays + " <= 0");
        }
        this.expiryDays = expiryDays;
        this.caKeyPassphrase = caKeyPassphrase;
        
        // The CA locations must match the relative locations given inside the openssl.cnf file.  Relative locations are relative to the 
        // working dir of the opensslCommands.
        
        // demoCaDir must be relative to openssl commands working dir
        opensslCommands = sslEnvironment.getOpensslCommands(caDir, execLogger);
        caDemoDir = new File(caDir, "demoCA");  
    
    }
    
    
    
    /**
     * Create a new CA, which lasts until this CertificateAuthority is closed.  
     * CA authority is configured by relative directories inside the openssl.cnf file.  So we must create 
     * a directory structure matching that.   Then we can call the openssl req command.
     * @throws SSLException
     * @return location of CA certificate
     */
    private void createCAHousekeeping() throws SSLException{
        logger.info("Create empty CA sub directories under " + caDemoDir.getAbsolutePath() );
        final File caPrivateDir = new File( caDemoDir, "private");
        SSLFileUtils.createPrivateCleanDir(caPrivateDir);

        final File caNewCertsDir = new File( caDemoDir, "newcerts");
        SSLFileUtils.createPrivateCleanDir(caNewCertsDir);

        final File indexFile = new File( caDemoDir, "index.txt");
        final File serialFile = new File( caDemoDir, "serial");

        SSLFileUtils.syncContentInTextFile(indexFile, "".toCharArray(), "Index file");


        // Must be an even number of digits
        SSLFileUtils.syncContentInTextFile(serialFile, "12".toCharArray(), "Serial file");

    }
    
    /**
     * Import an existing key/cert pair into the location expected in the openssl.cnf file. 
     * @param certKey
     * @return
     * @throws SSLException
     */
    private void importKeys(CertKey certKey) throws SSLException{
        if( certKey == null){
            throw new IllegalArgumentException("null certKey");
        }
        createCAHousekeeping();
        
        final File caKeyDest = new File(caDemoDir, "private/cakey.pem");

        // Do not use sslCertsConfig.getCACert() - constructed in a different place
        caCertificate = new File( caDemoDir, "cacert.pem");
        
        try {
            FileUtils.copyFile(certKey.getCert(), caCertificate);
        } catch (IOException e) {
            throw new SSLException("Unable to copy cert into CA structure", e);
        }
        try {
            FileUtils.copyFile(certKey.getKey(), caKeyDest);
        } catch (IOException e) {
            throw new SSLException("Unable to copy key into CA structure", e);
        }
    }
    
    /**
     * Create a new key/certificate pair as the . 
     * @return
     * @throws SSLException
     */
    private void createNewCAKey(DistinguishedName dn) throws SSLException{
        if( dn == null){
            throw new IllegalArgumentException("null dn");
        }
        
        createCAHousekeeping();
        
        final File caKey = new File(caDemoDir, "private/cakey.pem");

        
        caCertificate = new File( caDemoDir, "cacert.pem");


        // Create a self signed certificate authority (CA)
        // The relative location must match the CA authority specified in the 
        // openssl.cnf file. 
        opensslCommands.createCA( caKey, caCertificate, caKeyPassphrase, dn, this.expiryDays);
        
        
    }  
    
    

    /**
     * Create a certificate as requested by certificateRequest.  Surprisingly even though the certificate request includes any optional 
     * certificate extensions such as subject alternate names Openssl requires them to be listed again.  
     * Rather than parsing them from the certificate request pass them in again. 
     * @param certificateRequest
     * @param certificateExtensions eg subject alternative names
     * @param certificate
     * @throws SSLException
     */
    public void signCertificate(File certificateRequest, CertificateExtensions certificateExtensions, File certificate) throws SSLException{
        // Sign openssl stack certificate.   
        opensslCommands.signCertificate( 
                certificateRequest, 
                caKeyPassphrase, 
                certificate,
                this.expiryDays,
                certificateExtensions
                );
    }
    
   
    
    /**
     * Return the public certificate for this certificate authority.  
     * @return
     */
    public File getCACertificate(){
        return caCertificate;
    }

    

}
