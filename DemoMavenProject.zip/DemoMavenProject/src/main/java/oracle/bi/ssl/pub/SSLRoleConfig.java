package oracle.bi.ssl.pub;

import java.io.File;
import java.nio.charset.Charset;
import java.security.AccessController;
import java.security.MessageDigest;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import java.util.logging.Logger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

import oracle.bi.ssl.config.HostVerification;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLConfigWrapper;
import oracle.bi.ssl.config.SSLContextFactory;
import oracle.bi.ssl.config.SecurityProviders;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.locations.DomainLocations;
import oracle.bi.ssl.logging.LoggerFactory;

/**
 * Provides ssl configuration specific to a particular ssl role - client, server, internal versus external. 
 * The verification and trust keystores differ in each case.  The appropriate settings are selected from the 
 * general purpose SSLConfig.   
 *
 */
public final class SSLRoleConfig  {
    // Make state explicit so can be included in message digest.
    // Avoid booleans to avoid confusion about which way round they are. 
    private enum TrustKeyStoreSource {INTERNAL, EXTERNAL};
    private enum CertificateVerification {TRUST_ANY_PEER, VERIFY_PEER};
    
    
    private static final Logger logger = LoggerFactory.createLogger(SSLRoleConfig.class);
    
    static private final byte[] digestSeparator = new byte[]{0};
    static private final Charset digestCharset = Charset.forName("UTF-8");
    
    private final SSLConfigWrapper sslConfig;
    
    private final CertificateVerification certificateVerification;
    private final TrustKeyStoreSource trustKeyStoreSource;
    private final Supplier<TrustManager[]> trustManagerSupplier;

    private final HostVerification hostVerification;
    
    // If we have to verify hostname ourselves the host is stored in the context.  Therefore we 
    // cannot share SSLContexts. 
    private Map<String, SSLContext> knownContexts = new HashMap<String, SSLContext>();
    
    /**
     * Create an SSL environment suitable for servers (OBIPS, OBIS, Cluster controller, Scheduler) which use our internal identity certificate.   If  
     * two way ssl is enabled, requires that clients also use the internal identity certificate which is signed by our private certificate 
     * authority (CA) in the internal trust store. 
     * @param domainHome if null, derive from environment
     * @return null if internal ssl not enabled
     * @throws Exception
     */
    public static SSLRoleConfig serverSSLConfig(File domainHome) throws SSLException{
        final SSLConfigWrapper sslConfig = new SSLConfigWrapper(DomainLocations.optionallyFromEnvironment(domainHome), null);
        if( sslConfig.isSslEnabled()){
            SecurityProviders.getInstance().checkOnce(sslConfig);
            // Whether servers check client certificates is configurable
            final CertificateVerification certificateVerification = sslConfig.isClientVerification() ? CertificateVerification.VERIFY_PEER : CertificateVerification.TRUST_ANY_PEER;
            return new SSLRoleConfig(sslConfig, "server", certificateVerification, TrustKeyStoreSource.INTERNAL, HostVerification.ALLOW_ANY_HOST);
        } else {
            // If ssl not enabled cannot assume that credentials and keystores have been created.  
            return null;
        }
    }
    
    /**
     * Create a client ready to talk to servers using 'internal' trust certificates, signed by our private certificate authority (CA).  Therefore 
     * the certificate name (either subject common name or subject alternate name) does not need to be checked.  Since the identity certificates do not 
     * need to have a n networking address based name the same certificate may be used for mutliple servers.  Note that these weakly named 
     * certificates are not compatible with the HTTPS standard, which involves checking the host name. HTTP clients such as Jersey, even if given 
     * an SSL context from this internal client ssl Config, will still overwrite SSLSocket SSL parameters forcing host name checking.   In practice this 
     * means that this SSLRoleConfig should only be used when communicating over a proprietory protocol (eg OBIPS RPC over TCP) to one of the C++ 
     * system components. 
     * <p>
     * If two way ssl is enabled the client will use as its 
     * identity the shared BI server identity.
     * </p>
     * @param domainHome if null, derive from environment
     * @return null if internal ssl disabled
     * @throws Exception
     */
    public static SSLRoleConfig internalClientSSLConfig(File domainHome) throws SSLException{
        final SSLConfigWrapper sslConfig = new SSLConfigWrapper(DomainLocations.optionallyFromEnvironment(domainHome), null);

        // See comment for isSslEnabled().  As that will always return false for Koala, return an SSlRoleConfig object anyway
        // if the platform (e.g. Jetty) has set an override supplier
        final boolean sslEnabled = sslConfig.isSslEnabled() || sslConfig.getOverridenInternalTrustManagerSupplier() != null;

        if (sslEnabled){
            SecurityProviders.getInstance().checkOnce(sslConfig);
            // Clients always check server certificates. 
            // Servers are only contacted by internal components.  So use internal trust key store    
            // Internal certificate authority is only used to sign our certificates, so dont need to restrict to particular common names. 
            Supplier<TrustManager[]> overridenInternalTrustManagerSupplier = sslConfig.getOverridenInternalTrustManagerSupplier();
            return new SSLRoleConfig(sslConfig,
                    "internal client",
                    CertificateVerification.VERIFY_PEER,
                    TrustKeyStoreSource.INTERNAL,
                    HostVerification.ALLOW_ANY_HOST,
                    overridenInternalTrustManagerSupplier);
        } else {
            return null;
        }
    }
    
    
    /**
     * Create a client ready to talk to servers using 'external' trust certificates, typically signed by a public certificate authority.  Therefore 
     * the certificate name (either subject common name or subject alternate name) is checked.  The client may also talk to servers using our 
     * internal trust certificates, but the server certificates must have proper subject names matching their networking address.  The certificates 
     * we create for the managed webLogic internal channels are an example of these internally signed but HTTPS compatible certificates.  
     * <p>
     * If two way ssl is enabled the client will use as its identity the shared BI server identity. 
     * </p>
     * @param domainHome if null, derive from environment
     * @return null if internal ssl not enabled.  Although external trust is always available, the identity is only available if 
     * internal ssl is initialized.  (Depending on client usage we might need to relax this, and allow connection)
     * @throws Exception
     */
    public static SSLRoleConfig externalClientSSLConfig(File domainHome) throws SSLException{
        final SSLConfigWrapper sslConfig = new SSLConfigWrapper(DomainLocations.optionallyFromEnvironment(domainHome), null);
        if( sslConfig.isSslEnabled()){
            // Clients always check servers.
            // Server certs are signed by CA we trust, so we know certificate not forged.  But could be any certificate - must restrict by 
            // common name. 
            return new SSLRoleConfig(sslConfig, "external client", CertificateVerification.VERIFY_PEER, TrustKeyStoreSource.EXTERNAL, HostVerification.MATCH_HOST);
        } else {
            return null;
        }
    }
    
    
    /**
     * Constructor
     * @param sslConfig
     * @param purpose added to logging
     * @param certificateVerification
     * @param trustKeyStoreSource
     * @throws Exception
     */
    private SSLRoleConfig(SSLConfigWrapper sslConfig, 
                          String purpose, 
                          CertificateVerification certificateVerification, 
                          TrustKeyStoreSource trustKeyStoreSource,
                          HostVerification hostVerification) throws SSLException{
        this(sslConfig, purpose, certificateVerification, trustKeyStoreSource, hostVerification, null);
    }

    private SSLRoleConfig(SSLConfigWrapper sslConfig,
                          String purpose,
                          CertificateVerification certificateVerification,
                          TrustKeyStoreSource trustKeyStoreSource,
                          HostVerification hostVerification,
                          Supplier<TrustManager[]> trustManagerSupplier) {
        this.sslConfig = sslConfig;
        this.certificateVerification = certificateVerification;
        this.trustKeyStoreSource = trustKeyStoreSource;
        this.hostVerification = hostVerification;
        this.trustManagerSupplier = trustManagerSupplier;

        final String custom = trustManagerSupplier != null ? (" (with custom trust manager supplier: " + trustManagerSupplier) : "";
        logger.info("SSL role config for " + purpose + " Trust source: " + this.trustKeyStoreSource + " verification: " + this.certificateVerification + custom);
    }

    /**
     * 
     * @return true if trust configuration is restricted to internal endpoints only. 
     */
    public boolean isInternal(){
        return this.trustKeyStoreSource == TrustKeyStoreSource.INTERNAL;
    }
            
            
    /**
     * Creating an SSLContext requires access to credential store for the identity keystore passphrase, and to the 
     * keystore service itself.  We wrap in a doPrivileged block.  This means that callers do not need these 
     * permissions.  This is not ideal.  We encapsulate the security sensitive fine grained calls here -in particular 
     * we stop exporting certificates for evil use elsewhere, and stop dumping passphrases.  However , a caller 
     * still gets to call getSSLContext, and hence gets to connect with our identity, without itself being 
     * trusted code.  Ideally the doPrivileged block should be higher up the stack to constrain a particular usage pattern.  
     * However this, as always, conflicts with code modularity.   
     * 
     * To debug access control issues use:
     * <ul>
     * <li>-Djava.security.debug=access:failure</li>
     * </ul>
     * 
     * @param hostname The hostname may be 
     * used for certificate name checking.  As a result SSLContexts cannot be shared.  
     * @return
     * @throws SSLException
     */
    
    public SSLContext getSSLContext(final String hostname) throws SSLException {
        final PrivilegedExceptionAction<SSLContext> action = new PrivilegedExceptionAction<SSLContext>(){
                    @Override
                    public SSLContext run() throws SSLException
                    {
                        final SSLContext sslContext = getSSLContextCodeGrant(hostname);
                        
                        return sslContext;
                    }
                };
        try {
            final SSLContext sslContext = AccessController.doPrivileged(action);
            return sslContext;
        } catch (PrivilegedActionException e) {
            final Throwable cause = e.getCause();
            if( cause instanceof SSLException){
               throw (SSLException)cause;
            } else {
                throw new SSLException("Failed to get ssl context", e);
            }
        }
    }
    
    /**
     * Needs to run with code grants.  See above privileged block in getSSLContext. 
     * This is the only method which writes to data members.  So synchronize.  This 
     * ensures that if multiple threads are trying to get the same SSLContext at the same time we do not waste resources 
     * all doing the slow trust store lookup.  
     * @return
     * @throws SSLException
     */
    private synchronized SSLContext getSSLContextCodeGrant(String hostname) throws SSLException {
        
        // Even if using cached value, must be in the code grant check. 
        SSLContext ret = this.knownContexts.get(hostname);
        if( ret == null){
            if (trustManagerSupplier != null) {
                // Custom TrustManager[] in use - don't support normal or custom identity in this mode
                // This is used by Koala, and so microservices have a different way to get client/server TLS certs.
                TrustManager[] trustManagers = trustManagerSupplier.get();
                ret = SSLContextFactory.getSSLContext(hostname,
                        sslConfig.getSSLAlgorithms().getProtocols(),
                        hostVerification,
                        trustManagers);
            } else {
                final KeyStoreAccessor trustStore;
                if (trustKeyStoreSource == TrustKeyStoreSource.EXTERNAL) {
                    trustStore = sslConfig.getDomainTrustKeyStoreAccessor();
                } else {
                    trustStore = sslConfig.getBIInternalTrustKeyStoreAccessor();
                }

                ret = SSLContextFactory.getSSLContext(
                        hostname,
                        sslConfig.getSSLAlgorithms().getProtocols(),
                        KeyStoreType.getDefaultKeyStoreType(),
                        hostVerification,
                        sslConfig.getBIIdentityKeyStoreAccessor(),
                        sslConfig.getIdentityAlias(),
                        sslConfig.getKeystorePwd(),
                        sslConfig.getKeyPwd(),
                        trustStore);
            }
            this.knownContexts.put(hostname, ret);
        }
        return ret;
    }

    
    public String[] getEnabledCipherSuites() {
        return sslConfig.getSSLAlgorithms().getJavaCipherArray();
    }

    
    public String[] getEnabledProtocols() {
        return sslConfig.getSSLAlgorithms().getProtocols().getEnabledProtocols();
    }

    
    public String getBaseProtocol(){
        return sslConfig.getSSLAlgorithms().getProtocols().getBaseProtocol();
    }

    /**
     * Allows users to decide if connections in a pool are 'the same'.  Although the underlying ssl config is defined centrally
     * so is fixed, each Role is slightly different.  The different roles have different trust keystores.  
     * @param digest
     */
    public void updateHash(MessageDigest digest) {
        
        addToMessageDigest(digest,certificateVerification.name());
        addToMessageDigest(digest,trustKeyStoreSource.name());
        
    }

    
    public boolean getTrustAnyPeer() {
        return certificateVerification == CertificateVerification.TRUST_ANY_PEER;
    }

    
    
    
     
    static private void addToMessageDigest(MessageDigest digest, String str){
        digest.update(digestCharset.encode(str).array());

        digest.update(digestSeparator);
    }
}
