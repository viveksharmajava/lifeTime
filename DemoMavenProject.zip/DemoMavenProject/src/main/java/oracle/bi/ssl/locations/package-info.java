/**
 * Models locations in the domain home and oracle home file systems.  Also locations in keystores. 
 * Not part of the public api since we may change without notice locations of various files.  
 */

package oracle.bi.ssl.locations;