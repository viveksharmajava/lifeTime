/**
 * Supports manipulation of ssl configuration.  The actual SSLConfig class is in the oracle.bi.ssl.pub package since it 
 * forms part of the public api. 
 */

package oracle.bi.ssl.config;