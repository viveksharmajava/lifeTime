package oracle.bi.ssl.config;

import oracle.bi.base.lcm.model.jaxb.SSLConfig;
import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.credentials.CredentialAccessor;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.jps.KeyStoreServiceAccessor;
import oracle.bi.ssl.locations.DomainLocations;
import oracle.bi.ssl.locations.KeystoreNames;
import oracle.bi.ssl.pub.SSLAlgorithms;
import oracle.bi.ssl.pub.SSLException;
import oracle.bi.ssl.pub.SSLProtocols;

import javax.net.ssl.TrustManager;
import javax.xml.bind.JAXBException;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.function.Supplier;

/**
 * Java representation of SSL configuration.  The low level jaxb persistence is defined in the bi base template by class 
 * SSLConfig.  This allows the config template to include the default xml, and also isolates the 
 * persistence (which must not change on upgrade) and the 
 * convenience methods which can.  
 * 
 * 
 * 
 * SSL is configured in one place under the domain configuration.  Every component reads ssl settings from this one place. 
 * Values which are currently fixed - for example which trust store to use, and which SSL protocols to uss - are also 
 * accessed via this class.  This ensures that if these values change or become configurable consuming code will remain 
 * unchanged.  
 * 
 * The configuration is saved in an xml file.  Java -> xsd jaxb generation is used.  Unlike xsd -> Java this allows us to 
 * trivially include real behaviour in the Java classes. 
 *
 */

final public class SSLConfigWrapper {
    private static final String PARAM_INTERNAL_TRUSTMANAGER_SUPPLIER = "oracle.bi.ssl.pub.internal_trustmanagers_supplier";

    private static CipherConverter cipherConverter = new CipherConverter();
    
    private final File backingFile;
    private final KeystoreNames keystoreNames = new KeystoreNames();
    
    // lazy evaluation so JPS initialization cost is only paid when a security store (credential or keyStore) is accessed. 
    private CredentialAccessor lazyCredentialAccessor = null;
    private KeyStoreServiceAccessor lazyKeyStoreServiceAccessor = null;
    
    private final String stripe;
    
    /**
     * Contents of central ssl domain configuration file
     */
    private final SSLConfig persistence;
    
    private final DomainLocations domain;

    private Supplier<TrustManager[]> overrideInternalTrustManagerSupplier;
    /**
     * 
     * @param domain
     * @param stripe if null use default stripe.  Non default stripes used for testing. 
     * @throws SSLException
     */
    public SSLConfigWrapper(DomainLocations domain, String stripe) throws SSLException{
        if( domain == null){
            throw new IllegalArgumentException("null domain");
        }
        this.domain = domain;
        this.backingFile = domain.getSSLConfigFile();
        this.persistence = read(backingFile);
        
        this.stripe = stripe;

        loadOverrides();
    }

    /**
     * Support some variation of config via JVM params.  The bi-ssl.xml is intended for OAS end-user editing, so
     * don't want this within that.
     *
     * But we do want to change some built-in behaviour for DV-in-Docker, where some clients access SSLConfigWrapper/SSLRoleConfig
     * directly, instead of using EndpointManager's SSL Context
     */
    private void loadOverrides() {
        // For now, only support override internal trust manager, not external or identity keystore.
        //
        // (DV-in-docker may need support for external trust manager for ONSR, but not identity keystore as TLS server/client certs
        // are managed separately)
        final String internalTrustManagerSupplierClass = System.getProperty(PARAM_INTERNAL_TRUSTMANAGER_SUPPLIER);
        if (internalTrustManagerSupplierClass != null) {
            try {
                @SuppressWarnings("unchecked") final Class<Supplier<TrustManager[]>> clazz = (Class<Supplier<TrustManager[]>>) Class.forName(internalTrustManagerSupplierClass);
                overrideInternalTrustManagerSupplier = clazz.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(String.format("Could not load Supplier<TrustManager[]> class %s, due %s", internalTrustManagerSupplierClass, e.getMessage()), e);
            }
        }
    }

    /**
     * Lazy evaluation. 
     * @throws SSLException 
     */
    private KeyStoreServiceAccessor getKeyStoreServiceAccessor() throws SSLException{
        if( lazyKeyStoreServiceAccessor == null){
            lazyKeyStoreServiceAccessor = new KeyStoreServiceAccessor(domain);
        }
        return lazyKeyStoreServiceAccessor;
    }
    
    /**
     * Lazy evaluation 
     */
    private final CredentialAccessor getCredentialAccessor() throws SSLException {
        if( lazyCredentialAccessor == null){
            lazyCredentialAccessor = new CredentialAccessor(domain);
        }
        return lazyCredentialAccessor;
    }
    /**
     * Create initial default config file.  Clients should not need to do this since the 
     * base bi template will create it.  Used for testing. 
     * @param domain
     * @throws SSLException 
     */
    public static void initConfig( DomainLocations domain) throws SSLException{
        persist(new SSLConfig(), domain.getSSLConfigFile());
    }

    public void setJavaSslCipherList(String ... ciphers) {
        persistence.setUseOpensslCiphersForJava(false);
        persistence.setJavaSslCipherList( cipherConverter.toCipherList(ciphers) );
    }

    /**
     * Cipher list which will be applied to OpenSSL connections.   Empty string means allow any cipher supported by OpenSSL. 
     * Java components have their cipher list controlled by VM properties.  We do not attempt to provide a canonical form 
     * to specify both Java JSSE and OpenSSL cipher usage in one go.  Introducing our own mechanisms would restrict users from accessing 
     * the full power of standard JSSE configuration mechanisms.   It is entirely possible to specify different cipher suites for the different 
     * implementation stacks.  This would be appropriate if weaknesses in the implementations rather than the algorithm per se are found in the 
     * future. 
     * 
     * For JSSE settings see jdk.tls.disabledAlgorithms and jdk.certpath.disabledAlgorithms in <OracleHome>/oracle_common/jdk/jre/lib/security/java.security
     * 
     * For OpenSSL cipher list syntax see the ciphers(1) man page, https://www.openssl.org/docs/apps/ciphers.html#CIPHER_LIST_FORMAT.
     * For command line usage by client see -cipher option on s_client(1) man page, https://www.openssl.org/docs/apps/s_client.html#
     * For command line usage by server see -cipher optin on s_server(1) man page, https://www.openssl.org/docs/apps/s_server.html#
     * For programmatic usage see https://www.openssl.org/docs/ssl/SSL_CTX_set_cipher_list.html
     * 
     * Ciphers are ':' separated.  You can use the openssl ciphers command to generate lists mathing requirements, eg only rsa algorithms. 
     * The order is significant for clients.  The first cipher on the list also accepted by the server is used.  The order within the list for 
     * servers is not significant.  
     * 
     * 
     */
    public String getOpensslCipherListString() {
        return persistence.getOpensslCipherList();
    }

    /**
     * Use default ciphers is represented by empty array
     * @param ciphers never null
     */
    public void setOpenSslCipherList(String ... ciphers) {
        persistence.setOpensslCipherList( cipherConverter.toCipherList(ciphers) );
    }

    public void setSslEnabled(boolean sslEnabled){
        persistence.setSslEnabled(sslEnabled);
    }
    
    public boolean isSslEnabled() {
        /*
         * Currently cannot be used... DV-Jetty launcher sets overrideInternalTrustManagerSupplier. Webapps that use
         * URLs are fine, as they don't call isSslEnabled directly.  But SAW client does use this global flag to decide
         * whether to use TLS to OBIPS.  They are working on an env var to override the call to this method, but in
         * the meantime, always return false from here.  Long term for koala, that is probably the correct solution anyway,
         * given this is a global flag but in koala TLS has to be controlled per comms path (client->server pair)
        if (overrideInternalTrustManagerSupplier != null) {
            // Assume if client has overriden trust manager, then they want TLS enabled
            // (This is for DV-in-Docker - cannot set enabled=true in bi-ssl.xml as that breaks nqsserver)
            return true;
        } else {
            return persistence.isSslEnabled();
        }
         */

        return persistence.isSslEnabled();
    }

    public Supplier<TrustManager[]> getOverridenInternalTrustManagerSupplier() {
        return overrideInternalTrustManagerSupplier;
    }

    public void setClientVerification(boolean clientVerification){
        persistence.setClientVerification(clientVerification);
    }
    
    public boolean isClientVerification(){
        return persistence.isClientVerification();
    }

    /**
     * If true the value of javaSsslCipherList will be ignored.  Java ciphers will be translated from the openssl cipher list.  Only ciphers 
     * supported by both protocols are supported. 
     */
    public boolean isUseOpensslCiphersForJava(){
        return persistence.isUseOpensslCiphersForJava();
    }

    public void setUseOSProvidedOpenssl(boolean useOSProvidedOpenssl) {
        persistence.setUseOSProvidedOpenSSL(useOSProvidedOpenssl);
    }

    public boolean isUseOSProvidedOpenssl() {
        return persistence.isUseOSProvidedOpenSSL();
    }
    public String getHashAlgorithm() {
        return persistence.getHashAlgorithm();
    }

    public void setHashAlgorithm(String hashAlgorithm) {
        persistence.setHashAlgorithm(hashAlgorithm);
    }

    public int getHashIterationCount() {
        return persistence.getHashIterationCount();
    }

    public void setHashIterationCount(int hashIterationCount) {
        persistence.setHashIterationCount(hashIterationCount);
    }

    public String getEncryptionAlgorithm() {
        return persistence.getEncryptionAlgorithm();
    }

    public void setEncryptionAlgorithm(String encryptionAlgorithm) {
        persistence.setEncryptionAlgorithm(encryptionAlgorithm);
    }

    public int getEncryptionAlgorithmKeySize() {
        return persistence.getEncryptionAlgorithmKeySize();
    }

    public void setEncryptionAlgorithmKeySize(int encryptionAlgorithmKeySize) {
        persistence.setEncryptionAlgorithmKeySize(encryptionAlgorithmKeySize);
    }

    public boolean isFIPSEnabled() {
        return persistence.isFipsEnabled();
    }

    public void setFIPSEnabled(boolean fipsEnabled) {
        persistence.setFipsEnabled(fipsEnabled);
    }

    public int getPbeIterationCount() {
        return persistence.getPbe().getPbeIterationCount();
    }

    public void setPbeIterationCount(int pbeIterationCount) {
        persistence.getPbe().setPbeIterationCount(pbeIterationCount);
    }

    public int getPbeSaltSize() {
        return persistence.getPbe().getPbeSaltSize();
    }

    public void setPbeSaltSize(int pbeSaltSize) {
        persistence.getPbe().setPbeSaltSize(pbeSaltSize);
    }

    public int getPbeIVSize() {
        return persistence.getPbe().getPbeIVSize();
    }

    public void setPbeIVSize(int pbeIVSize) {
        persistence.getPbe().setPbeIVSize(pbeIVSize);
    }

    public int getPbeAuthTagLength() {
        return persistence.getPbe().getPbeAuthTagLength();
    }

    public void setPbeAuthTagLength(int pbeAuthTagLength) {
        persistence.getPbe().setPbeAuthTagLength(pbeAuthTagLength);
    }

    public String getPbeKeygenSpec() {
        return persistence.getPbe().getPbeKeygenSpec();
    }

    public void setPbeKeygenSpec(String pbeKeygenSpec) {
        persistence.getPbe().setPbeKeygenSpec(pbeKeygenSpec);
    }

    public KeyStoreAccessor getBIInternalTrustKeyStoreAccessor() throws SSLException {
        try (Passphrase keystorePassphrase = getCredentialAccessor().getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE)){
            final KeyStoreAccessor keyStoreAccessor = getKeyStoreServiceAccessor().getBIInternalTrustKeyStore(keystorePassphrase, stripe);
            return keyStoreAccessor;
        }
    }
    
    public KeyStoreAccessor getDomainTrustKeyStoreAccessor() throws SSLException {        
        // No passphrase - policy permissions only. 
        return getKeyStoreServiceAccessor().getDomainTrustKeyStore();
    }

    public KeyStoreAccessor getBIIdentityKeyStoreAccessor() throws SSLException {
        try (Passphrase keystorePassphrase = getCredentialAccessor().getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE)){
            final KeyStoreAccessor keyStoreAccessor = getKeyStoreServiceAccessor().getBIIdentityKeyStore(keystorePassphrase, stripe);
            return keyStoreAccessor;
        }
    }

    public SSLAlgorithms getSSLAlgorithms(){
        // Do not allow insecure sslv2 (ancient, many vulnerabilities), sslv3 (broken by POODLE attack late 2014). 
        // Now C++ stack using openssl 1.0.1 only use best it supports - TLSv1.2. 
        return new SSLAlgorithms( SSLProtocols.TLSV1_2ONLY, getJavaSslCipherList());
    }
    
    /**
     * Caller must ensure passphrase shredded on try with resources close        
     * @return
     * @throws SSLException
     */
    public Passphrase getKeystorePwd() throws SSLException{
        return getCredentialAccessor().getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);
    }
    
    /**
     * Caller must ensure passphrase shredded on try with resources close        
     * @return
     * @throws SSLException
     */
    public Passphrase getKeyPwd() throws SSLException{
        return getCredentialAccessor().getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);
    }
    
    public String getStripe(){
        return stripe;
    }

    /**
     * Currently everyone uses the same identity certificate/key.  For example OBIPS server will use this key.  Perhaps surprisingly a client such as 
     * the Analytics web app will also use this key.  A client certificate will only be checked if two way ssl is enabled. 
     * @return
     */
    public String getIdentityAlias(){
        return keystoreNames.getServerIdentityAlias();
    }
    
    /**
     * Save to the standard location
     */
    public void save() throws SSLException{
        save( backingFile);
    }
    
    /**
     * Save to an arbitrary location
     * @param file path to domain locations
     * @throws IOException 
     * @throws JAXBException 
     */
    public void save(File file) throws SSLException{
        persist(persistence, file);
    }

    /**
     * Save to an arbitrary file.
     * @param persistence
     * @param file
     * @throws JAXBException
     * @throws IOException
     */
    private static void persist(SSLConfig persistence, File file) throws SSLException{
        
        final XmlBridge xmlBridge;
        try {
            xmlBridge = new XmlBridge();
        } catch (JAXBException e) {
            throw new SSLException("Unable to create parser for SSLConfig", e);
        }
        try {
            xmlBridge.marshall(persistence, file);
        } catch (JAXBException e) {
            throw new SSLException("Unable to marshall SSLConfig", e);
        } catch (IOException e) {
            throw new SSLException("Unable to save ssl config to " + file.getAbsolutePath(), e);
        }
    }

    /**
     * Read from an arbitrary file.
     * @param file
     * @return
     * @throws JAXBException
     */
    private static SSLConfig read(File file) throws SSLException{
        
        final XmlBridge xmlBridge;
        try {
            xmlBridge = new XmlBridge();
        } catch (JAXBException e) {
            throw new SSLException("Unable to create parser for ssl config file " + file.getAbsolutePath(), e);
        }
        
        try {
            final SSLConfig persistence = xmlBridge.unmarshall(file);
            return persistence;
        } catch (JAXBException e) {
            throw new SSLException("Unable to read ssl config file " + file.getAbsolutePath(), e);
        }
        
    }

    private List<String> getJavaSslCipherList() {
        if( persistence.isUseOpensslCiphersForJava() ){
            final List<String> opensslCiphers = cipherConverter.parseCiphersList(persistence.getOpensslCipherList());
            return cipherConverter.convertToJava(opensslCiphers);
        } else {
            return cipherConverter.parseCiphersList(persistence.getJavaSslCipherList());
        }
        
    }

}
