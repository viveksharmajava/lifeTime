/**
 * File system utilities.  
 */

package oracle.bi.ssl.files;