package oracle.bi.ssl.channels;

/**
 * Defines a channel.  All channels have the same name so that one virtual host can target them all. 
 * Channels have one port (unlike the default public channel which has two - http and https). 
 * Channels are always associated with one server, identified by name. 
 *
 */
public final class Channel {
    private final String serverName;
    private final int channelPort;
    
    public Channel(String serverName, int channelPort) {
        this.serverName = serverName;
        this.channelPort = channelPort;
    }

    public String getServerName() {
        return serverName;
    }

    public int getChannelPort() {
        return channelPort;
    }
    
    
}
