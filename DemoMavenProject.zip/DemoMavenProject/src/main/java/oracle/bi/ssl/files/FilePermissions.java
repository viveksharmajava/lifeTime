package oracle.bi.ssl.files;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Logger;

import oracle.bi.ssl.pub.SSLException;



/**
 * Utility class holding methods for manipulating file permissions.
 */
public final class FilePermissions {

    private static final Logger _logger = Logger.getLogger("oracle.as.install.bi.util");

    private static final Set<PosixFilePermission> PRIVATE_FILE_PERMISSIONS = 
            new HashSet<PosixFilePermission>(Arrays.asList(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
    
    private static final Set<PosixFilePermission> PRIVATE_DIR_PERMISSIONS = 
            new HashSet<PosixFilePermission>(Arrays.asList(PosixFilePermission.OWNER_EXECUTE, PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));

    /**
     * No instances (static methods only).
     */
    private FilePermissions()
    {
    }

    /**
     * Sets a file to the 'private' permissions for a file to be used within the BI system,
     * namely (User:RW, Group:None, Other:None), but still subject to umask (don't add extra permissions).
     * Note that in this context, 'private' is used for specially sensitive files.
     * @param f File whose permissions are to be modified.
     */
    public static void setPrivateFilePermissions(File file) throws SSLException {
        
        try{
            _logger.finer("Setting Private permissions on: " + file.getAbsolutePath());
            if ( System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
              boolean success;
              success = file.setExecutable(true, true) && file.setReadable(true, true) || file.setWritable(true, true);
              if ( !success) {
                throw new SSLException("Failed to set private file permissions on " + file.getAbsolutePath());
              }
            }
            else {
              Files.setPosixFilePermissions(file.toPath(), PRIVATE_FILE_PERMISSIONS);
            }
        } catch (IOException e){
            throw new SSLException("Failed to set private file permissions on " + file.getAbsolutePath() );
        }
    }
    
    /**
     * Sets a directory to the 'private' permissions for a directory to be used within the BI system,
     * namely (User:RWX, Group:None, Other:None), but still subject to umask (don't add extra permissions).
     * Note that in this context, 'private' is used for specially sensitive files.
     * @param d Directory whose permissions are to be modified.
     */
    public static void setPrivateDirPermissions(File dir) throws SSLException {
        try{
            _logger.finer("Setting Private permissions on: " + dir.getAbsolutePath());
            if ( System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
              boolean success;
              success = dir.setExecutable(true, true) && dir.setReadable(true, true) || dir.setWritable(true, true);
              if ( !success) {
                throw new SSLException("Failed to set private dir permissions on " + dir.getAbsolutePath());
              }
            }
            else {
              Files.setPosixFilePermissions(dir.toPath(), PRIVATE_DIR_PERMISSIONS);
            }
        } catch (IOException e){
            throw new SSLException("Failed to set private dir permissions on " + dir.getAbsolutePath() );
        }
    }

}
