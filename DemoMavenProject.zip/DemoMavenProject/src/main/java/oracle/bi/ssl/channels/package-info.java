/**
 * All the WebLogic ssl configuration is done on the bi_internal_channel1 channel which is reserved for our use only - so we 
 * can configure it with our own internal SSL certificates.   Configuring channels requires complex WLST edits of the WebLogic config.xml 
 * file.  
 * <p>
 * There is a strong relationship to the endpoint manager code.  Here we modify the contents of WebLogic's config.xml.  Endpoint manager reads the 
 * config back out.  Both writer and reader must deal with special cases such as web applications delivered as standalone applications rather then 
 * the more usual contained within an ear file.  
 * </p>
 */

package oracle.bi.ssl.channels;