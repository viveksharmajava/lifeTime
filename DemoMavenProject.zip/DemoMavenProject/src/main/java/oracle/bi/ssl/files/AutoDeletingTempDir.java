package oracle.bi.ssl.files;

import java.io.File;
import java.io.IOException;

import oracle.bi.ssl.pub.SSLException;

import org.apache.commons.io.FileUtils;

/**
 * Supports try with resources to create a temporary directory, and then delete it at exit from the try. 
 * This ensures that any security sensitive files are deleted. 
 * @author pharry
 *
 */
public class AutoDeletingTempDir implements AutoCloseable {
    private final File dir;
    
    /**
     * Create a temp directory called 'sub' under base.
     * @param base
     * @param sub
     * @throws SSLException
     */
    public AutoDeletingTempDir(File base, String sub) throws SSLException{
        if(base == null){
            throw new IllegalArgumentException("null base");
        }
        if(sub == null){
            throw new IllegalArgumentException("null sub");
        }
        dir = new File(base, sub);
        SSLFileUtils.createPrivateCleanDir(dir);
    }

    @Override
    public void close() throws SSLException {
      
        try {
            FileUtils.forceDelete(dir);
        } catch (IOException e) {
            throw new SSLException("Unable to delete private temporary directory " + dir.getAbsolutePath(), e);
        }
    }
    
    public File getDir(){
        return dir;
    }
}
