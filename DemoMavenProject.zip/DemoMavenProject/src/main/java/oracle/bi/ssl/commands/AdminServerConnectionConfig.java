package oracle.bi.ssl.commands;

import java.util.Objects;

import oracle.bi.ssl.certificate.Passphrase;

/**
 *  Holds the information required to connect to Admin Server in online mode. 
 * 
 *
 */
public final class AdminServerConnectionConfig {
    private final String adminServerConnectString; // Of form host:port
    private final String user;
    private final Passphrase adminPassword;
    
    public AdminServerConnectionConfig(String adminServerConnectString, String user, Passphrase adminPassword) {
        this.adminServerConnectString = Objects.requireNonNull(adminServerConnectString, "null adminServerConnectString");
        this.user = Objects.requireNonNull(user, "null user");
        this.adminPassword = Objects.requireNonNull(adminPassword, "null adminPassword");
    }

    public String getAdminServerConnectString() {
        return adminServerConnectString;
    }

    public String getUser() {
        return user;
    }

    public Passphrase getAdminPassword() {
        return adminPassword;
    }

    
    
    
}
