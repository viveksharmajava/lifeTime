package oracle.bi.ssl.pub;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;

import oracle.bi.ssl.logging.LoggerFactory;

/**
 * Specifies what protocol and cipher to be used
 *
 */
public final class SSLAlgorithms {
    private static final Logger logger = LoggerFactory.createLogger(SSLAlgorithms.class);
    private final SSLProtocols protocols;
    private final List<String> cipherList;
    
    
    public SSLAlgorithms(SSLProtocols protocols, List<String> cipherList) {
        this.protocols = protocols;
        this.cipherList = cipherList;
    }

    public SSLProtocols getProtocols() {
        return protocols;
    }
    
    public List<String> gatJavaCipherList(){
        return cipherList;
    }
    
    /**
     * SSLSocket requires array of ciphers.  So convert from List to array. 
     * @return
     */
    public String[] getJavaCipherArray() {
        
        return cipherList.toArray(new String[cipherList.size()]);
        
    }
    
    @Override
    public String toString(){
        return protocols + " " + cipherList;
    }
    
    /**
     * Apply these algorithm choices to the ssl socket. 
     * @param sslSocket
     */
    public void applyToSSLSocket(SSLSocket sslSocket){
     // The getInstance(protocol) enables that and higher.  We want to ping with a specific protocol. 
        logger.info("Client initially has enabled protocols: " + Arrays.toString(sslSocket.getEnabledProtocols()));
        
        
        sslSocket.setEnabledProtocols( protocols.getEnabledProtocols() );
        logger.info("Client has enabled protocols: " + Arrays.toString(sslSocket.getEnabledProtocols()));
        
        final String[] ciphers = getJavaCipherArray();
        if( ciphers.length > 0){
            logger.info("Setting cipher suites to " + Arrays.toString(ciphers));
            sslSocket.setEnabledCipherSuites(ciphers);
            logger.info("Client enabled cipher suites: " + Arrays.toString(sslSocket.getEnabledCipherSuites()));
        } else {
            logger.info("Client using default cipher suites: "  + Arrays.toString(sslSocket.getEnabledCipherSuites()));
        }
    }
    
    /**
     * Apply these algorithm choices to the ssl server socket. 
     * @param sslSocket
     */
    public void applyToSSLServerSocket(SSLServerSocket serverSocket){
        serverSocket.setEnabledProtocols( getProtocols().getEnabledProtocols() );
        logger.info("Server enabled protocols are: " + Arrays.toString(serverSocket.getEnabledProtocols()));

        final String[] ciphers = getJavaCipherArray();
        if( ciphers.length > 0){
            serverSocket.setEnabledCipherSuites(ciphers);
            logger.info("Server enabled ciphers are: " + Arrays.toString(serverSocket.getEnabledCipherSuites()));
        } else {
            logger.info("Server using default enabled ciphers " + Arrays.toString(serverSocket.getEnabledCipherSuites()));
        }
    }
}
