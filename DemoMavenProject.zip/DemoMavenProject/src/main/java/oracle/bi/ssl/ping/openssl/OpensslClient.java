package oracle.bi.ssl.ping.openssl;



import java.util.Objects;
import java.util.logging.Logger;

import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.logging.EchoMode;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.logging.OnCompletionExecLogger;
import oracle.bi.ssl.openssl.OpensslCommands;
import oracle.bi.ssl.openssl.OpensslEndpoint;
import oracle.bi.ssl.pub.SSLException;

/**
 * Openssl client, based on the openssl comandline s_client.  The advantage of using s_client is that it is supported openssl code rather than 
 * our own client voiding the need to write our own standalone C++/C client separated off from the embedded code in OBIPS/OBIS.   However it 
 * does use exactly the same certificate options as the OBIPS/OBIS code so is a good crosscheck on certificate usage.
 * 
 * Openssl s_client has problems with hanging waiting for input on Windows.  See http://rt.openssl.org/Ticket/Display.html?id=3464&user=guest&pass=guest
 * This is due to it handling input from tty specially, ignoring input from stdin. There is currently no workaround.  The only option is to not 
 * use on windows. 
 */
public final class OpensslClient {
    private final static Logger logger = LoggerFactory.createLogger(OpensslClient.class);
    
    private final OpensslEndpoint opensslEndpoint;
    // Leave output in log file only.  We typically only want to echo WLST output to std out because WLST is so slow.  
    private final OnCompletionExecLogger execLogger = new OnCompletionExecLogger(logger, EchoMode.NO_ECHO);
    private final OpensslCommands openSSLCommands;
    
    
    public OpensslClient(SSLEnvironment sslEnvironment, OpensslEndpoint opensslEndpoint) throws SSLException{
        this.opensslEndpoint = opensslEndpoint;
        
        this.openSSLCommands = sslEnvironment.getOpensslCommands(sslEnvironment.getHomes().getDomainLocations().getSSLCommandDir(), execLogger);
        
    }
    
    public  OpensslPingResult ping(String host, int port){
        Objects.requireNonNull(host, "null host");
        try{
            // Sending any data on the openssl s_client command line seems unreliable.  Sometimes received by server before 
            // connection closed, sometimes not. 
            openSSLCommands.validateClient(opensslEndpoint, host, port);
            return OpensslPingResult.success(execLogger.toString());
        } catch (SSLException e){
            return OpensslPingResult.failed(execLogger.toString());
        } 
    }
}
