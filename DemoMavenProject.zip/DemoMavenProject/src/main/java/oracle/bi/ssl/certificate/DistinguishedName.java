package oracle.bi.ssl.certificate;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.security.auth.x500.X500Principal;

/**
 * Used to identify subject and issuer (signer) of certificates. 
 * Distinguished Name is often abbreviated to 'DN'. 
 * The most important field within the distinguished name is the common name (CN). 
 *
 */
public final class DistinguishedName {
    public final static int CN_MAX_LENGTH = 64;
    public final static int OU_MAX_LENGTH = 64;
    
    private final String commonName;
    private final String ou;

    /**
     * OU (Organization unit) for identity certificates which are fixed specials.  Eg server identity for system 
     * components, client identity, special 'localhost' identity.  
     */
    public static final String OU_FIXED = "Oracle Analytics fixed";
    
    /**
     * OU (Organization unit) for identity certificates which are created in response to dynamically created endpoint.  
     * Eg server identity for web logic managed server internal channels.   Using two different OU names ensures that 
     * we do not create a variable certificate with the same DN as an existing fixed certificate.  In practice this would 
     * only happen for variable certs with address 'localhost' which would clash with the fixed special 'localhost'. 
     * The openssl CA signing call fails if asked to sign the same DN twice.   
     */
    public static final String OU_VARIABLE = "Oracle Analytics variable";
    
    
    /**
     * If certificates are regenerated, then the ou field of the CA should be made unique.  This ensures 
     * that a client will not see two certificates with the same DN but different hashes.  Browsers 
     * will throw up errors if this happens.  Uniqueness also helps testing when intentionally 
     * mixing up multiple CAs to test trust. 
     * 
     * The uniqueness is just a convenience, avoiding browser warnings and confusion in tests.  It is 
     * not of any security significance so using a time is fine. 
     * @param commonName
     * @param ou
     */
    public static DistinguishedName createUnique(String commonName, String ouBase){
        final Date now = new Date();
        
        // Not static since find bugs complains that data format not concurrency safe. 
        // Performance not a problem since we only create a few DistinguishedName instances. 
        final SimpleDateFormat shortDateFormat = new SimpleDateFormat("yyMMddHHmmssZ");
        
        final String ou = ouBase + " " + shortDateFormat.format(now);
        return new DistinguishedName(commonName, ou);
    }
    
    public DistinguishedName(String commonName, String ou) {
        validateField("commonName", commonName);
        // According to RFC3280:
        //   maximum length of the common name is 64. See 'ub-common-name INTEGER ::= 64'.  Use subjectAlternateNames instead.
        //   maximum length of the OU is also 64.  See 'ub-organizational-unit-name INTEGER ::= 64'.
        if( commonName.length() > CN_MAX_LENGTH){
            throw new IllegalArgumentException("Subject common name (CN) '" + commonName + "' length " + commonName.length() + 
                    " exceeds max of " + CN_MAX_LENGTH);           
        }
        validateField("ou", ou);
        if( ou.length() > OU_MAX_LENGTH){
            throw new IllegalArgumentException("Organization Unit (OU) '" + ou + "' length " + ou.length() + 
                    " exceeds max of " + OU_MAX_LENGTH);           
        }
        
        
        this.commonName = commonName;
        this.ou = ou;
    }

    private static void validateField(String fieldName, String value){
        if( value == null ){
            throw new IllegalArgumentException("null " + fieldName);
        }
        if( value.isEmpty() ){
            throw new IllegalArgumentException("empty " + fieldName);
        }
        if( value.contains(",") ){
            // Can escape, but easier to forbid
            throw new IllegalArgumentException(fieldName + " contains  unsupported ',' character");
        }
        
        
    }
    public String getCommonName() {
        return this.commonName;
    }
    
    public String getOU(){
        return this.ou;
    }
    
    /**
     * To form used with openssl command line. 
     */
    public String toString(){
       return '/' + toSeparatedString('/');
    }
    
    /**
     * Return list of keys separated by separator
     * @return
     */
    private String toSeparatedString(char separator){
        return  "CN=" + commonName + separator + 
                "OU=" + ou + separator + 
                "O=Oracle" + separator + 
                "C=US";
    }
    
    public X500Principal toX500Principal(){
        return new X500Principal( toSeparatedString(','));
    }
}
