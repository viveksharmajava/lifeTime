package oracle.bi.ssl.online;

import java.util.ArrayList;
import java.util.List;

import oracle.bi.endpointmanager.pub.EndpointContext;
import oracle.bi.endpointmanager.pub.EndpointManager;
import oracle.bi.endpointmanager.pub.RegisteredEndpoint;
import oracle.bi.endpointmanager.pub.RegisteredEndpointList;

/*
 * Detects if the domain is online (ie running). 
 */
public final class OnLineDetector {
    private final EndpointManager endpointManager;
    
    /**
     * One endpoint type per process (managed server or system component). 
     */
    private final String[] endpointTypes = {"OBIJH", "OBIPS", "OBIS", "OBISCH", "OBICCS", "BI-SECURITY-SOAP"};
    
    public OnLineDetector(EndpointManager endpointManager){
        this.endpointManager = endpointManager;
    }
    
    /**
     * Check for running components.  Currently only BI components are included.  Admin server not yet 
     * checked. 
     * @return list of endpoints which are up.  Only one endpoint type per process is included. 
     */
    public List<RegisteredEndpoint> getUpEndpoints(){
        final TCPPing tcpPing = new TCPPing();
        
        final List<RegisteredEndpoint> upEndpoints = new ArrayList<RegisteredEndpoint>();
        for(String endpointType: endpointTypes){
            final RegisteredEndpointList endpoints = endpointManager.getRegisteredEndpointsByComponentType(endpointType, (EndpointContext) null);
            for( RegisteredEndpoint endpoint : endpoints.getEndpoints()){
                if( tcpPing.isReachableEndpoint(endpoint)){
                    upEndpoints.add(endpoint);
                }
            }
        }
        return upEndpoints;
    }
}
