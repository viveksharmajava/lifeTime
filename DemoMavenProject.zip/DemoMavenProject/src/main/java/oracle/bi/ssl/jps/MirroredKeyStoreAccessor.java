package oracle.bi.ssl.jps;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.security.Key;
import java.security.KeyStore;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.HashSet;
import java.util.Set;

import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.pub.SSLException;


/**
 * Provides consistent access to KeyStores which are held in multiple locations.  Writes are made to all copies.  
 * Reads are always made from the primary. 
 * 
 * Typically the primary is the 'real' keystore service copy. 
 * The optional secondary is a file system copy used by WebLogic in expanded domains.  Astonishingly WebLogic does not use the default keystore
 * service instead it uses the 'bootstrap' service which points to file <DomainHome>/config/keystores.xml
 *  
 */
final class MirroredKeyStoreAccessor implements KeyStoreAccessor
{
    
   private final KeyStoreAccessor primaryKeyStore;
   
   /**
    * May be null
    */
   private final KeyStoreAccessor mirroredKeyStore;
   
   
   
   /**
    * Wrap a KeyStore with convenience commands
    * @param mirroredKeyStore null if this configuration only has a single keystore
    */   
   MirroredKeyStoreAccessor(KeyStoreAccessor primaryKeyStore, KeyStoreAccessor mirroredKeyStore) throws SSLException
   {
       if( primaryKeyStore == null){
           throw new IllegalArgumentException("null primaryKeyStore");
       }
       this.primaryKeyStore = primaryKeyStore;
       this.mirroredKeyStore = mirroredKeyStore;
   }
   
   
   @Override
   public KeyStore getKeyStore(){
       return primaryKeyStore.getKeyStore();
   }
    
    
   @Override 
   public void exportKeyStoreToFile(File destFile, Passphrase passphrase) throws SSLException{
       primaryKeyStore.exportKeyStoreToFile(destFile, passphrase);
   }
   

   
   
   /*
    * Load a private key, in DER (binary) format with pkcs8 encoding together with its 
    * associated certificate chain in pem format. 
    */
   @Override
   public void loadPrivateKey(File keyFile, File certificateFile, Passphrase keyPassword, String alias) throws SSLException
   {
       primaryKeyStore.loadPrivateKey(keyFile,  certificateFile,  keyPassword, alias);
       if( mirroredKeyStore != null){
           mirroredKeyStore.loadPrivateKey(keyFile,  certificateFile,  keyPassword, alias);
       }
   }
   
   
   /**
    * Load a certificate in x509 format, into an existing keystore.
    * Allows us to sign a certificate using openssl, then load into the java world. 
    * 
    * 
    * @param certificateFile should contain a single x509 certificate
    * @param alias name for certificate entry in keystore.  This alias must be unused. 
    */
   @Override
   public void loadX509(File certificateFile, String alias) throws SSLException
   {
       primaryKeyStore.loadX509(certificateFile, alias);
       if( mirroredKeyStore != null){
           mirroredKeyStore.loadX509(certificateFile, alias);
       }
      
   }
   
   
   
   
   /** 
    * Load a private key, with its corresponding certificate chain.  
    * For our simple local Certificate Authority the certificate chain will consist of a 
    * single certificate - which is the corresponding public key.
    */
   @Override
   public void loadKey(String alias, Key key, Passphrase keyPassword, Certificate[] authenticationChain)
   throws SSLException
   {
       primaryKeyStore.loadKey(alias, key, keyPassword, authenticationChain);
       if( mirroredKeyStore != null){
           mirroredKeyStore.loadKey(alias, key, keyPassword, authenticationChain);
       }


   }
   
   @Override
   public void dumpKeyStoreDiagnosticsToFile(String name) throws SSLException, IOException{
      
       primaryKeyStore.dumpKeyStoreDiagnosticsToFile(name + "_primary");
       if( mirroredKeyStore != null){
           mirroredKeyStore.dumpKeyStoreDiagnosticsToFile(name + "_mirrored");
       }
   }
   
   @Override
   public void dumpKeyStoreDiagnostics(Writer w) throws SSLException{
       try {
           primaryKeyStore.dumpKeyStoreDiagnostics(w);
           
           if( mirroredKeyStore != null){
               
               final Set<Principal> primarySubjects = primaryKeyStore.getCertificateSubjects();
               final Set<Principal> mirroredSubjects = mirroredKeyStore.getCertificateSubjects();
               if( primarySubjects.equals(mirroredSubjects)){
                   w.write("Mirrored keystore " + mirroredKeyStore.getComment() + " consistent.\n");
               } else {
                   
                   w.write("WARNING: inconsistent keystores.  Consider running wlst command 'syncKeyStores'.\n");
                   mirroredKeyStore.dumpKeyStoreDiagnostics(w);
                   w.write("\n");
                   final Set<String> missingInPrimary = new HashSet<>();
                   for( Principal p: mirroredSubjects){
                       if( !primarySubjects.contains(p)){
                           missingInPrimary.add(p.getName());
                       }
                   }
                   final Set<String> missingInMirror = new HashSet<>();
                   for( Principal p: primarySubjects){
                       if( !mirroredSubjects.contains(p)){
                           missingInMirror.add(p.getName());
                       }
                   }
                   w.write("Missing from mirrored " + mirroredKeyStore.getComment()+ ":\n  " + String.join("\n  " ,missingInMirror) + "\n");
                   w.write("Missing from primary " + primaryKeyStore.getComment() + ":\n  " + String.join("\n  " ,missingInPrimary) + "\n");
               }
           } else {
               w.write("No mirrored key store\n");
           }
       } catch (IOException e) {
           throw new SSLException("Failed to write summary", e);
       }
       
   }
   
   
   /**
    * Load a single trusted certificate
    * @param alias local name
    * @param certificate 
    * @throws SSLException
    */
   @Override
   public void loadCertificate( String alias, Certificate certificate) throws SSLException
   {  
       primaryKeyStore.loadCertificate(alias,  certificate);
       if( mirroredKeyStore != null){
           mirroredKeyStore.loadCertificate(alias,  certificate);
       }
   }


    @Override
    public Set<Principal> getCertificateSubjects() throws SSLException {
        
        return primaryKeyStore.getCertificateSubjects();
    }


    @Override
    public String getComment() {
        final StringBuilder buff = new StringBuilder();
        buff.append( this.primaryKeyStore.getComment());
        if( this.mirroredKeyStore == null){
            buff.append( " - No mirror");
        } else {
            buff.append(" - mirror: " );
            buff.append( this.mirroredKeyStore.getComment());
        }
        return buff.toString();
    }

 
  
   
   
}
