package oracle.bi.ssl.exec;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;


/**
 * Allows command line executables to be run.  
 * This is based on Runtime.exec, with concurrent threads to consume the two outputs (stdout and errout) 
 * and optionally to feed stdin.  
 */
public final class Exec 
{
    private static final Logger _logger = LoggerFactory.createLogger(Exec.class);
    
    // Where to log stdout and stderr  
    private final ExecLogger execLogger;

    /**
     * Execute a command, logging at FINE line by line. 
     */
    public Exec(ExecLogger execLogger) {
       if( execLogger == null){
           throw new IllegalArgumentException("null execLogger");
       }
       this.execLogger = execLogger;
    }
   
    
    
    
    
   /**
    * Run a command line synchronously, logging output and error streams.  Also feeds in 
    * stdin to the sub-process. 
    * @param cmdArgs command and it's args.  Separate args must be presented as separate elements - 
    * this method does not support the exec(String commandLine) style. 
    * @param comment text included in errors and progress reports.
    * @param processInputs each element is piped into the running command's stdin as a separate line.  Typically used to pass security sensitive information.  As mutable 
    * char arrays rather than immutable strings to allow overwriting of passwords.
    * @return process status
    * @throws SSLException 
    */
   public ExecResult runCommandSynchronously(
                                        final File workingDir,
                                        final ProcessKiller processKiller,
                                        final Map<String, String>env,
                                        final List<String> cmdArgs, 
                                        final String comment, 
                                        final List<char[]> processInputs) throws SSLException
   {
      

      final String[] cmdArgsArray = cmdArgs.toArray(new String[ cmdArgs.size()]);
      // Do not use simple Arrays.toString.  It produces a comma separated list which you can't then just cut and paste to 
      // run manually in a command window when reproducing a problem. 
      final String cmdLine = String.join(" ", cmdArgsArray);
      
      
      
      
      final String summaryComment = "'" + comment + "' In " + workingDir + " Running: " + cmdLine + " with env " + env;
      _logger.log(Level.INFO, summaryComment);

      FilePrereqs.checkDirExists(workingDir, "workingDir");
      
      final ProcessBuilder processBuilder = new ProcessBuilder(cmdArgsArray);
      processBuilder.directory(workingDir);
      final Map<String, String> processEnv = processBuilder.environment();
      processEnv.clear();
      processEnv.putAll(env);
      
      final Process process;
      try {
         process = processBuilder.start();
         processKiller.setProcess(process);
      } catch (IOException e){
         throw new SSLException("Failed to launch sub process: " + comment,  e);
      }

      
      // any error message?
      final StdErrLineDestination stderrDest =  new StdErrLineDestination(comment, execLogger);
      
      final StreamGobbler stderrGobbler = new StreamGobbler(_logger, process.getErrorStream(), stderrDest);

      // any output?
      final StdOutLineDestination stdoutDest = new StdOutLineDestination(comment, execLogger);
      
      final StreamGobbler stdoutGobbler = new StreamGobbler(_logger, process.getInputStream(), stdoutDest);

      // stream in input to the process
      final StreamPusher streamPusher = new StreamPusher(process.getOutputStream(),  processInputs);
      
      // kick all three  off
      stderrGobbler.start();
      stdoutGobbler.start();
      
      
      streamPusher.start();


      final int status;

      // Wait for process - and the consuming threads - to complete. 
      try {
         status = process.waitFor();
         stderrGobbler.join();
         stdoutGobbler.join();
         streamPusher.join();
      } catch (InterruptedException e){
         throw new SSLException("Failed to consume output of: " +  comment, e);
      }

      final boolean success = (status == 0);
      execLogger.completed(success);

      _logger.log(Level.FINE, "Execute " + comment + " completed with status: " + status);
      
      if( status != 0){          
          throw new SSLCommandException(status, cmdLine, execLogger.getStderr() );
      }
      return new ExecResult(stdoutDest.getLines(), execLogger.getStderr());
   }


   


   

   

   /**
    * Push contents of array of strings to sub-process, sub-process may block either consuming this 
    * or writing its output.  Therefore push and read (stdout and errout) must all be on separate 
    * threads. 
    */
   private static final class StreamPusher extends Thread
   {
      private final OutputStream _os;

      private final List<char[]> _contents;

      StreamPusher(OutputStream os, List<char[]> contents){
         super("StreamPusher-" + nextThreadNum());
         this._os = os;
         this._contents =  contents;
      }

      /* For autonumbering the threads. */
      private static int threadInitNumber;
      private static synchronized int nextThreadNum() {
          return threadInitNumber++;
      }
      
      /**
       * Do the actual pushing.
       */
      @Override
      public void run()
      {
         try
         {
            final OutputStreamWriter osw = new OutputStreamWriter(this._os,
                    Charset.defaultCharset()/*make it explicit that we're relying on default encoding*/);
            final BufferedWriter bw = new BufferedWriter(osw);
            final PrintWriter pw = new PrintWriter(bw);

            for (char[] line:  _contents)
            { 
               // Echo out contents to subprocess's input stream  
               
               // Do not echo to System.out - could contain security sensitive data (which is probably why its being piped instead of 
               // included in command line). 
               // Do not use println.  This puts out a platform dependent line terminator.  Openssl read password assumes Unix style \n. 
               // Windows \r\n results in the \c being added to the password. 
               pw.print(line);
               pw.print('\n');
               pw.flush();
            }

            pw.flush();
            pw.close();
         }
         catch (final Exception e)
         {
            _logger.log(Level.WARNING,"Unexpected error ",e);
         }
      }
   }

  
}


