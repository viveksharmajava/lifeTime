package oracle.bi.ssl.pub;


import java.util.Arrays;
import java.util.List;

/**
 * Specifies SSL protocol options for Java clients and servers. 
 *
 */
public final class SSLProtocols {
    private final String baseProtocol;
    private final List<String> enabledProtocols;
    
    public static final String TLSv1 = "TLSv1";
    public static final String TLSv1_1 = "TLSv1.1";
    public static final String TLSv1_2 = "TLSv1.2";
    public static final String SSLv3 = "SSLv3";
    
    // see http://docs.oracle.com/javase/7/docs/technotes/guides/security/StandardNames.html#SSLContext
    // Note that TLS is more recent than the discredited SSLv2 and SSLv3. 
    
    // Openssl 1.0.0.? does not support TLS 1.1 or 1.2.  So cannot use TLSv1.1 or TLSv1.2 alone here. 
    
    // Just because the version of Openssl we are using does not support TLSv1.1 or 1.2 does not mean java components 
    // can't aim for 1.2. 
    public static final SSLProtocols INSECURE_V3= new SSLProtocols(SSLv3, SSLv3);
    public static final SSLProtocols COMPATIBLE= new SSLProtocols(TLSv1_2, TLSv1, TLSv1_1, TLSv1_2);
    public static final SSLProtocols INSECURE_SERVER = new SSLProtocols(TLSv1_2, SSLv3, TLSv1, TLSv1_1, TLSv1_2);
    public static final SSLProtocols TLSV1_2ONLY = new  SSLProtocols(TLSv1_2, TLSv1_2);
    /**
     * 
     * @param baseProtocol
     * @param enabledProtocols never null.  
     */
    private SSLProtocols(String baseProtocol, String... enabledProtocols) {
        if( baseProtocol == null){
            throw new IllegalArgumentException("null baseProtocol");
        }
        if( enabledProtocols == null){
            throw new IllegalArgumentException("null enabledProtocols");
        }
        this.baseProtocol = baseProtocol;
        this.enabledProtocols = Arrays.asList(enabledProtocols);
    }

    /**
     * The base protocol is the protocol to be used.  Typically each protocol includes and downgrade option to allow client and 
     * server to negotiate a lower protocol. Eg base protocol of TLS allows an SSLv3 client to connect.  Note that the history of 
     * SSL protocols is:
     *    SSLv2
     *    SSLv3
     *    TLS1.1
     *    TLS1.2
     *    
     * So TLS is more recent (and therefore considered more secure) that SSLv2 or v3.
     * @return
     */
    public String getBaseProtocol() {
        return baseProtocol;
    }

    /**
     * Controls which sub protocols are supported.  So to only allows TLS1.2 set base to TLS1.2 and set enabled protocols to TLS1.2.
     * @return
     */
    public String[] getEnabledProtocols() {
        return enabledProtocols.toArray( new String[enabledProtocols.size()]);
    }
    
    
    @Override
    public String toString(){
        return baseProtocol + enabledProtocols;
    }
    
}
