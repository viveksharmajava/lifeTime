/**
 * Execution of command line tools.  Supports delivering stdin to the command lines to provide a secure method 
 * of passing passwords.  Both stderr and stdout are logged.  Stdout is captured.  
 */

package oracle.bi.ssl.exec;