package oracle.bi.ssl.certificate;

import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import oracle.bi.ssl.pub.SSLException;

/**
 * Generates summary information about the expiry dates of our certificates. 
 * 
 *
 */
public final class ExpirySummary {
    // Use date format default constructor so get localized format. 
    private final SimpleDateFormat dateFormat = new SimpleDateFormat();
    
    private final Collection<X509Certificate> caCerts;
    private final Collection<X509Certificate> identityCerts;
    
    final CertificateStats certificateStats = new CertificateStats();
    
    public ExpirySummary(IdentityFactory factory) throws SSLException{
        // Note that if our keystore does not exist, will create an empty one. 
        caCerts = factory.listCACertificates();
        identityCerts = factory.listIdentityCertificates();
        certificateStats.collectStatsOnCertificates(caCerts);
        certificateStats.collectStatsOnCertificates(identityCerts);
    }
    
    public String getList() throws SSLException{
        final StringBuilder buff = new StringBuilder();
        // Include todays date.  It makes understanding the format of future dates easier for the user. 
        buff.append("Certificate expiry dates on " +  dateFormat.format(new Date() ) + "\n\n");
        
        buff.append("Certificate Authority (CA) certificates\n");
        for( X509Certificate caCert : caCerts){
            summaryForCert(buff, caCert);
        }
        buff.append("Server certificates\n");
        for( X509Certificate cert : identityCerts){
            summaryForCert(buff, cert);
        }
        return buff.toString();
    }
    
    private boolean isMissingCertificateCategory(){
        // Ideally would check all certificates - both in the keystore and openssl certificate files.
        // Here we just do a simplistic check designed to catch case where generate certs has never been run
        // or a gross deletion of certificates.  Note this is a stricter check 
        // than certificateStats.getCount() == 0 which cehcks both categories empty. 
        return this.caCerts.isEmpty() || this.identityCerts.isEmpty();
    }
    private void summaryForCert(StringBuilder buff, X509Certificate cert) throws SSLException{
        buff.append("   ");
        buff.append(getCN(cert));
        buff.append(" ");
        buff.append(dateFormat.format(cert.getNotAfter()));
        buff.append("\n");
    }
    
    private static String getCN(X509Certificate cert) throws SSLException {
        final CertificateSubjectNames certificateSubjectNames = new CertificateSubjectNames(cert);
        return certificateSubjectNames.getCommonName();
    }
    
    
    /**
     * Get overall status in form suitable for further processing.  
     * @return
     */
    public ExpiryResult getResult() throws SSLException {
        if( isMissingCertificateCategory() ){
            return ExpiryResult.MISSING;
        } else if( certificateStats.expired() ){
            return ExpiryResult.EXPIRED;
        } else if (certificateStats.soonToExpire(30)){
            return ExpiryResult.WARNING;
        } else {return ExpiryResult.OK;  
        }
    }
    
    public String getResultString() throws SSLException {
        final StringBuilder buff = new StringBuilder();
        if( isMissingCertificateCategory() ){
            buff.append("Certificates are missing.  You should run ssl[.sh] regenerate. ");
            buff.append("\n");
        } else {
            buff.append("The first certificate to expire will expire on: ");
            buff.append(dateFormat.format(certificateStats.getFirstToExpire().getNotAfter()));
            buff.append("\n");
            buff.append( getResult().getResultString());
        }
        return buff.toString();
    }
}
