package oracle.bi.ssl.exec;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.logging.Level;
import java.util.logging.Logger;

/** 
 * Consume contents of a stream. Echo to a LineDestination
 */
final class StreamGobbler extends Thread {
    /* For autonumbering the threads. */
    private static int threadInitNumber;

    private final InputStream _is;

    private final LineDestination _lineDestination;
    
    private final Logger _logger;

    StreamGobbler(Logger logger, final InputStream is, 
            LineDestination lineDestination) {
        super("StreamGobbler-" + nextThreadNum());
        this._logger = logger;
        this._is = is;
        this._lineDestination = lineDestination;
    }


    private static synchronized int nextThreadNum() {
        return threadInitNumber++;
    }

    /**
     * Do the actual gobbling.
     */
    @Override
    public void run(){
        try {
            final InputStreamReader isr = new InputStreamReader(this._is,
                    Charset.defaultCharset()/*make it explicit that we're relying on default encoding*/);
            final BufferedReader br = new BufferedReader(isr);
            String line = null;
            while ((line = br.readLine()) !=  null){
                // Echo out contents
                this._lineDestination.consumeLine(line);
            }
        } catch (final IOException ioe){
            _logger.log(Level.FINE, "Exception during sub-process output consumption", ioe);
        }
    }
}
