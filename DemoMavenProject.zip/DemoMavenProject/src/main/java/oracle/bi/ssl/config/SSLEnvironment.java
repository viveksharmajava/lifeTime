package oracle.bi.ssl.config;

import java.io.File;
import java.util.Objects;

import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.openssl.OpensslCommands;
import oracle.bi.ssl.pub.SSLException;

/**
 * Information about the domain and oracle home - including config settings - which is passed throughout the SSL stack. 
 * 
 *
 */
public final class SSLEnvironment {
    private final Homes homes;
    private final SSLConfigWrapper configWrapper;
    
    private boolean opensslVersionChecked = false;
    
    /**
     * Use the standard stripe to hold SSL artifacts such as certificates.  Unless you need multiple certificates for testing 
     * use this one. 
     * @param homes
     * @throws SSLException
     */
    public SSLEnvironment(Homes homes) throws SSLException {
        this(homes,null);
    }
    
    /**
     *  
     * @param homes
     * @param stripe if non-null Point at non-standard stripe.  For testing use. 
     * @throws SSLException
     */
    public SSLEnvironment(Homes homes, String stripe) throws SSLException {
        this.homes = Objects.requireNonNull(homes, "null homes");
        this.configWrapper = new SSLConfigWrapper(homes.getDomainLocations(), stripe);
    }
    
    /**
     * Return openssl command line wrapper.  On first call checks the version.  Checking the version involves an exec, so 
     * best to do this once rather than every time an openssl command is run. 
     * 
     * @param workingDir
     * @param execLogger
     * @throws SSLException 
     */
    public OpensslCommands getOpensslCommands(File workingDir, ExecLogger execLogger) throws SSLException{
        final OpensslCommands opensslCommands = new OpensslCommands(this, workingDir, execLogger);
        // Could be concurrently using this.opensslVersionChecked.
        synchronized(this){
            if( !this.opensslVersionChecked){
                opensslCommands.checkVersion();
                this.opensslVersionChecked = true;
            }
        }
        return opensslCommands;
    }
    

    public Homes getHomes() {
        return homes;
    }

    public SSLConfigWrapper getConfigWrapper() {
        return configWrapper;
    }
    
    
}
