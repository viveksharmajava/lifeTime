package oracle.bi.ssl.ping;

import oracle.bi.endpointmanager.pub.RegisteredEndpoint;
import oracle.bi.ssl.certificate.EndpointHelper;
import oracle.bi.ssl.ping.java.JavaPingOK;
import oracle.bi.ssl.ping.java.JavaPingResult;
import oracle.bi.ssl.ping.openssl.OpensslPingResult;
import oracle.bi.ssl.ping.openssl.OpensslPingResult.OpensslState;

/**
 * Pings return structured data rather than just appending to logs or stdout.  This allows the ping result to be used by 
 * different UIs.  Eg a simple command line or web based tool such as Enterprise Manager. 
 * @author pharry
 *
 */
public final class PingResult {

    private final RegisteredEndpoint target;
    private final JavaPingResult javaPingResult;
    private final OpensslPingResult opensslPingResult;
    private final boolean sslPortConfigured;
    
    /**
     * SSL not configured.  Pings not carried out. 
     * @param target
     */
    public PingResult(RegisteredEndpoint target){
        this.target = target;
        this.sslPortConfigured = false;
        javaPingResult = null;
        opensslPingResult = null;
    }
    
    /**
     * SSL is configured.  Pings carried out. 
     * @param target
     * @param javaPingResult
     * @param opensslPingResult may be null if it was not run.  Openssl ping can be slow so depending on the java result may not be run. 
     */
    public PingResult(
            RegisteredEndpoint target, 
            JavaPingResult javaPingResult,
            OpensslPingResult opensslPingResult) {
        if( target == null){
            throw new IllegalArgumentException("null target");
        }
        if( javaPingResult == null){
            throw new IllegalArgumentException("null javaPingResult");
        }
        this.target = target;
        this.javaPingResult = javaPingResult;
        this.opensslPingResult = opensslPingResult;
        this.sslPortConfigured = true;
    }

    public RegisteredEndpoint getTarget() {
        return target;
    }

    public boolean getSSLPortConfigured(){
        return sslPortConfigured;
    }
    /**
     * Null if getSSLPortConfigured false;
     * @return
     */
    public JavaPingResult getJavaPingResult() {
        return javaPingResult;
    }

    /**
     * Null if getSSLPortConfigured false or openssl ping not carried out;
     * @return
     */
    public OpensslPingResult getOpensslPingResult() {
        return opensslPingResult;
    }
    
    /**
     * 
     * @return true if ping succeeded, or ping not run. 
     */
    private boolean opensslPingSuccess(){
        if(getOpensslPingResult() == null ){
            return true;
        } else {
            return getOpensslPingResult().getSSLState() == OpensslState.OPENSSL_OK;
        }
    }
    
    /**
     * Ping ok if ssl is configured and both Java and Openssl stacks ping successfully. 
     * @return
     */
    public boolean isPingSuccess(){
        return sslPortConfigured && 
                      getJavaPingResult() instanceof JavaPingOK &&
                            opensslPingSuccess();
        
    }
    
    
    
    /**
     * Brief summary. 
     */
    public String getSummary(){
        if( sslPortConfigured ){
            if(opensslPingResult == null ){
                // Openssl not run
                return "Target: " + getTargetSummary() + "\n  Java client: " + javaPingResult.getSummary();
            } else {
                // Openssl run.   Don't assume why - in case the algorithm for optimising which is run changes. 
                if(javaPingResult.getSSLState() != JavaPingResult.JavaSSLState.SSL_OK && opensslPingResult.getSSLState() == OpensslPingResult.OpensslState.OPENSSL_OK){
                    // Most common case - java (which checks CN and SSLv3) failed openssl ok.  So print compact result
                    return "Target: " + getTargetSummary() + "\n  Java client: " + javaPingResult.getSummary();
               } else {
                    return "Target: " + getTargetSummary() + "\n  Java client: " + javaPingResult.getSummary() + "\n  Openssl client: " + opensslPingResult.getSummary();    
               }                
            }  
        } else {
            return "Target: " + getTargetSummary() + " no SSL port configured";
        }
    }
    @Override 
    public String toString(){
        if( sslPortConfigured ){
            String ret;
            ret = "Target: " + getTargetSummary() + "\n  Java client: " + javaPingResult;
            if( opensslPingResult != null){
                ret += "\n  " + "Openssl client: " + opensslPingResult;
            }
            return ret;
        } else {
            return "Target: " + getTargetSummary() + " no SSL port configured";
        }
    }
    
    private String getTargetSummary(){
        return target.getInstanceId() + ":" + target.getComponentType() + " @ " + EndpointHelper.getEffectiveClientListenAddress(target) + ":" + getEffectiveSSLPort();
    }
    
    
    
    private int getEffectiveSSLPort(){
        // Endpoint api should isolate us from this fiddle. 
        if( target.getSSLPort() == null){
            return target.getPort();
        } else {
            return target.getSSLPort();
        }
    }
}
