package oracle.bi.ssl.exec;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.files.OSUtils;
import oracle.bi.ssl.pub.SSLException;

/**
 * Defines where an executable can be found.  Supports both windows and linux flavours.  
 * The choice of which one to use is made late, so that checks on OS flavour are isolated inside the {@link Exec} class. 
 *
 */
public final class Executable {
    private final File executableLinux; 
    private final File executableWindows;
    
    /**
     * 
     * @param executableLinux null if not supported
     * @param executableWindows null if not supported
     */
    public Executable(File executableLinux, File executableWindows) {
        this.executableLinux = executableLinux;
        this.executableWindows = executableWindows;
    }

    /**
     * 
     * @throw if not supported on this platform
     */
    private File getExecutableFileLinux() {
        if( executableLinux == null){
            throw new IllegalStateException("Not supported on Linux");
        }
        return executableLinux;
    }

    /**
     * 
     * @throw if not supported on this platform
     */
    private File getExecutableFileWindows() {
        if( executableWindows == null){
            throw new IllegalStateException("Not supported on Windows");
        }
        return executableWindows;
    }
    
    /**
     *
     * @return location of executable for current platform
     */
    public File getExecutableFile(){
        if( OSUtils.isWindowsFamily()){
            return getExecutableFileWindows();
        } else {
            return getExecutableFileLinux();
        }
    }
    
    /**
     * Return invocation (without any parameters) for current operating system. 
     * @param executable
     * @return
     * @throws SSLException 
     */
    public List<String> getExecutableLaunchArgs() throws SSLException{
        if( OSUtils.isWindowsFamily()){
            final File executableWindows = this.getExecutableFileWindows();
            FilePrereqs.checkNonEmptyFile(executableWindows, "windows executable");
         
            // cmd
            //    start is not a program - its a command in the command interpretter so need to run the 
            //    command interpretter.
            // 
            // start
            //    Must start a window, since openssl gets its randomness from the screen.  
            //    If run directly from Runtime.exec, openssl.exe just hangs waiting for 
            //    randomness. 
            // 
            // \"BI\"
            //    window title must be in double quotes - or else windows thinks it is the command to run
            //    Do not use -passin pass:password since on some OS's ps shows arg line
            // 
            // /b 
            //    Disables starting a new window - but the randomgenerator from display still works!
            //    Critically this means that we can capture output since it goes to the shell we 
            //    exec, so errors become visible. 
            //
            // /wait
            //    Invoke synchronously. 
            // 
           
            
            // Working dir may be different to current process's working dir, so convert executable to absolute path so it can be found.
            return Arrays.asList(
                "cmd", "/C", "start", "/b", "\"BI\"", "/WAIT",  executableWindows.getAbsolutePath()  );
         } else {
            final File executableLinux = this.getExecutableFileLinux();
            
            FilePrereqs.checkNonEmptyFile(executableLinux, "Linux executable");
            // Working dir may be different to current process's working dir, so convert executable to absolute path so it can be found.
            return Arrays.asList( executableLinux.getAbsolutePath() );

         }
    }
    
}
