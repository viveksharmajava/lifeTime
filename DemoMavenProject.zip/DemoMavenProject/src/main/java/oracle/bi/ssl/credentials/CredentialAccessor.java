package oracle.bi.ssl.credentials;




import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.jps.JPSServiceAccessor;
import oracle.bi.ssl.locations.DomainLocations;
import oracle.bi.ssl.pub.SSLException;
import oracle.security.jps.service.credstore.CredStoreException;
import oracle.security.jps.service.credstore.Credential;
import oracle.security.jps.service.credstore.CredentialFactory;
import oracle.security.jps.service.credstore.CredentialMap;
import oracle.security.jps.service.credstore.CredentialStore;
import oracle.security.jps.service.credstore.PasswordCredential;

/**
 * keys for use with the credential store. 
 * @author pharry
 *
 */
public final class CredentialAccessor {
    private static final String SSL_CREDENTIAL_MAP = "oracle.bi.enterprise";
    
    // Passphrase for server keys and trust/identity keystores. 
    public static final String SSL_INTERNAL_PASSPHRASE = "ssl.passphrase";
    
    // Passphrase for internal CA key. This is the most security sensitive since with it (and access to key file) 
    // forged server certificates could be created. 
    public static final String SSL_INTERNAL_CA_PASSPHRASE = "ssl.capassphrase";
    
    
    private final CredentialStore credentialStore;
    
    public CredentialAccessor(DomainLocations domain) throws SSLException{
        final JPSServiceAccessor jps = new JPSServiceAccessor(domain);
        credentialStore = jps.getRuntimeJpsContext().getServiceInstance(CredentialStore.class);        
    }

    private void storePasswordCredential(String credentialMapName, 
            String credentialKey, 
            String credentialUsername,
            char[] password
            ) throws Exception {
        // Not sure how well underlying layers report bad parameters, so be protective. 
        if( credentialMapName == null){
            throw new IllegalArgumentException("null credentialMapName");
        }
        if( credentialKey == null){
            throw new IllegalArgumentException("null credentialKey");
        }
        if( credentialUsername == null){
            throw new IllegalArgumentException("null credentialUsername");
        }
        if( password == null){
            throw new IllegalArgumentException("null password");
        }
        if( password.length == 0){
            // PasswordCredential constructor rejects empty passwords.
            throw new IllegalArgumentException("empty password");
        }

        final boolean newMap;
        CredentialMap credentialMap = credentialStore.getCredentialMap(credentialMapName);
        if (credentialMap == null) {
            credentialMap = CredentialFactory.newCredentialMap();
            newMap = true;
        } else {
            newMap = false;
        }

        // Create first so if creation throws (eg password unacceptable), will not have deleted any existing credential. 
        final PasswordCredential credential = CredentialFactory.newPasswordCredential(credentialUsername, password);

        if( credentialMap.containsKey(credentialKey) ){
            credentialMap.deleteCredential(credentialKey);
        }

        credentialMap.setCredential(credentialKey, credential);

        // Must call setCredentialMap after adding the credential for new map, or credential is ignored. 
        if (newMap) {
            credentialStore.setCredentialMap(credentialMapName, credentialMap);
        }
    }
    
    
    public void savePassphrase(Passphrase passphrase, String key) throws SSLException{
        try {
            storePasswordCredential(
                    SSL_CREDENTIAL_MAP, key, "sslUser", passphrase.getPassphraseChars());
        } catch (Exception e) {
            throw new SSLException("Unable to save passphrase at key " + key + " due to " + e, e);
        }
    }
    
    /**
     * Get passphrase from the credential store
     * @return
     * @throws SSLException if not found
     */
    public Passphrase getPassphrase(String key ) throws SSLException{
        final Passphrase ret = getOptionalPassphrase(key);

        if ( ret == null){
            throw new SSLCredentialMissingException(key);
        }
        return ret;
    }

    /**
     * Check if passphrase exists - the passphrase read is correctly shredded. 
     * @param key
     * @return
     * @throws SSLException
     */
    public boolean passphraseExists(String key)throws SSLException{
        
        final Passphrase passphrase = getOptionalPassphrase(key);
        if( passphrase == null){
            return false;
        } else {
            passphrase.close();
            return true;
        }
    }

    /**
     * Get credential from the credential store
     * @param key
     * @return Return null if does not exist. 
     * @throws SSLException
     */
    public Passphrase getOptionalPassphrase(String key) throws SSLException{

        final Credential credential;
        try {
            credential = credentialStore.getCredential(CredentialAccessor.SSL_CREDENTIAL_MAP, key);
        } catch ( CredStoreException e){
            throw new SSLException("Failed to read credential " +key, e);
        }
        if( credential == null){
            return null;
        }
        if( !(credential instanceof PasswordCredential) ){
            throw new SSLException("Credential " + key + " is " + credential.getClass() + " not  a password credential");
        }
        final PasswordCredential pwCredential = (PasswordCredential)credential;

        return new Passphrase(pwCredential.getPassword());
    }
}
