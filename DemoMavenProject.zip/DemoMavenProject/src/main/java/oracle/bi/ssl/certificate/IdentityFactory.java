package oracle.bi.ssl.certificate;

import java.io.File;
import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.endpointmanager.pub.EndpointManager;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.credentials.CredentialAccessor;
import oracle.bi.ssl.files.AutoDeletingTempDir;
import oracle.bi.ssl.locations.CertificateLocations;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.locations.KeystoreNames;
import oracle.bi.ssl.locations.OpensslCertificateFileLocations;
import oracle.bi.ssl.logging.EchoMode;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.logging.OnCompletionExecLogger;
import oracle.bi.ssl.pub.CertOptions;
import oracle.bi.ssl.pub.SSLException;

import org.apache.commons.io.FileUtils;



/**
 * Supports construction and storage of the certificates created for the BI components.
 * 
 *  
 *  
 * There are three SSL stacks 
 *    - openssl used by the BIEE C++ components, 
 *    - Oracle's C++ library used by Essbase, and 
 *    - JSSE used by the Java components.  
 *    
 * They store the certificates in different store types.  Java components use the Java JKS Keystores 
 * stored JPS KeyStore service, Essbase uses Oracle Wallets, and openssl uses individual pem (or der) certificate files. 
 * 
 * The certificates created are:
 *      CN="OBIEE Internal Certificate Authority".  Internal BIEE CA.  Self signed (since it is a CA).
 *      
 *      Following certificates are signed by the above internal CA:
 *         CN="OBIEE Server Openssl".  openssl server certificate - fixed CN, so can only be used by clients who know they are using internal trust. 
 *         
 *         CN="OBIEE Client".  openssl certificate for clients.  Only used if two way SSL is in force (server is checking clients certs). 
 *         
 *         CN="OBIEE Generic Server".  Java generic certificate - fixed CN, so can only be used by clients who know they are using internal trust.
 *          
 *         CN=<Address> eg "myserver.acme.com".  One java certificate for each distinct listener address, 
 *         with CN matching address.  These are therefore compatible with general HTTPS usage. Optionally with a Subject Alternative Name. 
 *      
 *      The use of separate certificates for java and openssl stacks is of no semantic interest - it just makes storing the certificates in the 
 *      corresponding keystore types easier.  The client certificate is separate since in the future we may use separate client certificates  
 *      versus internal identities to distinguish between lowly client authentication and internal authentication as a 'super user'  for calls between 
 *      system components.   
 *      
 * The Internal BIEE CA is also added to trust stores. 
 */
public final class IdentityFactory
{
    private final static Logger logger = LoggerFactory.createLogger(IdentityFactory.class);
    
    
    private final OpenSSLIdentityFactory openSSLIdentityFactory;
    private final JavaIdentityFactory javaIdentityFactory;
    
   
    private final CertificateLocations certificateLocations;
    private final SSLEnvironment sslEnvironment;
    
    private final ExecLogger execLogger;
    private final CredentialAccessor credentialAccessor;
    
    private final KeyStoreType keyStoreType;
    
    // Common name used for the internal CA certificate.  Includes the phrase 'Certificate Authority' since that makes 
    // understanding certificate chains in the output of openssl s_client -connect much easier. 
    final static String INTERNAL_CN = "OBIEE Internal Certificate Authority";
    private final static String INTERNAL_OU = "OBIEE Installer";
    
    
    
    /**
     * @param stripe Allow stripe to be chosen.  If stripe is null default is used 
     */
    public IdentityFactory(SSLEnvironment sslEnvironment, KeyStoreType keyStoreType, EndpointManager endpointManager) throws SSLException{    
        this.sslEnvironment = Objects.requireNonNull(sslEnvironment, "null sslEnvironment");
        this.keyStoreType = keyStoreType = Objects.requireNonNull(keyStoreType, "null keyStoreType");
        
        if( endpointManager == null){
            throw new IllegalArgumentException( "null endpointManager");
        }
        
        
        
        // oracleHome and domainLocations may be relative.  So long as we stay within this process they remain valid. 
        // They will be converted to absolutePath when we cross a process boundary, eg on launching a sub-process. 
        // Conversion at the point of need is preferable to conversion at the boundary of the system since the boundary is 
        // not definable.  A test of a sub-system defines boundary as the subsystem.  This would result in repeated just in case 
        // conversion at multiple layers which is inconsistent. Note we may convert at multiple logging points since an absolute 
        // path is more informative in a log message. 
        final Homes homes = sslEnvironment.getHomes();
        this.credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        
        
        this.certificateLocations = new CertificateLocations(homes.getDomainLocations());
        execLogger = new OnCompletionExecLogger(logger, EchoMode.NO_ECHO);
        openSSLIdentityFactory = new OpenSSLIdentityFactory(sslEnvironment);
        javaIdentityFactory = new JavaIdentityFactory(sslEnvironment, endpointManager);
        
        
    }
    
    /**
     * Return all our internal CA certificates
     * @return
     * @throws SSLException
     */
    public List<X509Certificate> listCACertificates() throws SSLException{
        try (Passphrase passphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
            return javaIdentityFactory.listCACertificates(passphrase);
        }
    }
    
    /**
     * Return all identity certificates.  This allows them to be checked for expiry dates.  Currently we only return the Java ones,
     * since they are conveniently accessible. 
     * @return
     * @throws SSLException
     */
    public List<X509Certificate> listIdentityCertificates() throws SSLException{
        try (Passphrase passphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
            return javaIdentityFactory.listIdentityCertificates(passphrase);
        }
    }

    /**
     * Create new internal CA and internal certificates.  Constructs a new internal certificate authority, and uses that to sign 
     * internal certificates.  The new CA and signed certificates are stored both in individual files for use by openssl,
     * and in the internal BI trust/identity keystores within the keystore service.  
     * The new CA has a new passphrase.   The keystore keyphrase remains unchanged, so any existing channels (which contain 
     * the encrypted passphrase) do not need to be reconfigured. 
     * <p>
     * Existing passphrases for both server certificates and certificate authority are respected.  
     * </p>
     * <p>
     * Reusing the server certificate passphrase avoids the need to update the WebLogic channel configuration to have the new passphrase. 
     * Reusing all passphrases allows the passphrases to be optionally chosen in advance by provisioning code.  This simplifies 
     * disaster recovery configurations where database content is propagated from a primary system to a secondary system.  Database 
     * content includes the contents of the credential store. In such DB 
     * synchronized systems the domain file systems are not synced.  If both primary and secondary chose their own passphrases they would be 
     * different, so the certificates stored in the file system would be secured by different passphrases.  Once primary to secondary 
     * DB sync takes place the secondary would have the primary's passphrases which would not match the secondary's file based certificates.   
     * </p>
     * <p>
     * By pre-populating the passphrases we force primary and secondary to use the same values, so overwriting secondary with 
     * primary has no effect.   
     * </p>
     * <p>
     * A possible enhancement would be to allow optional replacement of passphrases to provide a reset if the passphrases have ben 
     * compromised or a security audit requires regular replacement.  
     * </p>
     * @return subject DNs of generated identity certificates.  To provide feedback in UI. 
     */
    public List<DistinguishedName> generateInternalCertificates(CertOptions certOptions) throws SSLException {
        final List<DistinguishedName> subjects;
        // Ensure passphrases are cleared even after exceptions.  Clears passphrases by auto closing from try with resources block. 
        try (Passphrase oldServerPassphrase = credentialAccessor.getOptionalPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);
             Passphrase oldCaPassphrase = credentialAccessor.getOptionalPassphrase(CredentialAccessor.SSL_INTERNAL_CA_PASSPHRASE);
             
             // Use the existing passphrases. 
             Passphrase serverPassphrase = oldServerPassphrase == null ? Passphrase.randomPassphase() : oldServerPassphrase;
             Passphrase caPassphrase = oldCaPassphrase == null ? Passphrase.randomPassphase() : oldCaPassphrase){
           
            if( oldServerPassphrase != null){
                // If we do not clear existing keystore get alias already exists errors when recreating the contents. 
                logger.log(Level.FINE, "Clearing existing keystores"  );
                javaIdentityFactory.cleanKeyStores(oldServerPassphrase);
            }

            logger.log(Level.FINE, "Clearing existing internal certificate files"  );
            openSSLIdentityFactory.cleanOpensslCertificates();
            
            logger.log(Level.FINE, "Clearing existing wallets"  );
            final File walletsHomeDir = certificateLocations.getWalletLocations().getWalletsHomeDir();
            
            try {
                FileUtils.forceMkdir(walletsHomeDir);
                FileUtils.cleanDirectory(walletsHomeDir);
            } catch (IOException e){
                throw new SSLException("Failed to empty wallets home dir " + walletsHomeDir, e);
            }
            
            final Passphrases passphrases = new Passphrases(caPassphrase, serverPassphrase);
            subjects = generateCertificatesImpl(passphrases, certOptions);
            storePassphrases(passphrases);
        }
        
        try( Passphrase sslPassphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
             javaIdentityFactory.checkKeyStores(sslPassphrase, keyStoreType);
        }
        return subjects;
    }
    
    
    
    /**
     * Add any missing listener identity certificates using same CA as existing listener identity certificates.  Use the same 
     * expiry date as existing certificates. 
     * Use same passphrase to protect the new keys. 
     * @return
     * @throws SSLException
     */
    public List<DistinguishedName> topUpListenerCertificates() throws SSLException{
        // Use try with resources to ensure passphrase is cleared out after use. 
        try ( Passphrase caPassphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_CA_PASSPHRASE);
              Passphrase sslPassphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){   
               logger.log(Level.FINE, "Topping up listener certificate files"  );
               final List<DistinguishedName> subjects = javaIdentityFactory.topUpListenerCertificates(caPassphrase, sslPassphrase);
               return subjects;
        } 
    }
    
   
   
    
    

    // ------------------------------------------------ Private methods ----------------

    
    
    

    /**
     * Create Java, openssl, and Oracle Wallet certificate stores and populate them.   The Certificate authority directory 
     * (including key) are persisted so the CA can be reopened later to top up certificates if new listeners are added. 
     * 
     * Multiple transient file artifacts are created.  These are deleted.  
     * 
     * @return subject DNs of generated certificates
     */
    private List<DistinguishedName> generateCertificatesImpl( Passphrases passphrases, CertOptions certOptions) throws SSLException {   
        // Record options so that on regeneration of missing certs can reuse options.  This simplifies the command line, 
        // and avoids the danger of having a hybrid population of certificates with different host name options. 
        final Homes homes = sslEnvironment.getHomes();
        try {
            CertOptionsStore.storeCertOptions(homes.getDomainLocations().getSSLCertOptions(), certOptions);
        } catch (IOException e) {
            throw new SSLException("Unable to store cert options", e);
        }
        
        // sslTmpDir is shared - cannot assume can delete it all. 
        final File sslTmpDir = homes.getDomainLocations().getTmpSSL();
        final File caDir = this.certificateLocations.getOpensslCertificateLocations().getInternalCADir();
        // Create a temp directory tStringo hold our temp files so we can delete at end of try with resources block
        
        try( final AutoDeletingTempDir certsTempDir = new AutoDeletingTempDir(sslTmpDir, "certs");){
             final List<DistinguishedName> subjects = new ArrayList<>();
             
             final DistinguishedName caDN = DistinguishedName.createUnique(INTERNAL_CN, INTERNAL_OU);
             final CertificateAuthority privateCA = 
                     CertificateAuthority.mkNewRootCA(
                             sslEnvironment, 
                             caDir,
                             execLogger, 
                             passphrases.getCaKeyPassphrase(), 
                             caDN,
                             certOptions.getExpiryDays() );
            subjects.add(caDN);
            // Create identity certificate for use by openssl.  Store in individual certificate/key files.
            subjects.addAll(
                    openSSLIdentityFactory.createOpensslIdentities(certsTempDir.getDir(), passphrases.getServerKeyPassphrase(), privateCA));
            subjects.add(openSSLIdentityFactory.createOpensslLocalhostIdentity(certOptions.getSanOption(),
                    certsTempDir.getDir(), passphrases.getServerKeyPassphrase(), privateCA));

            final KeystoreNames keystoreNames = certificateLocations.getKeyStoreNames();
            
            // Create internal identity certificate for use by components using Java KeyStore - ie Java components.  Store in JPS Keystore service.
            // Create one general certificate for use by javahost and other non https servers.  
            final String jksCN = "OBIEE jks Server";
            final DistinguishedName dn = new DistinguishedName( jksCN, DistinguishedName.OU_FIXED);
            final String serverAlias = keystoreNames.getServerIdentityAlias();
            final boolean created = javaIdentityFactory.createJavaIdentityCertificate(certsTempDir.getDir(), 
                                          passphrases.getServerKeyPassphrase(), 
                                          passphrases.getKeystorePassphrase(), 
                                          privateCA,
                                          dn,
                                          new CertificateExtensions(),
                                          serverAlias);
            if( !created){
                // We are regenerating all certificates.  We do not expect any alias values to already exist. 
                throw new SSLException("Certificate alias " + serverAlias + " already exists");
            }
    
            subjects.add(dn);

            subjects.addAll(javaIdentityFactory.createIdentityCertificatesForListenerAddresses(
                                          certsTempDir.getDir(),
                                          certOptions.getSanOption(),
                                          passphrases.getServerKeyPassphrase(), 
                                          passphrases.getKeystorePassphrase(), 
                                          privateCA));



            // Store trust for use by internal components (to verify servers, and optionally to verify clients).
            final OpensslCertificateFileLocations locations = this.certificateLocations.getOpensslCertificateLocations();
            final String pemFileName = locations.getInternalTrustCert().getName();
            openSSLIdentityFactory.addOpensslInternalTrust(privateCA, locations.getInternalTrustDir(), pemFileName);
            
            // Store trust for use by components talking to WebLogic.  If all web apps are targetted on our internal channels, then they use internal certificates 
            // so the trust is identical to the internal trust.  If they are targeted to public ports, then the synctrust commmand must be run to copy over all 
            // trust from the JPS keystore service's trust service. 
            // TBD - revert to old ssl not using channels for time being. 
            openSSLIdentityFactory.addOpensslInternalTrust(privateCA, locations.getExternalTrustDir(), pemFileName);
    
            javaIdentityFactory.addJavaInternalTrust(passphrases.getKeystorePassphrase(), privateCA);
            
            // Now add identity signed by same CA to Oracle Wallet for use by components using Oracle's C++ ssl api (as opposed to OpenSSL used by BIEE)
            final WalletAccessor walletAccessor = new WalletAccessor(certsTempDir.getDir(), passphrases.getKeystorePassphrase());
            // Must add trust to wallet before creating identities, so that trust chains are complete. 
            walletAccessor.addTrustCertificate(locations.getInternalTrustCert());
            final String walletCommonName = "OBIEE wallet Server";
            final DistinguishedName walletDN = new DistinguishedName(walletCommonName, "Business Intelligence");
            walletAccessor.createIdentity(walletDN, privateCA);
            subjects.add(walletDN);
            
            walletAccessor.save(certificateLocations.getWalletLocations().getServerWalletDir());
            return subjects;
        } 
    }
    
    

    
    
    /**
     * Programmes should use passphrases from the credential store.
     * @throws SSLException 
     */
    private void storePassphrases(Passphrases passphrases) throws SSLException{
        credentialAccessor.savePassphrase(passphrases.getServerKeyPassphrase(), 
                    CredentialAccessor.SSL_INTERNAL_PASSPHRASE);
        credentialAccessor.savePassphrase(
                    passphrases.getCaKeyPassphrase(),
                    CredentialAccessor.SSL_INTERNAL_CA_PASSPHRASE);
        
    }



    /**
     * Store hashed form of ca certificate in a trust directory.  Since only one certificate is being stored we do not need to worry about 
     * clashing hashes.  The certificate will also be stored in a file with a human readable name.  This is for users who wish to refer to 
     * one CA by file name, rather than use the openssl trust dir mechanism. 
     * @param ca certificate authority whose CA certificate will be stored
     * @param trustDir will be created if necessary.  Will be cleared out. 
     * @param pemFile name of non-hashed ca file within the trust dir.
     * @throws SSLException
     */
    
    



}
