package oracle.bi.ssl.jps;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.security.Key;
import java.security.KeyStore;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.Set;

import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.pub.SSLException;


/**
 * 
 * Utilities to manipulate Java KeyStores stores - importing and exporting certificates. 
 * The Java key store is only used by Java components.  The C++ openssl runtime stack 
 * (and its certificate signing tool) manipulate individual 
 * certificates stored in separate files.   This is an interface so that we can implement 
 * access to mirrored and single keystores in the same consistent manner. 
 *
 *  
 */
public interface KeyStoreAccessor
{
  
   /**
    * For read access only.  Writes should be made only via the KeyStoreAccessor to ensure that mirrored copies are 
    * kept in sync. 
    * @return underlying dumpKeystoreDiagnosticskeystore.  
    */
   public KeyStore getKeyStore();
    
    
   /**
    * Save keystore, protected by a passphrase.  Writes to JPS keystores are automatically saved within JPS without any save call. 
    * This is useless for JPS keystores since 
    * oracle.security.jps.internal.keystore.provider.FarmKeyStoreSpi.engineStore(FarmKeyStoreSpi.java:595)
    * throws java.io.IOExdumpKeystoreDiagnosticsception: Method not implemented
    * @param destFile
    * @param passphrase
    * @throws SSLException
    */
   public void exportKeyStoreToFile(File destFile, Passphrase passphrase) throws SSLException;
   
   
   /*
    * Load a private key, in DER (binary) format with pkcs8 encoding together with its 
    * associated certificate chain in pem format. 
    */
   void loadPrivateKey(File keyFile, File certificateFile, Passphrase keyPassword, String alias) throws SSLException;
   
   
   
   
   
   /**
    * Load a certificate in x509 format, into an existing keystore.
    * Allows us to sign a certificate using openssl, then load into the java world. 
    * 
    * 
    * @param certificateFile should contain a single x509 certificate
    * @param alias name for certificate entry in keystore.  This alias must be unused. 
    */
   void loadX509(File certificateFile, 
                               String alias) throws SSLException;
   
   /** 
    * Load a private key, with its corresponding certificate chain.  
    * For our simple local Certificate Authority the certificate chain will consist of a 
    * single certificate - which is the corresponding public key.
    */
   public void loadKey(String alias, Key key, Passphrase keyPassword, Certificate[] authenticationChain) throws SSLException;
   
   /**
    * @return description of where this keystore came from
    */    
   public String getComment();
   
   /**
    * Dump public summary information 
    * @param name
    * @throws SSLException
    * @throws IOException 
    */
   public void dumpKeyStoreDiagnostics(Writer w) throws SSLException;
   
   /**
    * Dump full keystore, secured with passphrase, to files in logs directory. 
    * @param name base name of files
    * @throws IOException 
    */
   public void dumpKeyStoreDiagnosticsToFile(String name) throws SSLException, IOException;
   
   /**
    * Return the subjects of the certificates
    */
   public Set<Principal> getCertificateSubjects() throws SSLException;
   
   /**
    * Load a single trusted certificate
    * @param alias local name
    * @param certificate 
    * @throws SSLException
    */
   public void loadCertificate( String alias, Certificate certificate) throws SSLException;
   
   
   
   
   
  
   
   
}
