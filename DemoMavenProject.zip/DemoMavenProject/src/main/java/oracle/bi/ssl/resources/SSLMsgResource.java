package oracle.bi.ssl.resources;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.WeakHashMap;

public class SSLMsgResource {

     private static Locale _defaultLocale = Locale.getDefault();
     private static Map<Locale,ResourceBundle> _resources;
     
     private static SSLMsgResource _instance = new SSLMsgResource(); 
     
     private SSLMsgResource(){
         // Singleton class private constructor
     }
     
     public static SSLMsgResource  getInstance() {
         return _instance;
     }
     
     // Return the resource bundle
      private ResourceBundle getBundle(Locale locale)
      {
        if(_resources == null || _resources.get(locale) == null)
        {
            createBundle(locale);
        } 
            return (ResourceBundle) _resources.get(locale);
       }
      
      private synchronized void createBundle(Locale locale){
          if(_resources == null)
            {
              _resources = Collections.synchronizedMap(new WeakHashMap<Locale,ResourceBundle>(10));
            }
            if(_resources.get(locale) == null)
            {
              ResourceBundle myResources = ResourceBundle.getBundle(SSLMsg.class.getName(), locale);
              _resources.put(locale, myResources);
            }
     }
      
      public static String getRawMessage(Locale aLocale, String aKey)
      {
        ResourceBundle resources = getInstance().getBundle(aLocale);
        String myMessage = "";
        try
        {
          myMessage = resources.getString(aKey);
        }
        catch(MissingResourceException mrsex1)
        {
            resources = getInstance().getBundle(_defaultLocale);
          try
          {
            myMessage = resources.getString(aKey);
          }
          catch(MissingResourceException mrsex2)
          {
            myMessage = aKey;
          }
        }
        return myMessage;
      }
      
      
      
      public static String getMessage(String key, Object ... args){
          return getMessage(key, Locale.getDefault(), args);
      }
      
      
      
      
      public static String getMessage(String key, Locale locale, Object ...args ){
          return MessageFormat.format(getRawMessage(locale, key),args);
      }
      
      
      
}
