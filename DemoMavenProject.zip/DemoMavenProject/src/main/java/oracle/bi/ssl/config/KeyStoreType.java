package oracle.bi.ssl.config;

import oracle.bi.ssl.pub.SSLException;

/**
 * The values are defined in 
 * https://docs.oracle.com/javase/7/docs/technotes/guides/security/StandardNames.html#KeyStore
 * where they are in lower case - although upper case also appears to work. 
 */
public enum KeyStoreType {

    jks,
    
    pkcs12;
    
    /**
     * 
     * @return type for use in KeyStore.getInstance.  Use {@link #name()} 
     * @throws SSLException 
     */
    public static KeyStoreType getDefaultKeyStoreType() {
        if( SecurityProviders.isFipsSecurityProvider() ){
            // This FIPS provider only supports pkcs12 keystores. 
            return pkcs12;
        } else {
            // With the default security providers in the JDK + programmatically added OraclePKIProvider 
            // a pkcs12 KeyStore fails.  Calls to keystore.loadKey throw java.security.KeyStoreException: Not Implemented
            
            return jks;
        }
        
    }
}
