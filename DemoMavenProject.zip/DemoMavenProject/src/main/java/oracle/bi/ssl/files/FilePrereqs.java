package oracle.bi.ssl.files;

import java.io.File;

import oracle.bi.ssl.pub.SSLException;

/**
 * Simple file utilities.  Check that prerequisites are satisfied.  These are used to provide early error reporting at the top of methods 
 * thus avoiding obscure errors inside complex utilities, such as openssl command lines. 
 */
public final class FilePrereqs
{
   
   /**
    * No instances
    */
   private FilePrereqs()
   {
   }
   
   /**
    * Check name ends in expected .der.   We enforce this convention to make understanding 
    * complex file type conversions simpler. 
    * @param file
    * @throws SSLException
    */
   public static void checkIsDerFile(File file) throws SSLException{
       checkIsFileType(file, "der");
   }
   
   public static void checkIsPemFile(File file) throws SSLException{
       checkIsFileType(file, "pem");
   }
   
   /**
    * 
    * @param file
    * @param type without the starting '.'
    * @throws SSLException
    */
   public static void checkIsFileType(File file, String type) throws SSLException{
       if(!file.getName().endsWith("." + type)){
           throw new SSLException("File " + file.getAbsoluteFile() + " does not end with expected type ."+type);
       }
   }
   
   /**
    * Check file exists, and is non-zero in size.  This is used to confirm that 
    * certificate creation has worked.  Openssl is prone to producing empty files 
    * if the arguments are wrong.  
    * @param comment operation which should have produced this file.  Used in exception string. 
    */
   public static void checkNonEmptyFile(File file, String comment) throws SSLException
   {
      if (!file.exists()){
         throw new SSLException(comment + " " + file.getAbsolutePath() + " does not exist");
      }
      
      if( file.length() == 0 ){
         throw new SSLException(comment + " " + file.getAbsolutePath() + " empty");
      }
   }
   
   public static void checkDirExists(File dir, String comment) throws SSLException
   {
      if (!dir.exists()){
         throw new SSLException(comment + " " + dir.getAbsolutePath() + " does not exist");
      }
      
      if( !dir.isDirectory() ){
         throw new SSLException(comment + " " + dir.getAbsolutePath() + " is not a directory");
      }
   }
   
   /**
    * Check file does not exist.  Used to prevent accidental overwrites.
    * @param comment operation which intends to create this file.  Used in exception string. 
    */
   public static void checkNoOverwrite(File file, String comment) throws SSLException
   {
      if (file.exists()){
         throw new SSLException(comment + ": file " + file.getAbsolutePath() + " already exists");
      }    
   }
   
    
}


