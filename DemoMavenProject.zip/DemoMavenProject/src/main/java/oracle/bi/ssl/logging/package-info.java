/**
 * Utilities for recording information in log files.  
 */

package oracle.bi.ssl.logging;