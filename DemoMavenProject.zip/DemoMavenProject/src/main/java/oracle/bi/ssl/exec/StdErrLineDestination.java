package oracle.bi.ssl.exec;



import oracle.bi.ssl.logging.ExecLogger;

/**
 * Sends stderr to ExecLogger.  
 *
 */
public class StdErrLineDestination implements LineDestination{
    private final String comment;
    private final ExecLogger execLogger;
    
    public StdErrLineDestination(String comment, ExecLogger execLogger){
        this.execLogger = execLogger;
        this.comment = comment;
    }
    @Override
    public void consumeLine(String line) {
        execLogger.stdErr(comment, line);            
    } 
    
    
}

