/**
 * Public API to ssl facilities.  Consumers should only use classes and interfaces defined in this package and below.  
 * Classes and interfaces in other packages may change without warning. 
 */

package oracle.bi.ssl.pub;