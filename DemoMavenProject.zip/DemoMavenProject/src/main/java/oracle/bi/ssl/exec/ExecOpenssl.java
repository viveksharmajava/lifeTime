package oracle.bi.ssl.exec;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.pub.SSLException;


/**
 * Invokes command line tool 'openssl' which allows manipulation of certificates, including 
 * signing by a local certificate authority.  Particular command invocations are in class OpensslCommands.
 */
public final class ExecOpenssl 
{
   // OS dependent arguments
   private final List<String> _launchArgs;
   
   
   private final File _workingDir;
   private final File _opensslCnf;
   private final ExecLogger _execLogger;
   private final Executable _executable;
   private final Homes _homes;
   private final File _oracleHome;
   
   
   /**
    * Initialize location of executable
    * @param executable which openssl executable to use
    * @throws SSLException 
    */
   public ExecOpenssl(Homes homes, Executable executable, File workingDir, ExecLogger execLogger) throws SSLException  {      
      _execLogger = Objects.requireNonNull(execLogger);      
      _executable = Objects.requireNonNull(executable, "null executable");  
      _workingDir = Objects.requireNonNull(workingDir, "null workingDir");
      FilePrereqs.checkDirExists(workingDir, "workingDir");
      
      _homes = homes;
      
      _oracleHome =  _homes.getOracleHomeLocations().getOracleHome();
      
      _opensslCnf = homes.getDomainLocations().getOpensslCnf();
      
      _launchArgs = executable.getExecutableLaunchArgs();      
   }
   
   public Executable getExecutable(){
       return _executable;
   }
   
   public File getWorkingDir(){
       return _workingDir;
   }

       
   /**
    * Run openssl command. 
    * @param opensslArgs command line arguments
    * @param inputs security sensitive inputs passed via stdin
    * @comment Included at trace level. So not translated. 
    * @return stdout lines
    */
   public List<String> runOpensslCommand(
                                        List<String> opensslArgs, 
                                        List<char[]>inputs,
                                        String comment) throws SSLException{ 
       return runKillableOpensslCommand(new ProcessKiller(), opensslArgs, inputs, comment);
   }
   
   /**
    * Run an openssl command, with ability to kill process, with default log levels
    * @param processKiller allows a process to be killed.  Only used if the process is long running eg s_server.
    * @param opensslArgs openssl args, eg {"ca", "-option1", "-option2", ...}.
    * @param inputs passed to the process via stdin.  Typically used to securely pass passwords   
    * @param comment text included in errors and progress reports.
    * @return lines output to stdout
    */
   public List<String> runKillableOpensslCommand(
                                        ProcessKiller processKiller,
                                        List<String> opensslArgs,
                                        List<char[]> inputs,
                                        String comment
                                      ) throws SSLException {       
      final List<String> cmdArgs = new ArrayList<String>();
      cmdArgs.addAll(_launchArgs);
      cmdArgs.addAll(opensslArgs);
     
      final Map<String, String> env = new HashMap<String, String>();
      
      // If we do not give an explicit openssl.cnf file location every open ssl command - even ones which do not use openssl.cnf - 
      // will give a warning that the openssl.cnf build time location was not found.  Using -config location on the command line only 
      // fixes this for the subset of commands which support -config.  The environment variable approach fixes in all cases.  If -config 
      // is given on the command line it will take precedence. 
      FilePrereqs.checkNonEmptyFile(_opensslCnf, "openssl config file" );
      
      boolean hasConfig = false;
      for( String arg : opensslArgs){
          if( arg.equals("-config")) {
              hasConfig = true;
          };
      }
      if( !hasConfig){
          env.put("OPENSSL_CONF", _opensslCnf.getAbsolutePath());
          File fipslocation = new File(_oracleHome + File.separator + "bi/modules/oracle.bi.openssl/fipsmodule.cnf");
          File openssllocation = new File(_oracleHome , "bi/modules/oracle.bi.openssl/bin");        
          if(fipslocation.exists() && openssllocation.exists())
          {
              File opensslLibrary = new File(_oracleHome , "bi/modules/oracle.bi.openssl/lib");
              env.put("LD_LIBRARY_PATH", opensslLibrary.getAbsolutePath());
              
              /*
              File opensslFipsConf = new File(_homes.getDomainLocations().getSSLConfigDir().getAbsolutePath(), "openssl3.cnf");
              if(opensslFipsConf.exists())
              {
                   //we would use openssl3.cnf when FIPS is enabled and use our own FIPS enabled OpenSSL
                   env.put("OPENSSL_CONF", opensslFipsConf.getAbsolutePath());
              }
              */             
              File opensslModules = new File(_oracleHome , "bi/modules/oracle.bi.openssl/lib/modules");
              env.put("OPENSSL_MODULES", opensslModules.getAbsolutePath());
              
              File opensslPath = new File(_oracleHome , "bi/modules/oracle.bi.openssl");
              env.put("OPENSSL_CONF_INCLUDE", opensslPath.getAbsolutePath());             
          }
      }

      _execLogger.clear();
      final Exec exec = new Exec(_execLogger);
      final ExecResult execResult = exec.runCommandSynchronously(_workingDir, processKiller, env, cmdArgs, comment, inputs);
            
      return execResult.getLines();
   }
}
