package oracle.bi.ssl.certificate;

    
import java.io.Console;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Arrays;




/**
 * Protects a passphrase/password by storing in a mutable character array which 
 * is overwritten when finished with.  
 */
public final class Passphrase implements AutoCloseable
{
   // Allow choosing of explicit alphabetic and numeric for the irritating cases where password is required to contain 
   // particular contgributors - although this reduces the password space. Do not include special characters.  Makes 
   // passing on command line (Not used in actual code but useful in dev!) harder. 
   // "!@#$%^&*"
   private static final String PASSWORD_ALPHABETIC  = 
                        "abcdefghijklmnopqrstuvwxyz" + 
                        "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   
   private static final String PASSWORD_NUMERIC = 
                        "0123456789";
   
   private static final String PASSWORD_MIXED = PASSWORD_ALPHABETIC + PASSWORD_NUMERIC;
                       

   private char[] _passphraseChars;
   
   // Track if cleared out to avoid accidental shredding
   private boolean _shredded = false;
   
   
   /**
    * Constructor.  Once Passphrase is finished with, you should call secureShred() to overwrite the 
    * password. 
    * @param passphraseChars Must be non-null
    * A mutable char array is used instead of a String so that it can be cleared out.  The char array is 
    * owned by the Passphrase instance, and will be overwritten when secureShred is called.  This avoids the 
    * caller having to overwrite their own char[] as well.  
    */
   public Passphrase( char[] passphraseChars) 
   {
      if( passphraseChars == null ){
          throw new IllegalArgumentException("null passphraseChars" );
      }
      
      _passphraseChars = passphraseChars;
   }
   
   /**
    * Generate a random passphrase.  This is guaranteed to contain both alphabetic and numeric fields since wallet passwords must contain both. 
    * 
    */
   public static Passphrase randomPassphase(){  
       // Upper + lower case + numbers 62 digits. 
       // 62^18 is 1.8 x 10^32
       // One calculation at every GigHz clock tick, * number of seconds per year * 1 billion years = 
       // 10^9 x (60 x 60 *24 * 365) x 10^9 = 3 x 10^25
       // So 18 digits or more is plenty. 
       // Do not want arbitrarily long since slows startup as we wait for entropy. 
       // 
       final int passwordMixedLength = 25;
       final SecureRandom r = new SecureRandom();
       
       final char[] passphraseChars = new char[passwordMixedLength + 2];
       
       
       for( int i = 0; i < passwordMixedLength; i++){
           passphraseChars[i] = PASSWORD_MIXED.charAt(r.nextInt(PASSWORD_MIXED.length()));
       }
       
       // Now add the guaranteed numeric and alphabetic to ensure always have at least one of each to satisfy Oracle Wallet password check. 
       passphraseChars[passwordMixedLength] = PASSWORD_NUMERIC.charAt(r.nextInt(PASSWORD_NUMERIC.length()));
       passphraseChars[passwordMixedLength+1] = PASSWORD_ALPHABETIC.charAt(r.nextInt(PASSWORD_ALPHABETIC.length()));
       return new Passphrase(passphraseChars);
   }
   
   /**
    * Read a passphrase from the first line of stdin. 
    * @return
    * @throws IOException 
    */
   public static Passphrase fromStdIn(String prompt) throws IOException{
       System.out.println(prompt);
       return new Passphrase(readFromStdIn());
   }
   
   /**
    * Read a passphrase from the first line of console. 
    * Does not echo to stdout, but is known not to work in certain circumsntances, eg in IDEs, where the 
    * exec window is not a true console.  If there is no system console eg when testing by invoking main directly, 
    * revert to fromStdIn which does echo. 
    * @return
    * @throws IOException 
    */
   public static Passphrase fromConsole(String prompt) throws IOException{
       System.out.println(prompt);
       final Console console = System.console();
       if( console == null){
           return fromStdIn(prompt);
       } else {
           return new Passphrase(console.readPassword());
       }
   }
   
   
   /**
    * Read password form stdin to avoid having a password argument on comand line invocation which is insecure. 
    * Passwords should be read into chars not Strings since chars can be cleared out - immutable Strings remain 
    * in the image until garbage collection (which could be ages) and even then may remain in the image until the 
    * memory is reallocated.
    * 
    * Redirected files result in a terminating linefeed.  As does echo (unless you use options such as -n first or \c).
    * So only include first line.  First line is terminated by line feed ('\n'), a carriage return ('\r'), or a carriage return
    * followed immediately by a linefeed.  This conforms to the definition of readline in java.io.BufferedReader. 
    * 
    * If used interactively the password characters are echoes - which users do not expect.  Consider using readFromConsole instead. 
    * @return password characters
    * @throws IOException
    */
   private static char[] readFromStdIn() throws IOException {
       int cInt;
       final StringBuilder buff = new StringBuilder();
       while( (cInt = System.in.read()) != -1){
           char c = (char)cInt;
           if(c == '\n' || c == '\r'){
               break;
           }
           buff.append(c);
       }
       
       
       char[] ret = new char[buff.length()];
       for( int i = 0; i < buff.length(); i++){
           ret[i] = buff.charAt(i);
           buff.setCharAt(i,  ' ');
       }
       
       return ret;
   }
   
   @Override
   public Object clone(){
      throw new IllegalStateException("Clone of passphrase not supported");
   }
   
   /**
    * Overwrite password fields so they are not available in coredumps etc.  
    * This method should be called once Passphrase is no longer needed.  This is most reliably done using 
    * a try with resources block. 
    */
   @Override
   public void close(){
       if( _shredded){
           // Don't do again
       } else {
           _shredded = true;
          Arrays.fill(_passphraseChars, ' ');
      
          // Now make even finding the length harder. 
          _passphraseChars = null;
       }
   }
   
   /**
    * As a fall back, ensure secureShred is called.  Waiting for garbage collection is not 
    * good practice, but at least the password is overwritten at garbage collection not on 
    * next reuse which could be much later (if at all). 
    * 
    * You should call secureShred explicitly.  
    */
   @Override
   protected void finalize() throws Throwable{
     close();
     super.finalize(); 
   } 

   
   
   /**
    * 
    * If password has bean cleared out, will throw IllegalStateException.  
    * Caller should not copy the result, not create a string from it, nor log it.   Do not keep a reference to it since even though it will 
    * be cleared, the length will remain extant.  Checkbugs complains about exposing the internals - but thats the whole point.  We do not 
    * want to give out a copy.   So need an exclusion in config/findbugs/excludeFilter.xml.
    * @return
    */
   public char[] getPassphraseChars(){      
      if( _shredded ){
         throw new IllegalStateException("Already shredded");
      }
      return _passphraseChars;
   }



   
   
  
}
