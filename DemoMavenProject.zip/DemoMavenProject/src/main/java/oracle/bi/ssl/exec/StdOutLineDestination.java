package oracle.bi.ssl.exec;

import java.util.ArrayList;
import java.util.List;

import oracle.bi.ssl.logging.ExecLogger;

/**
 * Sends stdout to ExecLogger, and in addition records stdout lines.  Some openssl commands output information which we need to capture on stdout.  
 *
 */
public class StdOutLineDestination implements LineDestination{
    private List<String> lines = new ArrayList<String>();
    private final String comment;
    private final ExecLogger execLogger;
    
    public StdOutLineDestination(String comment, ExecLogger execLogger){
        this.execLogger = execLogger;
        this.comment = comment;
    }
    @Override
    public void consumeLine(String line) {
        lines.add(line);
        execLogger.stdOut(comment, line);            
    } 
    
    public List<String> getLines(){
        return lines;
    }
}
