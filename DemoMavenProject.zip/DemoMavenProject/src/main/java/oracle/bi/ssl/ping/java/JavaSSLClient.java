package oracle.bi.ssl.ping.java;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import oracle.bi.ssl.logging.LoggerFactory;

/**
 * Performs  pings to an SSL server
 *
 * Whether or not the server has been configured to ask for client certificate authentication, we always provide client certificate from the 
 * identity key store. This reduces the number of different configurations to test. 
 */
public final class JavaSSLClient {
    private final static Logger logger = LoggerFactory.createLogger(JavaSSLClient.class);
    
    private final SSLSpec sslSpec;
     
    
    /***
     *  Remember settings, but do not actually create any SSL artifacts.  This allows the SSL environment to be changed between 
     *  ping calls. 
     */
    public JavaSSLClient(SSLSpec sslSpec){
        this.sslSpec = Objects.requireNonNull(sslSpec, "null sslSpec");
    }

    /**
     * Create ssl tcp connection, and perform ssl handshake. 
     * @param host
     * @param port
     * @param chat if true perform one request/response pair in addition to the SSL handshake and echo results.  Only usable if server 
     * plays same game
     * @return PingResult both for success and failure
     *
     */
    public JavaPingResult ping(String host, int port, boolean chat){
        
        
        
        final SSLSession tlsSession;
        try{
            // Can we connect using the currently configured algorithms?
            
            
            tlsSession = establishSSLSession( host, port, chat);   
            logger.info("Successfully connected over " + this.sslSpec.getSslAlgorithms()  + " to " + host + ":" + port);
        } catch (Throwable t){
            final JavaPingFailed javaPingFailed = new JavaPingFailed(t);
            logger.log(Level.INFO, "SSL connection failure: " + javaPingFailed.getSummary() + " to " + host + ":" + port, t);
            return javaPingFailed;
        }
        
        
        // We used to now check if we can connect over SSLv3 - which would indicate an insecure server.   With 
        // latest versions of JDK1.8 client SSLv3 is no longer supported so we are unable to make this check.  Removal of SSLv3 from servers is 
        // now well established so the need to do this check is effectively gone.  
        
       
        
        final JavaPingResult result = new JavaPingOK(tlsSession);
        logger.info("Successful connection: " + result.toString() );
        return result;
    }
    
    
    
       
    /**
     * Perform SSL handshake and optional exchange of application level data.  If ok returns the ssl session.  If any problem 
     * occurs throws an exception. 
     * @param allowedCN if null no check of certificate common name. 
     * @param host
     * @param port
     * @param chat
     * @return
     * @throws Exception
     */
    private SSLSession establishSSLSession(String host, int port, boolean chat) throws Exception{

        
        
        // To support custom protocols (eg OBIPS RPC over ssl TCP) we are using JSSE by directly using SSLContexts.  So we have to 
        // ensure the right host name verification is set.  Contrast this with HTTPS from an HTTPS URL where the HTTPS URL Connection does 
        // all the configuration for us. 
        
        final SSLContext ctx = sslSpec.getSSLContext(host);
        
        
        final SSLSocketFactory sslFactory = ctx.getSocketFactory();
        try (final SSLSocket sslSocket=(SSLSocket)sslFactory.createSocket(host, port);){
        
            sslSpec.getSslAlgorithms().applyToSSLSocket(sslSocket);
            
                        
            // startHandshake on a non-ssl port hangs.   To break the hang, use a timeout 
            // connecting over sslv3 when openssl based C++ server does not support it also hangs. 
            // It would be better if the server rejected more explicitly (as does openssl s_server). 
            // Clearly too small a timeout risks falsely reporting failed to connect.  Too large and the ssl checking code takes ages. 
            sslSocket.setSoTimeout(2000);
            
            
            // Perform handshake immediately - do not wait to send data.  This avoids the problem of ensuring that whatever 
            // data we send is acceptable to the other end.         
            sslSocket.startHandshake();
            
            final SSLSession sslSession = sslSocket.getSession();
            if( chat){
                // Do not close output stream prior to reading on input stream!       
                // Use same encoding as test SSL Server.
                int lineCount = 0;
                try(OutputStreamWriter ws = new OutputStreamWriter(sslSocket.getOutputStream(), StandardCharsets.UTF_8);
                    InputStreamReader is = new InputStreamReader(sslSocket.getInputStream(), StandardCharsets.UTF_8);
                    BufferedReader in = new BufferedReader(is)){
                    
                    ws.write("GET response\n\n");
                    ws.flush();
                    System.out.println("Client sent request");
                
                    System.out.println("Client awaiting response");
                    String line;
                    try {
                        while ((line = in.readLine()) != null) {
                          System.out.println("CLIENT: " + line);
                          lineCount++;
                        }
                    } catch (SSLException e){
                        // Openssl test server does not closedown cleanly. 
                        // For FIPS 140 security providers this results in:
                        // Inbound closed before receiving peer's close_notify: possible truncation attack?
                        // For default JDK security providers no exception. 
                        // If we have received content, then the SSL ping has definitely worked and we can ignore the exception
                        if( lineCount > 0 ){
                            logger.log(Level.INFO, "Received SSL exception: '" + e.getMessage() + "' after received content, so handshake ok", e);
                        } else {
                            throw e;
                        }
                    }
                }
            }
            return sslSession;
        }
        
        
      }
}
