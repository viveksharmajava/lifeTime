package oracle.bi.ssl.certificate;

import java.io.File;

/**
 * Certificate and keys are fundamentally a pair, so store them together whenever possible. 
 * 
 *
 */
public final class CertKey {
    private final File cert;
    private final File key;
    
    public CertKey(File cert, File key){
        this.cert = cert;
        this.key = key;
    }
    
    public File getCert(){
        return cert;
    }
    
    public File getKey(){
        return key;
    }
}
