package oracle.bi.ssl.locations;



/**
 * Defines names (stripes, keystore name, certificate aliases) of certificates within the JPS keyStore service.  
 */
public final class KeystoreNames {


    /**
     * Constructor.  
     */
    public KeystoreNames(){       
        
    }


    /**
     * Keystore service stripe holding all keystores added by the bi config assistant. 
     * @return
     */
    public String getDefaultBiStripe() {
        return "OBI";
    }

    public String getSystemStripe(){
        return "system";
    }
    
    public String getDemoIdentityKeyStoreName(){
        return "demoidentity";
    }
    
    public String getDemoIdentityAlias(){
        return "DemoIdentity";
    }

    /**
     * Identity keystore within bi stripe.
     */
    public String getBIIdentityKeyStoreName() {
        return "internalidentity";
    }
    
    public String getServerIdentityAlias(){
        return "allservers";
    }

    

    public String getClientIdentityAlias(){
        return "allclients";
    }
    
    /**
     * Keystore within bi stripe holding trust of internal certificates
     */
    public String getBIInternalTrustKeyStoreName() {
        return "internaltrust";
    }



    /**
     * Used in both domain trust (so weblogic trusts internal components) and internal trust (so internal components trust each other). 
     * @return
     */
    public String getInternalCACertificateAlias() {
        return "biinternal";
    }
    
    
}