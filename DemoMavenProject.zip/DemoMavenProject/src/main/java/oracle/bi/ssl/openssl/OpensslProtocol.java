package oracle.bi.ssl.openssl;

/**
 * Enum names are exactly the same as used (without the '-' prefix) for openssl s_server commands.  
 * 
 * @author pharry
 *
 */
public enum OpensslProtocol {
    
    ssl2, ssl3, tls1, tls1_1, tls1_2, no_ssl2, no_ssl3, no_tls1;
}
