package oracle.bi.ssl.certificate;

import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;

import oracle.bi.ssl.pub.SSLException;

/**
 * Get information from one or more collections of certificates
 * All the observers throw an IllegalStateException if called before any certs have been collected. 
 */
public final class CertificateStats {
    
    private X509Certificate firstToExpire = null;
    private int count = 0;
    
    private void checkCollected(){
        if( count == 0 ){
            throw new IllegalStateException("No certs in stats");
        }
    }
    public void collectStatsOnCertificates(Collection<X509Certificate> certs){
        count += certs.size();
        for( X509Certificate cert : certs){
            final Date expiry = cert.getNotAfter();
            if( firstToExpire == null){
                firstToExpire = cert; 
            } else if ( expiry.compareTo(firstToExpire.getNotAfter()) <  0){
                firstToExpire = cert;
            }
        }
    }
    
    
    public X509Certificate getFirstToExpire(){
        checkCollected();
        return firstToExpire;
    }
    
    public int getCount(){
        return count;
    }
    
    /**
     * Return true if certificates have expired. 
     * @return
     */
    public boolean expired() throws SSLException{
        checkCollected();
        final Date now = new Date();
        try {
            firstToExpire.checkValidity(now);
        } catch (CertificateExpiredException e) {
            return true;
        } catch (CertificateNotYetValidException e) {
            throw new SSLException("Certificate not yet valid");
        }
        return false;
    }
    
    /**
     * Return true if certificates will expire within n days. 
     * @return
     * @throws SSLException 
     */
    public boolean soonToExpire(int days) throws SSLException{
        checkCollected();
        if( days < 0 ){
            throw new IllegalArgumentException("Negative days");
        }
    
        final Calendar cal = GregorianCalendar.getInstance();
        cal.setTime( new Date() );
        
        cal.add(GregorianCalendar.DAY_OF_MONTH, days);
        try {
            firstToExpire.checkValidity(cal.getTime());
        } catch (CertificateExpiredException e) {
            return true;
        } catch (CertificateNotYetValidException e) {
            throw new SSLException("Certificate not yet valid");
        }
        return false;
    }
}
