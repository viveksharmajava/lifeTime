package oracle.bi.ssl.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.crypto.Cipher;

import oracle.bi.endpointmanager.pub.EndpointManager;
import oracle.bi.endpointmanager.pub.EndpointManagerFactory;
import oracle.bi.endpointmanager.pub.RegisteredEndpoint;
import oracle.bi.ssl.certificate.DistinguishedName;
import oracle.bi.ssl.certificate.ExpiryResult;
import oracle.bi.ssl.certificate.ExpirySummary;
import oracle.bi.ssl.certificate.Exporter;
import oracle.bi.ssl.certificate.IdentityFactory;
import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.channels.Channels;
import oracle.bi.ssl.channels.SSLProtocol;
import oracle.bi.ssl.config.CipherConverter;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.config.SecurityProviders;
import oracle.bi.ssl.credentials.CredentialAccessor;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.jps.KeyStoreServiceAccessor;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.EchoMode;
import oracle.bi.ssl.logging.FileLogging;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.online.OnLineDetector;
import oracle.bi.ssl.ping.Report;
import oracle.bi.ssl.pub.CertOptions;
import oracle.bi.ssl.pub.SANOption;
import oracle.bi.ssl.pub.SSLException;


/**
 * Supports command line for performing SSL management activities.
 * 
 * Run the command with <DomainHome>/bitools/bin/ssl.sh for Linux, ssl for windows.   This delegates to the implementation script, 
 * adding oracle home and domain home. 
 * 
 * To run inside the WLST environment run:
 * 
 * <OracleHome>/oracle_common/common/bin/wlst.sh
 * 
 * In this case the oracle home and domain home need to be given explicitly.  Eg:


from oracle.bi.ssl.commands import SSLCommand
import jarray

argsarray = jarray.array(["/bi/app/fmw", "/bi/domain/fmw/user_projects/domains/bi", "report", "obips1"], java.lang.String)


commandInterpretter = SSLCommand(None)
commandInterpretter.mainEx(argsarray)

 * The bi-ssl.jar is added to the WLST classpath in bi-sysman project, sub-project bi-sysman-wlst.
 */
public final class SSLCommand {
    
    /**
     * If null use the default endpoint manager.  Allows injection of a mocked endpoint manager for testing. 
     */
    private EndpointManager endpointManager;
    
    
    
    
    
    
    
    
    /**
     * Configure logs.  The "oracle" top level logger catches oracle.bi, oracle.jps etc.   Unfortunately empty log name (the root logger) does not 
     * as you might hope capture everything.    Use this logger to change log configuration.  Do not use to log from this class! 
     */
    private final static Logger oracleLogger = Logger.getLogger("oracle");  
    
    /**
     * Use this to log from this class. 
     */
    private final static Logger logger = LoggerFactory.createLogger(SSLCommand.class);

    private final static String DISABLE_OFFLINE_CHECK = "--disableOfflineCheck";
    
    private final static String SKIP_CERTIFICATES_UPDATE = "--skipCertsUpdate";
    
    
    // The commands 
    // -----------------------------------------------------------
    
    /**
     * List current trust 
     * @param command
     * @param homes
     * @param args
     * @return
     * @throws SSLException
     */
    private void listTrustCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        try {
            
            System.out.println("Trust certificates for use within WebLogic" );
            System.out.println("Certificates can be added in EM, but this can be missleading since this only changes the ");
            System.out.println("Default (database), not the bootstrap (file) keystores.  WebLogic managed servers use the ");
            System.out.println("bootstrap.  Check below for inconsistencies.  ");
            System.out.println();
            System.out.println("In WebLogic console managed servers can be configured to use non standard trust.  Here ");
            System.out.println("we list only the two standard trust keystore options");
            System.out.println();
            final KeyStoreServiceAccessor keyStoreServiceAccessor = new KeyStoreServiceAccessor(sslEnvironment.getHomes().getDomainLocations());
            {
                System.out.println("system/trust keystores" );
                final KeyStoreAccessor keyStoreAccessor = keyStoreServiceAccessor.getDomainTrustKeyStore();
                final Writer w =new OutputStreamWriter(System.out, StandardCharsets.UTF_8);
                keyStoreAccessor.dumpKeyStoreDiagnostics(w);
                w.flush();
            }
            
            System.out.println();
            {
                System.out.println("system/publiccacerts keystores" );
                final KeyStoreAccessor keyStoreAccessor = keyStoreServiceAccessor.getSystemPubliccacertsKeyStore();
                if( keyStoreAccessor == null){
                    System.out.println("- Does not exist");
                } else {
                    final Writer w =new OutputStreamWriter(System.out, StandardCharsets.UTF_8);
                    keyStoreAccessor.dumpKeyStoreDiagnostics(w);
                    w.flush();
                }
            }
            
             
        } catch (IOException e) {
            throw new SSLException("Failed to write trust summary", e);
        }
        
    }
    
    /**
     * Create or update a channel.  If newly created a channel port must be given. 
     * @param command
     * @param homes
     * @param args
     * @return
     * @throws SSLException
     */
    private void listCiphersCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCount(command, args, 3);
        System.out.println("The following are the cipher names which are automatically converted from OpenSSL to Java names. You can ");
        System.out.println("configure theprivate static KeyStoreType keyStoreType = KeyStoreType.getDefaultKeyStoreType();\n" + 
                "    se ciphers by just giving the OpenSSL name in the bi-ssl.xml file. ");
        System.out.println("If you give both Java and OpenSSL cipher names in the bi-ssl.xml file then, depending on your JDK version, ");
        System.out.println("additional ciphers may be available. ");
        System.out.println();
        
        int maxKeyLen = -1;
        try {
            maxKeyLen = Cipher.getMaxAllowedKeyLength("AES");
        } catch (NoSuchAlgorithmException e) {
            logger.log(Level.SEVERE, "Cannot get max allowed key length", e);
        }
        final String policy = Security.getProperty(CipherConverter.CRYPTO_POLICY_KEY);
        if( maxKeyLen <= 128){
             System.out.println("Java Cryptography Extension (JCE) not enabled.  Stronger cipers (eg with ASE keylength > 128) will not be usable");
             System.out.println("   crypto.policy: " + policy + " max length AES keys: " + maxKeyLen);
        }
        final CipherConverter cipherConverter = new CipherConverter();
        System.out.println(cipherConverter.toString());
    }
    /**
     * Create or update a channel.  If newly created a channel port must be given. 
     * @param command
     * @param homes
     * @param args
     * @return
     * @throws SSLException
     */
    private void channelCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCountRange(command, args, 4, 6);         
        boolean disableOfflineCheck = false;

        for(int i=2; i<args.length; i++){
           if(DISABLE_OFFLINE_CHECK.equalsIgnoreCase(args[i])){
               disableOfflineCheck = true;
               logger.info("Disabling offline check");
           }
        }

        if(!disableOfflineCheck) {
            final Homes homes = sslEnvironment.getHomes();
            checkOffline(homes);
        }

        final String server = args[3];
        final int port;
                
        if(args.length == 6 || (args.length==5 && !disableOfflineCheck)){
            final String portString = args[4];            
            try {
                port = Integer.parseUnsignedInt(portString);
            } catch (NumberFormatException e){
                final String msg = "Port '" + portString + "' in not an integer ";
                reportBadUsage(msg);
                throw BadStatusException.BAD_USAGE_STATUS;
            }
        } else {
            port = -1;
        }
        
        logger.info("Channel command: server " + server + " port " + port);
        
        final boolean sslEnabled = sslEnvironment.getConfigWrapper().isSslEnabled();
        
        
        final Channels channels = new Channels(sslEnvironment,  EchoMode.ECHO_INFO_TO_STD_OUT);
        
        final SSLProtocol sslProtocol;
        if( sslEnabled){
            System.out.println("Internal ssl is enabled.");
            final ExpiryResult expiryResult = checkCerts("Unable to configure internal channel using SSL.", sslEnvironment);
            
            sslProtocol = channels.createChannel(server, port);
            topupCerts(sslEnvironment);
            // Might as well inform user of expiry of certificates. 
            System.out.println(expiryResult.getResultString());
        } else {
            System.out.println("Internal ssl is not enabled.");
            sslProtocol = channels.createChannel(server, port);
        }
        if( port == -1){
            System.out.println("Configured bi internal channel on server " + server + " with protocol " + sslProtocol +" keeping existing port.");
        } else {
            System.out.println("Configured bi internal channel on server " + server + ", with protocol " + sslProtocol +", port " + port );
        }
        
    }
    
    private void channelsCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCountRange(command, args, 4, 6);

        String filepath = args[3];
        if(filepath!=null)
        {
            File serverPortfile = new File(filepath);
            
            if(serverPortfile.exists())
            {
                boolean disableOfflineCheck = false;
                boolean skipCertsUpdate = false;

                for(int i=4; i<args.length; i++){
                    if(DISABLE_OFFLINE_CHECK.equalsIgnoreCase(args[i])){
                        disableOfflineCheck = true;
                        logger.info("Disabling offline check");
                    }
                    if(SKIP_CERTIFICATES_UPDATE.equalsIgnoreCase(args[i])){
                        skipCertsUpdate = true;
                        logger.info("Skipping certificates update");
                    }
                }
        
                if(!disableOfflineCheck){ 
                    final Homes homes = sslEnvironment.getHomes();
                    checkOffline(homes);
                }

                HashMap<String, String> map = new HashMap<>();
                String line;
            
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filepath), StandardCharsets.UTF_8))){
                    while ((line = reader.readLine()) != null){
                        if(line.trim().length() > 0){
                            String[] serverPortPair = line.split(" ", 2);
                            String server = serverPortPair[0];
                            String port = "-1";
                            if(serverPortPair.length > 1){
                                port = serverPortPair[1];
                                try {
                                    int portInt = Integer.parseUnsignedInt(port);
                                    if(portInt == 0){
                                        final String mesg = "Port given is 0 ";
                                        reportBadUsage(mesg);
                                        throw BadStatusException.BAD_USAGE_STATUS;
                                    }
                                } catch (NumberFormatException e){
                                    final String msg = "Port '" + port + "' in not an integer ";
                                    reportBadUsage(msg);
                                    throw BadStatusException.BAD_USAGE_STATUS;
                                }
                            }
                            map.put(server, port);
                        } 
                    }
                } 
                catch (IOException e){                
                   logger.severe("Error in reading file" + e);
                }         

                final boolean sslEnabled = sslEnvironment.getConfigWrapper().isSslEnabled();       
        
                final Channels channels = new Channels(sslEnvironment,  EchoMode.ECHO_INFO_TO_STD_OUT);
        
                final SSLProtocol sslProtocol;
                if( sslEnabled && !skipCertsUpdate ){
                    System.out.println("Internal ssl is enabled.");
                    final ExpiryResult expiryResult = checkCerts("Unable to configure internal channel using SSL.", sslEnvironment);
            
                    sslProtocol = channels.createChannels(map);
                    topupCerts(sslEnvironment);
                    // Might as well inform user of expiry of certificates. 
                    System.out.println(expiryResult.getResultString());
                } else {
                     sslProtocol = channels.createChannels(map);
                } 
  
                List<String> serverList = new ArrayList<String>(map.keySet());
                List<String> portList = new ArrayList<String>(map.values());
                        
                if(portList.size() == 0){
                     System.out.println("Configured bi internal channel on servers with protocol " + sslProtocol +" keeping existing port.");
                } else {
                    for(int i=0; i<serverList.size(); i++){
                        if(portList.get(i).equalsIgnoreCase("-1")){
                            System.out.println("Configured bi internal channel on server " + serverList.get(i) + ", with protocol " + sslProtocol +" keeping existing port.");
                        } else {
                            System.out.println("Configured bi internal channel on server " + serverList.get(i) + ", with protocol " + sslProtocol +", port " + portList.get(i) );
                        }
                    }
                }
            }
            else 
            {
                logger.severe("File does not exist");
                throw new SSLException("File not found");
            } 
        }              
    }
        
    private void exportClientCertsCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCount(command, args, 4);
        // OK both on and offline. 
        
        final File dir = new File(args[3]);
        logger.info("export client certs command.  Dir: " + dir.getAbsolutePath());
        final ExpiryResult expiryResult = checkCerts("Unable to export certificates.", sslEnvironment); 
        
        final KeyStoreType keyStoreType = KeyStoreType.getDefaultKeyStoreType();
        
        final Exporter exporter = new Exporter(sslEnvironment, keyStoreType);
        // Try with resources so passphrase is cleared out
        try(Passphrase trustKeystorePassphrase = Passphrase.fromConsole("Enter new trust keystore passphrase")){
           if(trustKeystorePassphrase.getPassphraseChars().length == 0){
               System.out.println("Empty trust keystore passphrase rejected.  For security reasons a non empty passphrase is required.");
               throw BadStatusException.EMPTY_PASSPHRASE_STATUS;
           }
           exporter.exportClientCerts(dir, trustKeystorePassphrase);
        } catch (IOException e){
            throw new SSLException("Unable to read passphrase", e);
        }
        System.out.println("Exported client certificates to directory " + dir);
        final File readme = new File(dir, "readme.txt");
        System.out.println("See " + readme.getAbsolutePath() + " for explanations of the exported files");
        System.out.println(expiryResult.getResultString());
    }
    
    
    /**
     * 
     * @param adminServerConfig if null use offline, if non-null use online, connecting to AdminServer
     */
    private void rebindChannelCertificatesOnOrOffLine(SSLEnvironment sslEnvironment, AdminServerConnectionConfig adminServerConfig) throws SSLException, BadStatusException{       
        
        final boolean sslEnabled = sslEnvironment.getConfigWrapper().isSslEnabled();
        if( sslEnabled ){
            
            final Channels channels = new Channels(sslEnvironment,  EchoMode.ECHO_INFO_TO_STD_OUT);        
            
            // topupCerts fails if certificates never created.  So check for certificate health first. 
            final ExpiryResult expiryResult = checkCerts("Unable to create new certificates.", sslEnvironment);  
            
            channels.rebindChannelCertificates(adminServerConfig);
            
            // In case listeners have changed requiring new certificates.
            topupCerts(sslEnvironment);
            
            System.out.println("Internal channels have been bound to certificates matching their current listener addresses. " );
            System.out.println();
            // Display first expiry date/warning if about to expire. 
            System.out.println( expiryResult.getResultString() );
        } else {
            // If called from clone we do not want to suffer the overhead if ssl is not even enabled.  
            // We certainly do not want clone to fail because of out of date certificates. 
            System.out.println("Internal SSL is not enabled, so not rebinding channel certificates. ");
        }
    }
   
    /**
     * Implements the 'rebindchannelcerts' command.  Create new certificates (using the existing Certificate Authority) to match the current 
     * listener addresses.  A properly formed HTTPS certificate must have a common name (CN) matching the address the client has invoked. 
     * 
     */
    private void rebindChannelCertsCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        // Args array is HOME, DOMAINHOME, command name, [-online, host:port, user]
        
        boolean disableOfflineCheck = false;
        for(int i = 3; i < args.length; i++){
            if(DISABLE_OFFLINE_CHECK.equalsIgnoreCase(args[i])){
                disableOfflineCheck = true;
                logger.info("Disabling offline check");
            }
        }

        if(args.length > 3 && !disableOfflineCheck){
            // Has optional command parameters.  Parse them. 
            final String option = args[3];
            if( !option.equals("-online")){
                final String msg = 
                        "Command '" + command + "' does not support option '" + option +"'.\n"+ 
                        "This command only supports -online option with connection parameters, or offline with no parameters.\n";
                reportBadUsage(msg); 
                throw BadStatusException.BAD_USAGE_STATUS;
            }
            
            checkArgCount(command, args, 6);
            
            final String connectString = args[4];
            final String user = args[5];
            // Try with resources so passphrase is cleared out
            try(Passphrase adminPassword = Passphrase.fromConsole("Enter admin server password:");){  
                // Long delay after entering password is confusing, so give some immediate feedback. 
                System.out.println("Starting online rebind channel certificates command.  AdminServer must be running. ");
                final AdminServerConnectionConfig adminServerConfig = new AdminServerConnectionConfig(connectString, user,adminPassword );                
                logger.info("rebindChannelCerts -online command");                
                rebindChannelCertificatesOnOrOffLine(sslEnvironment, adminServerConfig);
            } catch (IOException e) {
                throw new SSLException("Unable to read admin server password", e);
            } 
        } else {
            logger.info("rebindChannelCerts offline command");            
            if(!disableOfflineCheck){
                checkOfflineWhy(sslEnvironment.getHomes(), "Servers are running.  Either use the online variant of this command, or stop all servers and run this offline variant again");
            }            
            rebindChannelCertificatesOnOrOffLine(sslEnvironment, null);
        }
    }
    
    /**
     * Implement the 'internalssl' command.  This is the central command.  It turns internal ssl on or off. 
     */
    private void internalSSLCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCountRange(command, args, 4, 5);
        
        final Homes homes = sslEnvironment.getHomes(); 
        boolean disableofflineCheck = false;
        for(int i = 4; i < args.length; i++){
            if(DISABLE_OFFLINE_CHECK.equalsIgnoreCase(args[i])){
                disableofflineCheck = true;
                logger.info("Disabling offline check");
            }
        }

        if(!disableofflineCheck){
            checkOffline(homes);
        }        
        
        final String useSSLString = args[3];
        final boolean useSSL = Boolean.parseBoolean(useSSLString);
        
        logger.info("internalssl command useSSL: " + useSSL);
        
        final Channels channels = new Channels(sslEnvironment,  EchoMode.ECHO_INFO_TO_STD_OUT);
        
        final CredentialAccessor credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        // We require channels to have been created.  Channel creation requires certificates - even if SSL is not currently turned on.  This is 
        // partly just to avoid yet more complexity in the api between the Java and wlst.  If certificates always exist, we can always 
        // pass down (on the command line for security) the certificate passphrase.  
        if( !credentialAccessor.passphraseExists(CredentialAccessor.SSL_INTERNAL_PASSPHRASE)){
            throw new SSLException(
                    "SSL certificates must be created even if internalssl is false.  \n" +
                    "This ensures that channels can be correctly setup, ready for internalssl.  \n" +
                    "Run command <DomainHome>/bitools/bin/ssl[.sh] regenerate <days>");
        }
        
        
        if( useSSL){
            // topupCerts fails if certificates never created.  So check for certificate health first. 
            final ExpiryResult expiryResult = checkCerts("Unable to turn on internal SSL.", sslEnvironment);            
            
            channels.setUseSSL(SSLProtocol.https);
            // In case listeners have changed.
            topupCerts(sslEnvironment);
            
            System.out.println("Internal BIEE communications have been configured to use SSL with certificates \n" +
                               "matching the current listening addresses.  Rerun if you change the addresses. \n"+ 
                               "To achieve end to end security you also need to review the SSL configuration  \n" + 
                               "of other components, including the external ports of WebLogic servers. " );
            System.out.println();
            // Display first expiry date/warning if about to expire. 
            System.out.println( expiryResult.getResultString() );
                               
        } else {
            channels.setUseSSL(SSLProtocol.http);
            System.out.println("Internal BIEE communications have been configured to not use SSL.  \n" +
                               "Sensitive information will be transmitted in the clear.");
        }
        System.out.println("\nStartup all BIEE servers to consume the new configuraton.  For example run the start[.sh] " + 
                           "command line tool in the same directory as this ssl tool.");
        
    }
    
    /*
     * Implement the 'regenerate' command.  Creates new certificate authority and server certificates
     */
    private void regenerateCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCountRange(command, args, 4, 6);
        boolean disableOfflineCheck = false;

        for(int i = 4; i < args.length; i++){ 
            if(DISABLE_OFFLINE_CHECK.equalsIgnoreCase(args[i])){
                disableOfflineCheck = true;
                logger.info("Disabling offline check");
            }
        }

        if(!disableOfflineCheck){
            checkOffline(sslEnvironment.getHomes());
        } 
                
        final String daysString = args[3];
        final int days;
        try {
            days = Integer.parseInt(daysString);
        } catch(  NumberFormatException e){
            final String msg = "Days " + daysString + " is not an integer.";
            reportBadUsage(msg);
            throw BadStatusException.BAD_USAGE_STATUS;
        }
        if( days <= 0){
            final String msg = "Days " + days + " must be at least 1.";
            reportBadUsage(msg); 
            throw BadStatusException.BAD_USAGE_STATUS;
        }
        final SANOption sanOption;
        if( args.length >= 6 || (args.length == 5 && !disableOfflineCheck)){
            final String sanOptionString = args[4];
            if( "CN".equals(sanOptionString)){
                sanOption = SANOption.USE_COMMON_NAME;
            } else if( "SAN".equals(sanOptionString)){
                sanOption = SANOption.USE_SUBJECT_ALTERNATE_NAME;
            } else {
                final String msg = "Certificate name option '" + sanOptionString + "' not supported.";
                reportBadUsage(msg); 
                throw BadStatusException.BAD_USAGE_STATUS;
            }
        } else {
            sanOption = SANOption.getDefaultSANOption();
        }
        
        logger.info("regenerate command.  Days: " + days);
        
        final KeyStoreType keyStoreType = KeyStoreType.getDefaultKeyStoreType();
        
        // Use default stripe. 
        final IdentityFactory factory = new IdentityFactory(sslEnvironment, keyStoreType, getEndpointManager(sslEnvironment.getHomes()));
        // Use random passphrases.
        final List<DistinguishedName> subjects = factory.generateInternalCertificates(new CertOptions(days, sanOption));
        System.out.println("Created " + subjects.size() + " certificates with subjects:\n ");
        for( DistinguishedName subject: subjects){
            System.out.println("  " + subject);
        }
        System.out.println("Regenerate has replaced the internal certificate authority (CA).  ");
        System.out.println("  (1) You must restart to use consistent new identity and new CA certificates. ");
        System.out.println("  (2) Any previously exported certificates will be invalid.  You must repeat the 'exportclientcerts' command. ");
        
    }
    
    /**
     * Implement the 'targetapps' command.  Targets applications at the appropriate channels, depending on whether the 
     * <OracleHome>/<ProductHome>/endpointmanager/jeemaps entry defines the endpoint as internal, external, or dual. 
     * 
     */
    private void targetAppsCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCountRange(command, args, 4, 5);
        
        final Homes homes = sslEnvironment.getHomes(); 
        boolean disableOfflineCheck = false;
        for(int i = 4; i < args.length; i++){  
            if(DISABLE_OFFLINE_CHECK.equalsIgnoreCase(args[i])){
                disableOfflineCheck = true;
                logger.info("Disabling offline check");
            }
        }

        if(!disableOfflineCheck){
            checkOffline(homes);
        }   
        
        final String target = args[3];
        
        logger.info("targetapps command. target: " + target);
        final Channels channels = new Channels(sslEnvironment, EchoMode.ECHO_INFO_TO_STD_OUT);
        channels.targetApps(target);
        
        System.out.println("Applications targeted at internal channels.  ");
    }
    
    /**
     * Implement the 'retargetapps' command.  Only has any effect if internal channels (and heven internal virtual host) 
     * have already been configured.  Targets applications at the appropriate channels, depending on whether the 
     * <OracleHome>/<ProductHome>/endpointmanager/jeemaps entry defines the endpoint as internal, external, or dual. 
     * 
     */
    private void retargetAppsCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCount(command, args, 3);
        final Homes homes = sslEnvironment.getHomes();
        checkOffline(homes);        
        
        logger.info("retargetapps command. " );
        final Channels channels = new Channels(sslEnvironment, EchoMode.ECHO_INFO_TO_STD_OUT);
        channels.targetApps(null);
        // The channels WLST will log an warn level - and hence to the console - whether retargetting took place.  
        
    }
    
    /**
     * Implement the 'expiry' command.  List information about expiry dates of the certificates (both server and Certificate Authority) that 
     * we created. 
     * 
     */
    private void expiryCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        checkArgCount(command, args, 3);
        // ok on and offline
        
        logger.info("expiry command");
        
        final KeyStoreType keyStoreType = KeyStoreType.getDefaultKeyStoreType();
        
        // Use default stripe. 
        final IdentityFactory factory = new IdentityFactory(sslEnvironment, keyStoreType, getEndpointManager(sslEnvironment.getHomes()));
        final ExpirySummary expirySummary = new ExpirySummary(factory);
        System.out.println( expirySummary.getList());
        System.out.println( expirySummary.getResultString() );
        // Allow shell scripts to make use of the expiry conclusion by exiting with error values if wanring or error. 
        final ExpiryResult expiryResult = expirySummary.getResult();
        if( expiryResult == ExpiryResult.EXPIRED){
            throw BadStatusException.EXPIRED_STATUS;
        } else if (expiryResult == ExpiryResult.WARNING){
            throw BadStatusException.EXPIRY_WARNING_STATUS;
        } else if ( expiryResult == ExpiryResult.MISSING){
            throw BadStatusException.CERTS_MISSING_STATUS;
        }
    }
    
    /**
     * Implements the 'report' command.  Attempt to connect to BIEE components using ssl. 
     *
     */
    private void reportCommand(String command, SSLEnvironment sslEnvironment, String[] args) throws SSLException, BadStatusException{
        // OK offline (just get lots of cannot connect) and online. 
        
        final Set<String> instances = new HashSet<String>();
        for(int index = 3; index < args.length; index++){
            instances.add(args[index]);
        }    
        
        logger.info("report command.  Instances: " + instances);
        
        final SecurityProviders securityProviders = SecurityProviders.getInstance();
        // If security providers available do not match those configured dump information about classpath.  
        // Omission from the classpath is the most common reason for a configured security provider being silently omitted. 
        // Do not include information about services offered by each SecurityProviders - this is fixed by the Security 
        // provider implementations so does not vary.  Its also exceedingly verbose. 
        securityProviders.doDump(System.out, EnumSet.of(SecurityProviders.DumpScope.CLASSPATH));      
        
        final KeyStoreType keyStoreType = KeyStoreType.getDefaultKeyStoreType();
        
        final Report report = new Report(System.out, sslEnvironment, keyStoreType, getEndpointManager(sslEnvironment.getHomes()), false);
        final int reportFailures;
        if( instances.isEmpty()){
            // Default to all types
            reportFailures = report.scanAllTypes();
        } else {
            reportFailures = report.scanInstances(instances);   
        }
        System.out.println();
        
        final IdentityFactory factory = new IdentityFactory(sslEnvironment, keyStoreType, getEndpointManager(sslEnvironment.getHomes()));
        final ExpirySummary expirySummary = new ExpirySummary(factory);
        System.out.println( expirySummary.getResultString() );
        
        // Do errors first, only return a warning status if no error. 
        final ExpiryResult expiryResult = expirySummary.getResult();
        if( expiryResult == ExpiryResult.EXPIRED){
            throw BadStatusException.EXPIRED_STATUS;
        } else if ( expiryResult == ExpiryResult.MISSING){
            throw BadStatusException.CERTS_MISSING_STATUS;
        } 
        if( reportFailures > 0 ){
            throw BadStatusException.SCAN_FAILURE_STATUS;
        }
        
        // Lower priority warning
        if( expiryResult == ExpiryResult.WARNING){
            throw BadStatusException.EXPIRY_WARNING_STATUS;
        }
    }
    
    // The wiring 
    // ============================
    
    
    /**
     * Command line entry point. 
     */
    public static void main(String [] args) {
        // Programmatically allow unlimited ciphers.
        Security.setProperty(CipherConverter.CRYPTO_POLICY_KEY, "unlimited");
        final SSLCommand sslCommand = new SSLCommand(null);
        final int retStatus = sslCommand.mainEx(args);
        System.exit(retStatus);
    }
    
    
    private static void reportBadUsage(String message){
        System.out.println(message);
        printUsage();
        
    }
    /**
     * 
     * @param endpointManager if non-null override default endpoint manager
     */
    public SSLCommand(EndpointManager endpointManager){
        this.endpointManager = endpointManager;
    }
    
    /**
     * Return either the injected endpoint manager, of the default (real) one.  Remember endpoint manager so we do not 
     * suffer the overhead of creating more than once. 
     * @param homes
     * @return
     */
    private EndpointManager getEndpointManager(Homes homes){
        
        if( endpointManager == null){
            final EndpointManagerFactory emFactory = new EndpointManagerFactory();
            endpointManager = 
                    emFactory.getEndpointManager(homes.getDomainLocations().getDomainHome(), homes.getOracleHomeLocations().getBiProductHome() );
        }
        return endpointManager;
    }
    /**
     * Returns exit status - unlike main which exits with failure status.  This is the JUnit test access point.  
     * No exceptions are thrown - all have been logged and converted to a status return ready for main's exit.
     * @param args
     * @throws IOException 
     * @throws Exception
     */
    public int mainEx(String ... args) {   
        try {
            executeCommand(args);
        } catch (BadStatusException e){ 
            // Already been reported by thrower
            return e.getStatus();
        } catch (Throwable e) {
            e.printStackTrace();
            // Don't throw another exception - just return the status code
            return BadStatusException.EXCEPTION_STATUS.getStatus();
        }
        // All good 
        return 0;
    }
        
    private void executeCommand(String[] args) throws BadStatusException, SSLException{
    
        if (args.length < 2) {
            final String msg = "Invoke via domain wrapper so oracle home and domain home can be automatically added";
            reportBadUsage(msg);
            throw BadStatusException.BAD_USAGE_STATUS;
        }

        final File oracleHome = new File(args[0]);
        final File domainHome = new File(args[1]); 
        
        // All commands command name. 
        if( args.length < 3) {
            final String msg = "Need command";
            reportBadUsage(msg); 
            throw BadStatusException.BAD_USAGE_STATUS;
        }
        
        final String command = args[2];        
        
        final Homes homes = new Homes(oracleHome, domainHome);
        try {
            directLogs(homes);
        } catch (IOException e) {
            throw new SSLException("Unable to redirect logs");
        }        
        
        final SSLEnvironment sslEnvironment = new SSLEnvironment(homes);
        // If we are miss-configured fail fast.   FIPS systems are currently only in GOV cloud, entirely under our control. 
        // So we can require specific configuration.  Non FIPS systems could be in OAS, configured by a customer using their choice of 
        // security providers.  So for backward compatibility do not check non-FIPS configuration.  
        
        final SecurityProviders securityProviders = SecurityProviders.getInstance();
        // Use check instead of checkOnce so if running repeatedly in a test environment will check each time. 
        // In real command line usage this will always be the first call, so they are equivalent. 
        // The exception itself now includes the security providers dump
        securityProviders.check(sslEnvironment.getConfigWrapper());
        
        
        if (command.equalsIgnoreCase("report") ) {
            reportCommand(command, sslEnvironment, args); 
        } else if (command.equalsIgnoreCase("expiry") ){
            expiryCommand(command, sslEnvironment, args);             
        } else if (command.equalsIgnoreCase("regenerate") ){
            regenerateCommand(command, sslEnvironment, args);  
        } else if ( command.equalsIgnoreCase("rebindchannelcerts") ){
            rebindChannelCertsCommand(command, sslEnvironment, args);
        } else if (command.equalsIgnoreCase("exportclientcerts") ){
            exportClientCertsCommand(command, sslEnvironment, args);            
        } else if (command.equalsIgnoreCase("channel") ){
            channelCommand(command, sslEnvironment, args); 
        } else if (command.equalsIgnoreCase("channels") ){
            channelsCommand(command, sslEnvironment, args); 
        } else if (command.equalsIgnoreCase("internalssl") ){
            internalSSLCommand(command, sslEnvironment, args);       
        } else if (command.equalsIgnoreCase("targetapps") ){
            targetAppsCommand(command, sslEnvironment, args);            
        } else if (command.equalsIgnoreCase("retargetapps") ){
            retargetAppsCommand(command, sslEnvironment, args);            
        } else if (command.equalsIgnoreCase("listciphers") ){
            listCiphersCommand(command, sslEnvironment, args);            
        } else if (command.equalsIgnoreCase("listtrust") ){
            listTrustCommand(command, sslEnvironment, args);    
        } else {
            final String msg = "Command " + command + " not supported.";
            reportBadUsage(msg);
            throw BadStatusException.BAD_USAGE_STATUS;
        }
    }
    
    /**
     * Throw if certificates missing or expired.  
     * @param comment
     * @param homes
     * @return expiry result so expiry warning/next expiry date can be shown at end of operaton
     * @throws BadStatusException
     * @throws SSLException 
     */
    private ExpiryResult checkCerts(String comment, SSLEnvironment sslEnvironment) throws BadStatusException, SSLException {
        final KeyStoreType keyStoreType = KeyStoreType.getDefaultKeyStoreType();
        
        final IdentityFactory factory = new IdentityFactory(sslEnvironment, keyStoreType, getEndpointManager(sslEnvironment.getHomes()));
        final ExpirySummary expirySummary = new ExpirySummary(factory);
        
        final ExpiryResult expiryResult = expirySummary.getResult();
        if( expiryResult == ExpiryResult.EXPIRED){
            System.out.println( comment );
            System.out.println(" Certificates have expired.  You should run ssl[.sh] regenerate. " );
            throw BadStatusException.EXPIRED_STATUS;
        } else if ( expiryResult == ExpiryResult.MISSING){
            System.out.println( comment );
            System.out.println( "Certificates are missing.  You should run ssl[.sh] regenerate. " );
            throw BadStatusException.CERTS_MISSING_STATUS;
        }
        return expiryResult;
    }
    
    
    /**
     * Create any required new certificates.  Run after creating new channels, or after enabling ssl. 
     * New certificates are required if any listener addresses have changed so that the common name
     * matches the address used to invoke the endpoint.  
     * @param homes
     */
    private void topupCerts(SSLEnvironment sslEnvironment) throws SSLException{
        logger.info("topup certificates");
        final KeyStoreType keyStoreType = KeyStoreType.getDefaultKeyStoreType();
        
        // Use default stripe. 
        final IdentityFactory factory = new IdentityFactory(sslEnvironment, keyStoreType, getEndpointManager(sslEnvironment.getHomes()));
        final List<DistinguishedName> subjects = factory.topUpListenerCertificates();
        if( subjects.isEmpty()){
            System.out.println("No new certificates required.");
        } else {
            System.out.println("Added missing certificates for new listening address: " );
            for( DistinguishedName subject : subjects){
                System.out.println( "  " + subject);
            }
        }
    }
    
    /**
     * Check arg count for method
     * @param args including 0 - domain home, 1 - oracle home, 2 - commandName
     * @param requiredCount number of arguments INCLUDING method name and domain and oracle homes
     * @throws BadCommandException
     */
    private static void checkArgCount(String method, String[] args, int requiredCount) throws BadStatusException{
        
        if( args.length != requiredCount) {
            // Do not include oracle home and domain home which are added by the domain home wrapper script for the user. 
            final String msg = "Command '" + method + "' requires " + (requiredCount -3) + " additional parameters. Number supplied was " + (args.length -3);
            reportBadUsage(msg); 
            throw BadStatusException.BAD_ARG_COUNT_STATUS;
        } 
    }
    
    /**
     * Check arg count for method
     * @param args including 0 - domain home, 1 - oracle home, 2 - commandName
     * @param requiredMinCount minimum number of arguments INCLUDING method name and domain and oracle homes
     * @param requiredMaxCount maximum number of arguments INCLUDING method name and domain and oracle homes
     * @throws BadCommandException
     */
    private static void checkArgCountRange(String method, String[] args, int requiredMinCount, int requiredMaxCount) throws BadStatusException{
        
        if( args.length  < requiredMinCount || args .length > requiredMaxCount) {
            // Do not include oracle home and domain home which are added by the domain home wrapper script for the user. 
            final String msg = "Command '" + method + "' requires between " + (requiredMinCount -3) + 
                    " and " + (requiredMaxCount -3) + " additional parameters. Number supplied was " + (args.length -3);
            reportBadUsage(msg); 
            throw BadStatusException.BAD_ARG_COUNT_STATUS;
        } 
    }
    
    /**
     * Direct logs to a file.  
     * @param homes
     * @throws IOException
     * @throws SSLException 
     */
    private void directLogs(Homes homes) throws IOException, SSLException{
        final File logDir = homes.getDomainLocations().getBILogs();
        final File logFile = new File(logDir, "sslcommand.log");
        FileLogging.directLogsToFile(oracleLogger, logFile);
        
        // Also get some brief log chatter on console from eclipse link
        // [EL Info]: server: 2015-05-25 07:45:22.353--ServerSession(427606821)--Detected server platform: 
        //            org.eclipse.persistence.platform.server.NoServerPlatform.
        // Have not managed to turn this off yet. 
        
        System.out.println("Logging to: " + logFile.getAbsolutePath() );
        System.out.println();
    }
    
    /**
     * Most commands should only be run with domain offline (ie stopped) in order to ensure:
     *  - Running admin server does not lock or overwrite domain configuration. 
     *  - System components which only support picking up configuration on restart are restarted
     *  - only have to implement one version of the underlying WLST scripts.  Unfortunately WLST offline and online 
     *    have many differences - and not just in how to connect to the domain.  Targetting webapps is completely different. 
     * There are a few commands where either they are intrinsically offline/online independency (eg read only commands), or 
     * have a special online variant to support a particular online use case. 
     * @throws BadStatusException 
     */
    private void checkOffline(Homes homes) throws BadStatusException{
        checkOfflineWhy(homes, "This command is only supported when the domain has been stopped.  Run <DomainHome>/bitools/bin/stop.sh command. ");
    }
    
    /**
     * With a custom explanation.  USe this when the command has an online variant. 
     * @param homes
     * @param comment
     * @throws BadStatusException
     */
    private void checkOfflineWhy(Homes homes, String comment) throws BadStatusException{
        final OnLineDetector onLineDetector = new OnLineDetector(this.getEndpointManager(homes));
        final List<RegisteredEndpoint> upEndpoints = onLineDetector.getUpEndpoints();
        if( !upEndpoints.isEmpty()){
            System.out.println(comment);
            System.out.println("The following endpoints are running:");
            for( RegisteredEndpoint endpoint : upEndpoints){
                System.out.println("  " + endpoint);
            }
            throw BadStatusException.NOT_OFFLINE_STATUS;
        }
    }
    
    private static void printUsage() {
        // Order of home args consistent with sync mid tier db
        // Exclude the first oracle home/domain home arguments since these are added by the wrapper  
        System.out.println("Usage: ");
        System.out.println();
        System.out.println("All commands may be run repeatedly.  The options given on the last run take effect. ");
        System.out.println("Offline commands must be run with the domain stopped. ");
        System.out.println("Online commands should be run with the domain running.");
        System.out.println();
        System.out.println("Basic commands:");
        System.out.println("   internalssl true|false");
        System.out.println("     Offline command. Choose protocol for use on channels.  Verifies channel setup, and ");
        System.out.println("     if enabling ssl rebinds channel certificates to current listener addresses. If run without previously running the  ");
        System.out.println("     BIEE config assistant it will prompt you to run various advanced configuration commands to setup the required ");
        System.out.println("     channels. ");
        System.out.println("   report [instance-1] ... [instance-n]");
        System.out.println("     On line command.  Peform an SSL ping against listed instances to test health of SSL configuration.  For example:");
        System.out.println("         report obis1 obis2");
        System.out.println("     If no instance given pings all instances. For example:" );
        System.out.println("         report ");
        System.out.println("   expiry");
        System.out.println("     Offline or online.  Displays information about the nearest expiry date of the generated certificates.  If they ");
        System.out.println("     have expired, or are about to, you should run the regenerate command. ");
        System.out.println("   exportclientcerts dir ");
        System.out.println("     Offline or online.  Export internal trust certificate and client identity to directory 'dir'.  They can then be used by clients.  ");
        System.out.println("     Will prompt for a passhrase which will be used to protect Java keystores, key entries, and standalone openssl key files.   ");
        System.out.println();
        System.out.println("Advanced configuration commands:");
        System.out.println("   regenerate <days> [CN|SAN]");
        System.out.println("     Offline command. Regenerate internal SSL certificates, using a new internal certificate authority.  ");
        System.out.println("     The <days> parameter defines the lifespan of the certificates.  Some organizations have standards probiting ");
        System.out.println("     any certificate lifespan over say one year.  Others require all certificates to have very long lifespans, say 30 years.");
        System.out.println("     Clients using the certificates superseded by the regenerated certificates will no longer be able to connect.");
        System.out.println("     Certificates must be generated to support internal channels, even if internalssl false is used.  This ensures.");
        System.out.println("     that the channels are ready for SSL use if required later.  ");
        System.out.println("     Optionally specify whether common name 'CN' or Subject Alternate Name 'SAN' host identification should be used.");
        System.out.println("   rebindchannelcerts [-online host:port adminUser]");
        System.out.println("     Offline or online command. Update certificates to match any changes in channel listeners.  The internalssl true command does this ");
        System.out.println("     automatically, so you only need to call if a listener is changed after internal ssl is enabled.  To use online give ");
        System.out.println("     the admin server connect string (host:port) and an admin user.  You will then be prompted for the admin user's password");
        System.out.println("   channel <server> [port]");
        System.out.println("     Offline command. Run this after internalssl true|false prompts you to do so.  ");
        System.out.println("     Create or update a private channel on the server listening on given port.  Only required for servers  "); 
        System.out.println("     not created by the config assistant, or if the channel SSL configuration has been overridden by use of the ");
        System.out.println("     'Use Demo Identity And Demo Trust' option.  If the channel already exists the port may be omitted, in which ");
        System.out.println("     case the existing port remains unchanged.");
        System.out.println("   channels <path>");
        System.out.println("     Offline command. Run this after internalssl true|false prompts you to do so.  ");
        System.out.println("     Creates or updates a private channel on each server listening on a given port. "); 
        System.out.println("     File path specified should point to file containing <server> [port] (one server and port combination per line) ");
        System.out.println("     for each server to be configured.  Only required for servers  "); 
        System.out.println("     not created by the config assistant, or if the channel SSL configuration has been overridden by use of the ");
        System.out.println("     'Use Demo Identity And Demo Trust' option.  If the channel already exists the port may be omitted, in which ");
        System.out.println("     case the existing port remains unchanged.");
        System.out.println("   targetapps <target>");
        System.out.println("     Offline command.  Run this after internalssl true|false prompts you to do so.  ");
        System.out.println("     Target applications at the bi_internal_channel1 ready for configuring the channel to use ssl.");
        System.out.println("     The 'target' argument is the current WebLogic target of all BI applications.  In a compact domain this should be AdminServer, in an ");
        System.out.println("     expanded domain the cluster, eg bi_cluster. Only required if the BI Config Assistant has not been run. To repair ");
        System.out.println("     previous targeting you can alternatively use retargetapps, which does not need the target argument.");
        System.out.println("   retargetapps");
        System.out.println("     Offline command.  If apps have previously been targeted at the bi_internal_channel1 retarget new applications.  ");
        System.out.println("     If apps have not been previously targeted does nothing.  ");
        System.out.println("     Only required if new web applications have been added.  Run automatically by upgrade. ");
        System.out.println("   listciphers");
        System.out.println("     Offline or online.  List cipher names. ");
        System.out.println("   listtrust");
        System.out.println("     Offline or online.  List default trust configured for components running in web logic managed servers talking ");
        System.out.println("     to external addresses.");
        System.out.println();
        
        
         
    }
    
    
}
