package oracle.bi.ssl.certificate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import oracle.bi.ssl.pub.CertOptions;
import oracle.bi.ssl.pub.SANOption;

/**
 * Support saving certificate options
 * 
 *
 */
public final class CertOptionsStore {
    private final static String SAN_OPTION_KEY = "SAN_OPTION";
    private final static String EXPIRY_DAYS_KEY = "EXPIRY_DAYS";
    
    /**
     * No instances.
     */
    private CertOptionsStore(){
        
    }
    
    /**
     * Store content of CertOptions ready for recovery by {@link #readCertOptions(File)}
     * @param file
     * @param certOptions
     * @throws IOException
     */
    public static void storeCertOptions(File file, CertOptions certOptions) throws IOException{
        final Properties properties = new Properties();
        properties.setProperty(SAN_OPTION_KEY, certOptions.getSanOption().name());
        properties.setProperty(EXPIRY_DAYS_KEY, Integer.toString(certOptions.getExpiryDays()));
        
        try( OutputStream os = new FileOutputStream(file);){
            properties.store(os, "Certificate options");
        }
        
    }
    
    /**
     * Recover cert options previously stored with {@link #storeCertOptions(File, CertOptions)}
     * @param file
     * @return
     * @throws IOException
     */
    public static CertOptions readCertOptions(File file) throws IOException{
        final Properties properties = new Properties();
        try(InputStream is = new FileInputStream(file);){
            properties.load(is);
        }
        final String sanOptionString = getRequiredProperty(properties, SAN_OPTION_KEY);
        
        final String expiryDaysString = getRequiredProperty(properties, EXPIRY_DAYS_KEY);
        final int expiryDays;
        try {
            expiryDays = Integer.parseInt(expiryDaysString);
        } catch (NumberFormatException e){
            throw new IllegalStateException("In file " + file.getAbsolutePath() + " key " + EXPIRY_DAYS_KEY + " value " + expiryDaysString + " not a number", e);
        }
        
        final SANOption sanOption = SANOption.valueOf(sanOptionString);
        
        return new CertOptions(expiryDays, sanOption);
    }
    
    /**
     * Throw if key does not exist
     * @param properties
     * @param key
     * @return
     */
    private static String getRequiredProperty(Properties properties, String key){
        final String ret = properties.getProperty(key);
        if( ret == null){
            throw new IllegalStateException("Required property " + key + " missing");
        }
        return ret;
    }
}
