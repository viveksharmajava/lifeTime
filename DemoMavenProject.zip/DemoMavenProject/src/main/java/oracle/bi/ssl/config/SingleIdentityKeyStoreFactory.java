package oracle.bi.ssl.config;

import java.io.IOException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.pub.SSLException;


/**
 * Constructs a KeyStore which only exposes the key at one predefined alias. 
 */
public final class SingleIdentityKeyStoreFactory
{
    /**
     * No instances. 
     */
    private SingleIdentityKeyStoreFactory() 
    {
        
    }
    
    
    /**
     * Extract single key entry from fullKeyStore, and store in a local in memory keystore.  This ensures that only that 
     * key is used for identities.  Normally the SSL handshake in a client is free to use any identity which matches the 
     * allowed CAs in the certificate request.   
     * This is much simpler than wrapping the original full KeyStore with observers which filter out calls for other aliases. 
     * If the fullKeyStore is from the JPS keystore service this also ensures that 
     * only this call needs code grants.  Subsequent observer methods on the local copy do not need code grants.
     * @param fullKeyStoreAccessor
     * @param alias
     * @param pwd
     * @return a local keystore containing the one key, protected by the same password
     *  
     */
    public static KeyStore createSingleIdentityKeyStore(
            KeyStoreAccessor fullKeyStoreAccessor, 
            KeyStoreType keyStoreType,
            String alias, 
            Passphrase keystorePassphrase, 
            Passphrase keyPassphrase) 
            throws SSLException
    {
        if( fullKeyStoreAccessor == null){
            throw new IllegalArgumentException("null fullKeyStore");
        }
        if( alias == null){
            throw new IllegalArgumentException("null alias");
        }        
        
        try {
            final KeyStore fullKeyStore = fullKeyStoreAccessor.getKeyStore();
            if( fullKeyStore.size() == 0 ){
                throw new SSLException("Base identity keystore " + fullKeyStoreAccessor.getComment() + " is empty");
            }
            
            if( !fullKeyStore.containsAlias(alias)){
                final Enumeration<String> aliasEnumerator = fullKeyStore.aliases();
                final List<String> aliases = new ArrayList<>();
                while( aliasEnumerator.hasMoreElements()){
                    aliases.add(aliasEnumerator.nextElement());
                }
                throw new SSLException("Base identity keystore does not contain alias '" + alias + "' has: " + aliases);
            }
            
            if( !fullKeyStore.isKeyEntry(alias)){
                throw new SSLException("Base identity keystore does not contain key at alias " + alias);
            }
            
            
            final KeyStore singleIdentityKeyStore = KeyStore.getInstance(keyStoreType.name());
            
            // Init as empty keystore, with same keystore wide passphrase.
            singleIdentityKeyStore.load(null, keystorePassphrase.getPassphraseChars());
            
            // Copy the single entry over, with the original pwd continuing as the key passphrase.
            final KeyStore.PasswordProtection passwordProtection = new KeyStore.PasswordProtection(keyPassphrase.getPassphraseChars());
            final KeyStore.Entry entry = fullKeyStore.getEntry(alias, passwordProtection);
            if( entry == null){
                // Should not get null due to prerequisite checks above, but throw to keep code analysis happy. 
                throw new SSLException("Alias " + alias + " not found");
            } else if( entry instanceof KeyStore.PrivateKeyEntry){
                KeyStore.PrivateKeyEntry keyEntry = (KeyStore.PrivateKeyEntry)entry;
                singleIdentityKeyStore.setKeyEntry(
                        alias, keyEntry.getPrivateKey(), keyPassphrase.getPassphraseChars(), keyEntry.getCertificateChain());
            } else {
                // Should not get wrong type due to prerequisite checks above, but throw to keep code analysis happy.
                throw new SSLException("Alias " + alias + " is not a private key entry - is a " + entry.getClass().getName() );
            }
            
            //fullKeyStoreAccessor.dumpKeyStoreDiagnosticsToFile("singleidentityok");
            
            return singleIdentityKeyStore;
            
        } catch (SSLException sslException){
            // Already an SSLException so do not wrap. 
            try {
                fullKeyStoreAccessor.dumpKeyStoreDiagnosticsToFile("singleidentityfailed");
            } catch (IOException e) {
                sslException.addSuppressed(e);
            }
            throw sslException;
        } catch(Exception e){
            try {
                fullKeyStoreAccessor.dumpKeyStoreDiagnosticsToFile("singleidentityfailed");
            } catch (IOException dumpingException) {
                e.addSuppressed(dumpingException);
            }
            throw new SSLException("Cannot create SingleIdentityKeystore", e);
        }
    }
    
    
    

}
