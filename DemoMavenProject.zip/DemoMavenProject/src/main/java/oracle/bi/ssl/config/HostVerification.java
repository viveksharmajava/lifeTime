package oracle.bi.ssl.config;

/**
 * Whether the host name used by a client must match that in either certificate subject common name (deprecated) or 
 * in subject alternate name. 
 * 
 *
 */
public enum HostVerification {
    ALLOW_ANY_HOST, 
    MATCH_HOST
}
