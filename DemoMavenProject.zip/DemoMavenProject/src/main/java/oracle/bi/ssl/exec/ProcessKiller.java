package oracle.bi.ssl.exec;

/**
 * Allows a synchronous process to be killed.  
 *
 */
public class ProcessKiller {
    private Process process = null;
    
    void setProcess(Process process){
        this.process = process;
    }
    
    public void kill(){
        if( process == null){
            throw new IllegalStateException("No process registered");
        }
        process.destroy();
    }
    
}
