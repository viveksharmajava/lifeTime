package oracle.bi.ssl.certificate;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Optional extensions have to be carried both to creation and signing calls. 
 * 
 *
 */
public final class CertificateExtensions {
    private final List<String> subjectAlternativeNames;
    
    /**
     * 
     * @param subjectAlternativeNames use empty array for none not null.  Replaces common name, 
     * allowing host names greater than the common name 64 character limit.  Currently have only got the openssl command line to 
     * work with one subject alterntive name, so throw here if there is any attempt to use more than one
     */
    public CertificateExtensions(String ... subjectAlternativeNames ){
        Objects.requireNonNull(subjectAlternativeNames, "null subjectAlternateNames");
        if( subjectAlternativeNames.length > 1){
            throw new IllegalArgumentException("Currently only support one subject alternative name.  Got " + subjectAlternativeNames.length);
        }
        this.subjectAlternativeNames = Arrays.asList(subjectAlternativeNames);
    }
    
    /**
     * Empty list if no subject alternate names required
     */
    public List<String> getSubjectAlternativeNames(){
        return this.subjectAlternativeNames;
    }
    
    @Override
    public String toString(){
        if( this.subjectAlternativeNames.isEmpty()){
            return "No subject alternative names";
        } else {
            return "Subject alternative names: " + this.subjectAlternativeNames;
        }
        
    }
}
