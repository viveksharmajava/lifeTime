package oracle.bi.ssl.certificate;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.Objects;
import java.util.logging.Logger;

import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.credentials.CredentialAccessor;
import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.jps.SingleKeyStoreAccessor;
import oracle.bi.ssl.locations.CertificateLocations;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.EchoMode;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.logging.OnCompletionExecLogger;
import oracle.bi.ssl.openssl.OpensslCommands;
import oracle.bi.ssl.pub.SSLException;
import oracle.bi.zip.AllowAll;
import oracle.bi.zip.Zip;
import oracle.bi.zip.ZipFilter;
import oracle.bi.zip.ZipLocation;

import org.apache.commons.io.FileUtils;

/**
 * Exports trust and identity in a form usable by clients. 
 * 
 * Clients cannot use the master keystores since they are in the keystore service, not simple files.  Clients may be on 
 * different machines with no access to the keystore service.  Clients also do not know the master passphrases. 
 * 
 * The exporter chooses a passphrase to protect the expported keystores. 
 */
public final class Exporter {
    private final static Logger logger = LoggerFactory.createLogger(Exporter.class);
    private final static ZipFilter allowAll = new AllowAll();
    
    private final SSLEnvironment sslEnvironment;
    private final KeyStoreType keyStoreType;
    
    public Exporter(SSLEnvironment sslEnvironment, KeyStoreType keyStoreType){        
        this.sslEnvironment = Objects.requireNonNull(sslEnvironment, "null sslEnvironment");
        this.keyStoreType = Objects.requireNonNull(keyStoreType, "null keyStoreType");
    }
    
    public void exportClientCerts(File targetDir, Passphrase newPassphrase) throws SSLException {
        checkDir(targetDir);
        final File zipFile = new File(targetDir, "clientcerts.zip");
        SSLFileUtils.optionalDeleteFile(zipFile);
        
        final File readmeFile = new File(targetDir, "readme.txt");
        SSLFileUtils.optionalDeleteFile(readmeFile);
        
        try( Zip zip = new Zip(zipFile);){
            try(
               Writer readme = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(readmeFile), Charset.defaultCharset()));){
               exportTrust(targetDir, newPassphrase, zip, readme);
               exportIdentity(targetDir, newPassphrase, zip, readme);
               addReadMeLine(readme, "Zip");
               addReadMeLine(readme, "--------");
               addReadMeLine(readme, "");
               addReadMeLine(readme, "For convenience when copying the exported certificate files to a remote machine exactly the same files are ");
               addReadMeLine(readme, "also included in the zip file " + zipFile.getName() );
               addReadMeLine(readme, "");
            }
            // Finished try with resources block, so readme file flushed. 
            addFileToZip(zip, readmeFile);
        } catch (IOException e){
            throw new SSLException("Failed to create zip file ", e);
            
        }
    }
    
    /**
     * For a standalone client to communicate with internal components a trust (CA) certificate is required. 
     * This is provided as both a openssl style pem file, and a Java keystore. 
     * @param targetDir
     * @param newKeystorePassphrase
     * @throws SSLException
     */
    private void exportTrust(File targetDir, Passphrase newKeystorePassphrase, Zip zip, Writer readme) throws SSLException {
        checkDir(targetDir);
        
        final Homes homes = sslEnvironment.getHomes();
        if( newKeystorePassphrase == null){
            throw new IllegalArgumentException("null newKeystorePassphrase");
        }
        final CertificateLocations certificateLocations = new CertificateLocations(homes.getDomainLocations());
        
        // Copy all internal trust certs so that clients can use a trust dir just like internal components do. Trust 
        // dir has ca in well known file name, and in the hashed file name required for use in a trust dir. 
        final File targetTrustDir = new File(targetDir, "internaltrust");
        SSLFileUtils.createPrivateCleanDir(targetTrustDir);
        
        final File trustDir = certificateLocations.getOpensslCertificateLocations().getInternalTrustDir();
        final File trustFile = certificateLocations.getOpensslCertificateLocations().getInternalTrustCert();
        try {
            FileUtils.copyDirectory(trustDir, targetTrustDir);
        } catch (IOException e) {
            throw new SSLException("Unable to copy trust directory " + trustDir.getAbsolutePath(), e);
        }
        
        
        // We can't simply save the internal trust keystore to a file, since the keystore service keystore 
        // implementation does not support saving to a file.  So must create a new keystore entirely. 
        
        final File destKeyStoreFile = new File(targetDir, "internaltrust.jks");        
        SSLFileUtils.optionalDeleteFile(destKeyStoreFile);
        
        
        
        final KeyStoreAccessor newKeyStore = 
                SingleKeyStoreAccessor.createInMemoryKeyStore(homes.getDomainLocations().getBILogs(), keyStoreType, newKeystorePassphrase);
        newKeyStore.loadX509(certificateLocations.getOpensslCertificateLocations().getInternalTrustCert(), certificateLocations.getKeyStoreNames().getInternalCACertificateAlias() );
        newKeyStore.exportKeyStoreToFile(destKeyStoreFile, newKeystorePassphrase);
        
        addDirToZip(zip, targetTrustDir, "internaltrust");
        addFileToZip(zip, destKeyStoreFile);
       
        addReadMeLine(readme, "Trust");
        addReadMeLine(readme, "--------");
        addReadMeLine(readme, "");
        addReadMeLine(readme, "Clients should always check the certificate of the server.  This requires a trusted Certificate Authority (CA) certificate");
        addReadMeLine(readme,"");
        addReadMeLine(readme, "For OpenSSL clients the trust is defined by individual certificate files. ");
        addReadMeLine(readme, "   The internal BI CA certificate is in: internaltrust/" + trustFile.getName() + " in pem (textual) format");
        addReadMeLine(readme, "The same internal BI CA certificate is also in hashed file name form in the internaltrust directory.  ");  
        addReadMeLine(readme, "This allows multiple trust files to be used by configuring a trust directory rather than a single trust file. ");
        addReadMeLine(readme,"");
        addReadMeLine(readme, "For Java clients the trust is in the keystore: ");
        addReadMeLine(readme, "   " + destKeyStoreFile.getName() );
        addReadMeLine(readme,"");
        addReadMeLine(readme, "The keystore file is protected by the passphrase provided at export time. The OpenSSL certificate files ");
        addReadMeLine(readme, "should be protected by setting restrictive file system permissions.");
        addReadMeLine(readme,"");
    }
    
    
    
    /**
     * 
     * @param dir
     * @param newKeyPassphrase used to protect both identity keystore and the key within it
     * @throws SSLException
     */
    private void exportIdentity(File dir, Passphrase newKeyPassphrase, Zip zip, Writer readme) throws SSLException {
        checkDir(dir);
        if( newKeyPassphrase == null){
            throw new IllegalArgumentException("null keyPassphrase");
        }
        
        final Homes homes = sslEnvironment.getHomes();
        final CertificateLocations certificateLocations = new CertificateLocations(homes.getDomainLocations());
        
        
        
        // Export client not server identity.  We may in future grant permissions on basis of the ssl identity, so we need 
        // to distinguish between a trusted server such as obips calling another server such as scheduler 
        // and a client such as admin tool which needs to give additional credentials such as 
        // an admin user/password. 
        final File clientKey = certificateLocations.getOpensslCertificateLocations().getOpensslClientKey();
        final File clientCert = certificateLocations.getOpensslCertificateLocations().getOpensslClientCertificate();
        
        final File destKey = new File(dir, clientKey.getName());
        final File destCert = new File(dir, clientCert.getName());
        final File destKeyDER = new File(dir, "clientkey.der");
        
        final File destKeyStore = new File(dir, "identity.jks");
        
        SSLFileUtils.optionalDeleteFile(destKey);
        SSLFileUtils.optionalDeleteFile(destCert);
        SSLFileUtils.optionalDeleteFile(destKeyDER);
        SSLFileUtils.optionalDeleteFile(destKeyStore);
        
        SSLFileUtils.copyFilePrivate(clientCert, destCert);
        
        
        
        // We can't simply save the identity keystore since that will have the master passphrase.  Nor can we simply copy 
        // openssl certs since they too will have the master passphrase. 
        final CredentialAccessor credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        // Ensure that on completion passphrase is shredded
        // See findbugs/excludeFilter.xml - problem with try with resources. 
        try( Passphrase originalPassphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
        
            final KeyStoreAccessor newKeyStore = 
                    SingleKeyStoreAccessor.createInMemoryKeyStore(homes.getDomainLocations().getBILogs(), keyStoreType, newKeyPassphrase);
            // Need server key in der format (binary) to load into keystore.  So might as well provide that to clients as well.  
            final ExecLogger execLogger = new OnCompletionExecLogger(logger, EchoMode.NO_ECHO);
            final OpensslCommands opensslCommands = 
                    sslEnvironment.getOpensslCommands(homes.getDomainLocations().getSSLCommandDir(), execLogger);
            
            opensslCommands.changeKeyPassphrase(clientKey, destKey, originalPassphrase, newKeyPassphrase);
            opensslCommands.convertKeyToDERpkcs8( destKey, destKeyDER, newKeyPassphrase);
            final String alias = certificateLocations.getKeyStoreNames().getClientIdentityAlias();
            
            newKeyStore.loadPrivateKey(destKeyDER, clientCert, newKeyPassphrase, alias);
            newKeyStore.exportKeyStoreToFile(destKeyStore, newKeyPassphrase);
        }
        
        addFileToZip(zip, destKey);
        addFileToZip(zip, destKeyDER);
        addFileToZip(zip, destCert);
        addFileToZip(zip, destKeyStore);
        
        addReadMeLine(readme, "Identity");
        addReadMeLine(readme, "--------");
        addReadMeLine(readme, "");
        addReadMeLine(readme, "Clients talking to servers using two way SSL must have their own identity.  Clients talking to servers ");
        addReadMeLine(readme, "using one way SSL do not need their own identity.");
        addReadMeLine(readme, "");
        addReadMeLine(readme, "Identity is defined by the client key and client certificate pair.");
        addReadMeLine(readme, "");
        addReadMeLine(readme, "For OpenSSL clients the client key and client certificate pair are in separate files: ");
        addReadMeLine(readme, "   The client key is in " + destKey.getName() + " in pem (textual) format, and also in " + destKeyDER.getName() + " in der (binary) format ");
        addReadMeLine(readme, "   The client certificate is in " + clientCert.getName() + " in pem (textual) format.");  
        addReadMeLine(readme, "");
        addReadMeLine(readme, "For Java clients the client key and client certificate pair are in the keystore: ");
        addReadMeLine(readme, "   identity.jks ");
        addReadMeLine(readme, "");
        addReadMeLine(readme, "The identity.jks keystore and the client key OpenSSL files are protected by the passphrase provided at export time. ");
        addReadMeLine(readme, "");
    }
    
    private static void addReadMeLine(Writer readme, String line) throws SSLException{
        try {
            readme.write(line);
            readme.write("\n");
        } catch (IOException e) {
            throw new SSLException("Failed to write to readme ", e);
        }
    }
    
    private static void addFileToZip(Zip zip, File file) throws SSLException{
        try {
            zip.addToZip(new ZipLocation(file, "clientcerts/"), allowAll);
        } catch (IOException e) {
            throw new SSLException("Failed to add file " + file.getAbsolutePath() + " to zip file", e);
        }
    }
    private static void addDirToZip(Zip zip, File dir, String location) throws SSLException{
        try {
            zip.addToZip(new ZipLocation(dir, "clientcerts/" + location + "/"), allowAll);
        } catch (IOException e) {
            throw new SSLException("Failed to add directory " + dir.getAbsolutePath() + " to zip file", e);
        }
    }
    private static void checkDir(File dir) throws SSLException{
        if( dir == null){
            throw new IllegalArgumentException("null dir");
        }
        if( !dir.exists() ){
            throw new SSLException("Directory " + dir.getAbsolutePath() + " does not exist.");
        }
        if( !dir.isDirectory()){
            throw new SSLException("Directory " + dir.getAbsolutePath() + " is not a directory");
        }
    }
    
    
    
}
