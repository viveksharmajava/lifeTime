package oracle.bi.ssl.pub;



import oracle.bi.ssl.config.SSLConfigWrapper;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.locations.DomainLocations;

/**
 * Provides access to keystores required by clients to connect to both internal endpoints with certificates signed by the BIEE internal CA, and 
 * to endpoints with domain trust.  
 * 
 *
 */
public final class BIKeyStores {

    private final SSLConfigWrapper sslConfigWrapper;
    
    /**
     * Use in WebLogic or cam environment using the default stripe.   Domain Home is defined by standard system property or environment variable. 
     * @throws SSLException
     */
    public BIKeyStores() throws SSLException {
        this(DomainLocations.fromEnvironment(), null);
    }
    
    /**
     * Use outside WebLogic or cam environment. 
     * @param domainLocations
     * @throws SSLException
     */
    public BIKeyStores(DomainLocations domainLocations, String stripe) throws SSLException{
        if( domainLocations == null){
            throw new IllegalArgumentException("null domainLocations");
        }
        this.sslConfigWrapper = new SSLConfigWrapper(domainLocations, stripe);
    }
    
    /**
     * 
     * @return the BIEE internal trust store, with just the BIEE internal CA certificate. 
     * @throws SSLException
     */
    public KeyStoreAccessor getBIInternalTrustKeyStoreAccessor() throws SSLException{
        // Auto clear by try with resources close.
         return sslConfigWrapper.getBIInternalTrustKeyStoreAccessor();
        
    }
    
    
    public KeyStoreAccessor getDomainTrustKeyStoreAccessor() throws SSLException {
        return sslConfigWrapper.getDomainTrustKeyStoreAccessor();
    }

    public KeyStoreAccessor getBIIdentityKeyStoreAccessor() throws SSLException {
        return sslConfigWrapper.getBIIdentityKeyStoreAccessor();
    }
}
