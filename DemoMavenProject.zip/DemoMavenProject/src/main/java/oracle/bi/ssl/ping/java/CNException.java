package oracle.bi.ssl.ping.java;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class CNException extends CertificateException{
    
    private static final long serialVersionUID = 1L;

    private final String subject;
    private final String allowedCN;
    
    public CNException(X509Certificate serverCertificate, String cn, String allowedCN){
        super("Common name " + cn + " of certificate " + serverCertificate.getSubjectDN().getName() + " does not match allowed " + allowedCN);
        this.subject = serverCertificate.getSubjectDN().getName();
        this.allowedCN = allowedCN;
    }

    public String getSubject() {
        return subject;
    }

    public String getAllowedCN() {
        return allowedCN;
    }
    
}
