package oracle.bi.ssl.locations;

import java.io.File;

import oracle.bi.ssl.commands.AdminServerConnectionConfig;

/**
 * Defines directory and file locations within the oracle home.  Does no validation. 
 *
 */
public final class OracleHomeLocations {
    final File oracleHome;
    
    public OracleHomeLocations(File oracleHome ){
        if( oracleHome == null){
            throw new IllegalArgumentException("null oracleHome");
        }
        this.oracleHome = oracleHome;
    }
    
    public File getOracleHome(){
        return oracleHome;
    }
    
    public File getBiProductHome(){
        return new File(oracleHome, "bi");
    }
    
    
    
    public File getSetProtocolScript(){
        return new File(oracleHome, "bi/modules/oracle.bi.ssl/set_protocol.py");
    }
    
    public File getCreateChannelScript(){
        return new File(oracleHome, "bi/modules/oracle.bi.ssl/create_channels.py");
    }
    
    /**
     * 
     * @param adminServerConfig if null, use offline.  If non-null use online.
     * @return
     */
    public File getRebindChannelCertificatesScript(AdminServerConnectionConfig adminServerConfig){
        if( adminServerConfig == null){
           return new File(oracleHome, "bi/modules/oracle.bi.ssl/rebind_channel_certificates.py");
        } else {
            return new File(oracleHome, "bi/modules/oracle.bi.ssl/rebind_channel_certificates_online.py"); 
        }
    }
    
   
    public File getOracleCommon(){
        return new File(oracleHome, "oracle_common");
    }
    
    public File getServerDir(){
        return new File(oracleHome, "bi/bifoundation/server");
    }
    
    public File getServerBinDir(){
        return new File(getServerDir(), "bin");
    }
    
    public File getOpensslCnfSrc(){
        return new File(getServerBinDir(), "openssl.cnf");
    }
    
    public File getDemoCAKey(){
        return new File(oracleHome, "wlserver/server/lib/CertGenCAKey.der");
    }
    
    public File getDemoCACert(){
        return new File(oracleHome, "wlserver/server/lib/CertGenCA.der");
    }
}
