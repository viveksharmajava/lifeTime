package oracle.bi.ssl.locations;

import java.io.File;

import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.files.SSLFileUtils;
import oracle.bi.ssl.pub.SSLException;

/**
 * Locations within domain home. 
 *
 */
public class DomainLocations {
    private final static String DOMAIN_HOME_SYSTEM_PROPERTY_KEY = "domain.home";
    private final static String DOMAIN_HOME_ENV_KEY = "DOMAIN_HOME";
    
    private final File domainHome;
    
    public DomainLocations(File domainHome) throws SSLException{
        if( domainHome == null){
            throw new IllegalArgumentException("null domainHome");
        }
        FilePrereqs.checkDirExists(domainHome, "domainHome");
        this.domainHome = domainHome;
    }
    
    public static DomainLocations optionallyFromEnvironment(File domainHome) throws SSLException{
        if( domainHome == null){
            return fromEnvironment();
        } else {
            return new DomainLocations(domainHome);
        }
    }
    /**
     * Both WebLogic and cam started standalone processes define domain home - one in system property, one in env 
     * @return
     */
    public static DomainLocations fromEnvironment() throws SSLException{
        String domainHome = System.getProperty(DOMAIN_HOME_SYSTEM_PROPERTY_KEY);
        if( domainHome == null){
            domainHome = System.getenv(DOMAIN_HOME_ENV_KEY);
            if( domainHome == null){
                throw new SSLException(
                        "Neither system property " + DOMAIN_HOME_SYSTEM_PROPERTY_KEY + " nor environment variable " + DOMAIN_HOME_ENV_KEY + " set.");
            }
        }
        return new DomainLocations(new File(domainHome));
    }
    
    /**
     * For interfacing to external utilities which do not understand DomainLocations - within this project should 
     * not need to access domain home to construct locations since there should be a method here for each location.
     * @return
     */
    public File getDomainHome(){
        return domainHome;
    }
    
    public File getFmwConfig(){
        return new File(domainHome, "config/fmwconfig");
    }
    
    public File getJpsConfigJse(){
        return new File(getFmwConfig(), "jps-config-jse.xml");
    }
    
    public File getJpsConfig(){
        return new File(getFmwConfig(), "jps-config.xml");
    }
    
    public File getTmpBI() throws SSLException{
        final File ret = new File(domainHome, "tmp/bi");
        SSLFileUtils.ensureDirExists(ret);
        return ret;
    }
    
    public File getTmpSSL() throws SSLException{
        final File ret = new File(getTmpBI(), "ssl");
        SSLFileUtils.ensureDirExists(ret);
        return ret;
    }
    
    /**
     * Log directory for logs not associated with one server. 
     * @return
     * @throws SSLException
     */
    public File getBILogs() throws SSLException{
        final File ret = new File(domainHome, "bilogs");
        SSLFileUtils.ensureDirExists(ret);
        return ret;
    }
    
    public File getSSLCommandDir() throws SSLException{
        final File ret = new File(getTmpSSL(), "cmd");
        SSLFileUtils.ensureDirExists(ret);
        return ret;
    }
    
    public File getSSLConfigDir() throws SSLException {
        final File ret = new File(getFmwConfig(), "biconfig/core/ssl");
        SSLFileUtils.ensureDirExists(ret);
        return ret;
    }
    
    /**
     * Remember options used at last regenerate command, so so can consistently top up.
     * @return
     */
    public File getSSLCertOptions() throws SSLException{
        return new File(getSSLConfigDir(), "cert.properties");
    }
    
    
    public File getSSLConfigFile() throws SSLException {
        return new File(getSSLConfigDir(), "bi-ssl.xml");
    }
    
    /**
     * Openssl configuration file which provides advanced options such as certificate lengths and durations, 
     * especially for certificate creation. 
     * @return
     */
    public File getOpensslCnf() throws SSLException {
        return new File(getSSLConfigDir(), "openssl.cnf");
    }
}
