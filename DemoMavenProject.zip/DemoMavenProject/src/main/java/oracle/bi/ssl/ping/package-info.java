/**
 * Provides runtime diagnostics to check that SSL connectivity is working.  The live components are typically poor at 
 * reporting why they have failed to connect over SSL.  A dedicated SSL ping can report back in a much more 
 * explicit manner.  Pings to both system components and WebLogic servers are supported.  
 */

package oracle.bi.ssl.ping;