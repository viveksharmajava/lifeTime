package oracle.bi.ssl.pub;

/**
 * Supports customization of certificate construction
 *
 */
public enum SANOption {
    /**
     * Use common name (CN).   This is the old style way of matching hostname to certificate, but cannot support hostnames greater than 64 characters
     */
    USE_COMMON_NAME, 
    /**
     * Use subject alternate name (SAN).   More modern approach.  Also supports wild cards. 
     */
    USE_SUBJECT_ALTERNATE_NAME;
   
    /**
     * 
     * @return the current default.  This is expected to change to USE_SUBJECT_ALTERNATE_NAME once all supporting components 
     * support this option. 
     */
    public static SANOption getDefaultSANOption(){
        return USE_COMMON_NAME;
    }
}
