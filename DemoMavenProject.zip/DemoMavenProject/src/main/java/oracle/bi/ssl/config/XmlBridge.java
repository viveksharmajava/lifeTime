package oracle.bi.ssl.config;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import oracle.bi.base.lcm.model.jaxb.SSLConfig;

/**
 * Supports marshalling and unmarshalling (ie saving and reading) JAXB annotated classes as XML files. 
 * @author pharry
 *
 *
 */
public final class XmlBridge {
    
    private static JAXBContext jaxbContext;
    /**
     * Bug 29904885 - PERFORMANCE - EACH SSL CONFIG READ USES NEW JAXBCONTEXT
     * From the JAXB 2.2 Specification, Section 4.2 JAXB Context:
     * 
     * To avoid the overhead involved in creating a JAXBContext instance, a JAXB application is encouraged to reuse a 
     * JAXBContext instance. An implementation of abstract class JAXBContext is required to be thread-safe, thus, multiple threads 
     * in an application can share the same JAXBContext instance.
     *
     * synchronized so we do not build more than once even if called in multiple threads.
     * 
     * @return
     * @throws JAXBException 
     * @throws IOException
     */
    private static synchronized JAXBContext getJAXBContext() throws JAXBException{
        if( jaxbContext == null){
            jaxbContext = JAXBContext.newInstance(SSLConfig.class);
        }
        return jaxbContext;
    }
    
    public XmlBridge() throws JAXBException{
        
        
        /* Debugging xml parser errors such as: 
           org.xml.sax.SAXNotRecognizedException: http://javax.xml.XMLConstants/feature/secure-processing
            at oracle.xml.jaxp.JXSAXParserFactory.setFeature(JXSAXParserFactory.java:128)
            at com.sun.xml.internal.bind.v2.util.XmlFactory.createParserFactory(XmlFactory.java:121)
            at com.sun.xml.internal.bind.v2.runtime.unmarshaller.UnmarshallerImpl.getXMLReader(UnmarshallerImpl.java:139)
            at javax.xml.bind.helpers.AbstractUnmarshallerImpl.unmarshal(AbstractUnmarshallerImpl.java:157)
            at javax.xml.bind.helpers.AbstractUnmarshallerImpl.unmarshal(AbstractUnmarshallerImpl.java:162)
            at javax.xml.bind.helpers.AbstractUnmarshallerImpl.unmarshal(AbstractUnmarshallerImpl.java:171)
            at javax.xml.bind.helpers.AbstractUnmarshallerImpl.unmarshal(AbstractUnmarshallerImpl.java:189)
            at oracle.bi.ssl.config.XmlBridge.unmarshall(XmlBridge.java:56)
        */
        /*
        final SAXParserFactory factory = SAXParserFactory.newInstance();
        System.out.println("SAXParserFactory: " + factory.getClass().getName());
        try {
            final SAXParser parser = factory.newSAXParser();
            System.out.println("SAXParser: " + parser.getClass().getName());
            final String resourceName = parser.getClass().getName().replace('.', '/') + ".class";
            
            System.out.println( "Lookup resource: " + resourceName + " is at " + Thread.currentThread().getContextClassLoader().getResource(
                    resourceName));
            //  This one gives null pointer exception:
            // System.out.println("Parser is from: " + parser.getClass().getProtectionDomain().getCodeSource().getLocation().toString());
        } catch (ParserConfigurationException | SAXException e) {
            System.out.println("SAXParser initialization failed with");
            e.printStackTrace();
        }
        */
    }
    
    /**
     * Write out xml file representation
     * @throws JAXBException 
     * @throws IOException 
     * @throws FileNotFoundException 
     */
    public void marshall(SSLConfig object, final File outputFile) throws JAXBException, IOException  {
        // generate the xsd & xml
        

        
        try ( OutputStream os = new FileOutputStream(outputFile); 
             ){
            final Marshaller marshaller = getJAXBContext().createMarshaller();
            
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            marshaller.marshal(object,os);
        }
    }
    
    /**
     * Read in from xml file
     * @throws JAXBException 
     */
   public SSLConfig unmarshall(File file) throws JAXBException{
        
        final Unmarshaller unmarshaller = getJAXBContext().createUnmarshaller();
        final Object obj = unmarshaller.unmarshal( file );
        return (SSLConfig)obj;
    }
}
