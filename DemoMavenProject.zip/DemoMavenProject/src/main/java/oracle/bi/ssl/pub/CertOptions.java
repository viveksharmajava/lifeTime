package oracle.bi.ssl.pub;

import java.util.Objects;

/**
 * When creating certificates we can choose optional facilities. 
 * 
 *
 */
public final class CertOptions {
    private final int expiryDays;
    private final SANOption sanOption;
    
    public CertOptions(int expiryDays, SANOption sanOption) {
        this.expiryDays = expiryDays;
        this.sanOption = Objects.requireNonNull(sanOption, "null sanOption");
    }

    public int getExpiryDays() {
        return expiryDays;
    }

    public SANOption getSanOption() {
        return sanOption;
    }
    
    
}
