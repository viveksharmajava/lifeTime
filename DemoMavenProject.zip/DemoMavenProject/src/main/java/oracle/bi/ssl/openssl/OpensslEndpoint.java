package oracle.bi.ssl.openssl;

import java.io.File;

import oracle.bi.ssl.certificate.Passphrase;

/**
 * An openssl endpoint needs these pieces of configuration information: 
 *    trust directory
 *    identify certificate
 *    private key certificate
 *    ciphers
 *    
 * It will also need a passphrase to access the key certificate
 * @author pharry
 *
 */
public final class OpensslEndpoint {
    private final File trustDir;
    private final File certFile;
    private final File keyFile;
    private final Passphrase keyPassphrase;
    private final String ciphers;
    
    public OpensslEndpoint(File trustDir, File certFile, File keyFile, Passphrase keyPassphrase, String ciphers) {
        this.trustDir = trustDir;
        this.certFile = certFile;
        this.keyFile = keyFile;
        this.keyPassphrase = keyPassphrase;
        this.ciphers = ciphers;
    }

    public File getTrustDir() {
        return trustDir;
    }

    public File getCertFile() {
        return certFile;
    }

    public File getKeyFile() {
        return keyFile;
    }

    public Passphrase getKeyPassphrase() {
        return keyPassphrase;
    }
    
    public String getCiphers(){
        return ciphers;
    }
}
