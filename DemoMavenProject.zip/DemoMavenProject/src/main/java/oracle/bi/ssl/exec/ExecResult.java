package oracle.bi.ssl.exec;

import java.util.List;

public final class ExecResult {
    private final List<String> lines;
    
    private final String stderr;
    
    public ExecResult(List<String> lines, String stderr) {
        this.lines = lines;
        this.stderr = stderr;
    }
    
    /**
     * Std out lines
     * @return
     */
    public List<String> getLines() {
        return lines;
    }

    
    public String getStdErr(){
        return stderr;
    }

    
    
}
