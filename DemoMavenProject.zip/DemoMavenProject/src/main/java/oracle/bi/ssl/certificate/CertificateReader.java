package oracle.bi.ssl.certificate;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.ssl.files.FilePrereqs;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;



/**
 * 
 * Supports reading certificates from pem files. 
 */
public final class CertificateReader
{
    private static final Logger _logger = LoggerFactory.createLogger(CertificateReader.class);

    // No instances
    private CertificateReader()
    {
    }

    public static X509Certificate readX509Certificate(File certificateFile) throws SSLException
    {
        final List<X509Certificate> certs = readX509Certificates(certificateFile);
        if( certs.size() > 1 )
        {
            throw new SSLException("Unexpected certificate count " + certs.size() + " in file " + certificateFile );
        }
        //readX509Certificates guarantees at least one.
        return certs.get(0);
    }

    

    

    /**
     * Read a pem certificate file, which may contain multiple certificates.  Throws if file does not contain at least one. 
     */   
    public static List<X509Certificate> readX509Certificates(File certificateFile) throws SSLException
    {
        FilePrereqs.checkNonEmptyFile(certificateFile,  "certificateFile");


        try (FileInputStream certificateFileInputStream =  new FileInputStream(certificateFile);){
            final CertificateFactory cf = CertificateFactory.getInstance("X.509");
            final Collection<? extends Certificate> certificates = 
                    cf.generateCertificates(certificateFileInputStream);

            final List<X509Certificate> ret = new ArrayList<X509Certificate>();
            for (Certificate cert: certificates)
            {
                _logger.log(Level.FINE, "Reading certificate file " + certificateFile + " type " + cert.getType() );

                if (!(cert instanceof X509Certificate)){
                    throw new SSLException("Certificate file " + certificateFile + " contains certificate of unexpected type " +  cert.getClass().getName());
                }

                ret.add( (X509Certificate)cert);
            }

            if( ret.size() == 0){
                throw new SSLException("Certificate file " + certificateFile + " contains 0 certificates");
            }

            return ret;
        } catch (CertificateException | IOException e) {
            throw new SSLException("Failed to read certificate file " + certificateFile + " due to " + e, e);
        }
    }


}
