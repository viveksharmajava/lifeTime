package oracle.bi.ssl.logging;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Java loggers are setup in JEE to log to the server log files at given log levels.  When running the same code in 
 * a console the log pollutes the console output, making console output hard to see.  This class allows us to 
 * control logging in a standalone command line process. 
 *
 */
public class FileLogging {

    /**
     * No instances
     */
    private FileLogging(){
        
    }
    
    /**
     * Loggers are held by weak references within the log manager.  So make sure caller holds onto a reference so this logger 
     * config change does not get lost. 
     * @param logger
     * @param file
     * @throws IOException
     */
    public static void directLogsToFile(Logger logger, File file) throws IOException{
         
        
        // This block configure the logger with handler and formatter  
        final FileHandler fh = new FileHandler(file.getAbsolutePath());  
        final SimpleFormatter formatter = new SimpleFormatter();  
        fh.setFormatter(formatter);
        
        logger.addHandler(fh);
        
        
        // Prevent logging to parent, which will be the console. 
        logger.setUseParentHandlers(false);
    }
}