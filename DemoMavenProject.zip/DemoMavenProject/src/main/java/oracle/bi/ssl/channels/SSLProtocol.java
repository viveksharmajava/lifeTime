package oracle.bi.ssl.channels;

/**
 * String values match those used within WLST. 
 *
 */
public enum SSLProtocol {
   https,
   http
}
