/**
 * Supports creation of certificates, and extraction of existing certificates from the JPS keystore service. 
 * 
 * All certificate manipulation is done by openssl command line invocations.  We could do the same sort of job via the java keytool
 * command line.    Direct Java manipulation via the java crypto classes is avoided.  The command line tools are comparatively well 
 * documented.  Using the crypto apis directly would be much harder to validate. 
 */

package oracle.bi.ssl.certificate;