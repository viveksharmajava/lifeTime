package oracle.bi.ssl.certificate;

import java.io.File;




/**
 * Defines location and encoding of a public certificate.
 */
public final class CertificateSpec
{
   /**
    * Defines encoding of the certificate.  pem is uuencoded with begin certificate and end certificate human readable 
    * header and footer.  DER is binary.  
    */
   public enum CertificateEncoding
   {
        DER("DER"),
        PEM("PEM");
        
        private final String _name;
        
        private CertificateEncoding(String name){
            _name = name;
        }
        
        /**
         * 
         * @return string used in openssl command line x905 command for inform and outform arguments. 
         */
        public String getOpensslFormString(){
           return _name.toUpperCase();
        }
     
        
        /**
         * Create from String.  Case insensitive.
         */
        public static CertificateEncoding fromString(String string){
            final CertificateEncoding ret = Enum.valueOf( CertificateEncoding.class, string.toUpperCase());
            return ret;
        }
   };
   
   
   
   private final File _certificateFile;
   
   private final CertificateEncoding _certificateEncoding;
   
   /**
    * Constructor
    * @param certificateFile
    * @param certificateEncoding
    */
   public CertificateSpec(File certificateFile, CertificateEncoding certificateEncoding)
   {
      if(certificateFile == null){
         throw new IllegalArgumentException("null certificateFile");
      }
      if(certificateEncoding == null){
         throw new IllegalArgumentException("null certificateEncoding");
      }
      _certificateFile = certificateFile;
      _certificateEncoding = certificateEncoding;
   }

   public File getCertificateFile()
   {
      return _certificateFile;
   }

   public CertificateEncoding getCertificateEncoding()
   {
      return _certificateEncoding;
   }
   
   @Override
   public String toString()
   {
      return _certificateFile.toString() + " format " + _certificateEncoding;
   }
   
   /**
    * Return the path to the certificate file
    * @return
    */
   public String getCertFilePath()
   {
       return _certificateFile.getAbsolutePath();
   }
   
   
  
}
