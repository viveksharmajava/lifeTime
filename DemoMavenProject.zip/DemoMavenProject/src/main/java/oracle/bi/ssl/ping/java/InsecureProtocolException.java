package oracle.bi.ssl.ping.java;

/**
 * An SSL client was able to connect to the server using an insecure protocol.  This indicates that the 
 * server is incorrectly secured. 
 *
 */
public class InsecureProtocolException extends Exception {
   
    private static final long serialVersionUID = 1L;

    public InsecureProtocolException(String message){
        super(message);
    }
}
