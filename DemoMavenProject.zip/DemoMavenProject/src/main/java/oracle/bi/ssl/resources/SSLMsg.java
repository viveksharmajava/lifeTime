package oracle.bi.ssl.resources;

import java.util.ListResourceBundle;


public class SSLMsg  extends ListResourceBundle{

    private static final Object[][] messages = new Object[][]
    {
        // SSL related messages
      
        
        {SSLMsgId.SSL_OK, "SSL ping OK.  "},
        {SSLMsgId.SSL_OFF, "SSL ping failed.  Server probably running with SSL OFF.  "},
        {SSLMsgId.CONNECT_FAILURE, "SSL ping failed.  Failed to connect.  Server may be down. "},
        {SSLMsgId.SSL_BAD_HANDSHAKE, "SSL ping failed.  SSL handshake failed.  Server may be running with SSL OFF, or certificates may not match."},
        // Note that single quote must be escaped in resource strings by another single quote.   Otherwise single quoted parts of the string mean do not format.
        {SSLMsgId.BAD_CN, "Common name does not match.  Ensure that the server certificate''s subject has a common name (CN) equal to the host name used to access the server."},
        {SSLMsgId.SSL_FAIL, "SSL connection failed.  See detailed log output."},
        {SSLMsgId.UNEXPECTED_FAILURE, "Unexpected failure."},
        
       
    
    };
    
    /**
     * Get the bundle contents.
     *
     * @return The bundle key/value pairs
     */
    @Override
    protected Object[][] getContents()
    {
        return messages;
    }
}
