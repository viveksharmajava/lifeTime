package oracle.bi.ssl.logging;



import java.util.logging.Logger;

import oracle.bi.ssl.resources.SSLLogMsg;


/**
 * log-config.xml allows log levels to be set per hierarchically named logger.  The code should support multiple loggers
 * so that particular areas can be turned to higher levels.  A common Java convention is to use one logger per class - but this 
 * results in large numbers.  We compromise with one per package. This is really only important for systems with a UI for 
 * picking loggers.  We expect log config for install components to be done by direct edit of the XML file but we stick to the 
 * established pattern. 
 *  
 *
 */
public final class LoggerFactory {
    // Ensure that there is a top level logger so a user can turn on all loggers by selecting just this one and using 
    // logger inheritance. 
    private final static String BASE_LOGGER_NAME = "oracle.bi.ssl";
    private final static Logger s_topLogger = Logger.getLogger(BASE_LOGGER_NAME);
    static {
        if( !LoggerFactory.class.getPackage().getName().startsWith(BASE_LOGGER_NAME)){
            throw new IllegalStateException("Base logger name " + BASE_LOGGER_NAME + " is not base");
        }
        
        s_topLogger.fine("BI SSL loaded");
    }
    
    /**
     * No instances.
     */
    private LoggerFactory() {
        super();
    }
    
    
    
    /**
     * Each class should define their own static logger initialized with their class using this call.  This allows the logging policy to be set here. 
     * 
     * Having a separate logger per class results in a huge number of loggers.  Having one logger for all of the config assistant gives little control.  
     * Compromise on one per package. 
     * @param myClass
     * @return
     */
    public static Logger createLogger(Class<?> myClass){
        final Logger logger = Logger.getLogger(myClass.getPackage().getName(), SSLLogMsg.class.getName());
        
        return logger;
    }
}
