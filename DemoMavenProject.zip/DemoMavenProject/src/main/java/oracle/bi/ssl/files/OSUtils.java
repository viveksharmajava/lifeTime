package oracle.bi.ssl.files;


public class OSUtils
{
  private OSUtils()
  {
  }
  
 
    
  public static boolean isWindowsFamily()
  {
    return System.getProperty("os.name").startsWith("Windows");
  }

  
  
  


  

  
}
