package oracle.bi.ssl.ping;


import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Logger;

import oracle.bi.endpointmanager.pub.EndpointContext;
import oracle.bi.endpointmanager.pub.EndpointContextBase;
import oracle.bi.endpointmanager.pub.EndpointManager;
import oracle.bi.endpointmanager.pub.RegisteredEndpoint;
import oracle.bi.endpointmanager.pub.RegisteredEndpointList;
import oracle.bi.ssl.certificate.EndpointHelper;
import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLConfigWrapper;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.credentials.CredentialAccessor;
import oracle.bi.ssl.files.OSUtils;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.ping.java.JavaPingResult;
import oracle.bi.ssl.ping.java.JavaSSLClient;
import oracle.bi.ssl.ping.openssl.OpensslClient;
import oracle.bi.ssl.ping.openssl.OpensslPingResult;
import oracle.bi.ssl.pub.SSLException;

/**
 * Perform ssl pings over endpoints provided by the endpoint api
 *
 */
public final class Report {
    private final static Logger logger = LoggerFactory.createLogger(Report.class);
    // The monitor ports do not use ssl. 
    // Ensure sorted for cleaner output
    
    // Types which have internal CA, and a single fixed common name (CN).  Therefore not appropriate for HTTPS usage where the CN is 
    // expected to match the address.  Used for system components. 
    // Exclude the Monitor endpoints, since the java ping fails with timeout and the openssl one fails on ssl handshake.  
    // This is because those ports are not ssl enabled! Note that there is no OBIPS_MONITOR port since OBIPS clustering is not managed by 
    // the cluster controller.   
    // "OBIS_MONITOR", "OBISCH_MONITOR", "OBICCS_MONITOR" 
    private final static SortedSet<String> internalScannedTypes = 
            new TreeSet<String>( Arrays.asList("OBIS", "OBIPS", "OBISCH", "OBIJH", "OBICCS" ));
    
    // Types which have internal CA, and common name (CN) matching address.  These are compatible with normal HTTPS usage.  Used for 
    // web apps hosted by WebLogic. 
    private final static SortedSet<String> httpsScannedTypes = new TreeSet<String>( Arrays.asList("BI-SECURITY-SOAP") );
    
    // Sorted by internal, then https
    private final static List<String> allScannedTypes = new ArrayList<String>();
    
    static {
        allScannedTypes.addAll(internalScannedTypes);
        allScannedTypes.addAll(httpsScannedTypes);
    }
    
    private final SSLEnvironment sslEnvironment;
    
    private final KeyStoreType keyStoreType;
    
    private final EndpointManager endpointManager;
    // Whether or not pings should send some data
    private final boolean chat;
    
    
    private final PrintStream ps;
    /**
     * 
     * @param homes
     * @param endpointManager
     * @param chat if true attempt to send data to server.  Use false for pinging operational servers since they will not understand the ping data. 
     * @throws SSLException 
     */
    public Report(
            PrintStream ps, 
            SSLEnvironment sslEnvironment, 
            KeyStoreType keyStoreType,
            EndpointManager endpointManager, 
            boolean chat) throws SSLException{
        
        this.ps = Objects.requireNonNull(ps, "null ps");
        this.sslEnvironment = Objects.requireNonNull(sslEnvironment, "null sslEnvironment");
        this.keyStoreType = Objects.requireNonNull(keyStoreType, "null keyStoreType");
        this.endpointManager = Objects.requireNonNull(endpointManager, "null endpointManager");
        this.chat = chat;
        
        
    }
    
    /**
     * Scan all endpoints whose SSL connectivity is centrally managed, outputting summary information to the print stream given in the constructor. 
     * @param types if null, all types will be scanned
     * @throws SSLException
     * @return number of failures
     */
    public int scanAllTypes() throws SSLException {
        
        if(sslEnvironment.getConfigWrapper().isSslEnabled()){
            dumpSSLConfigSummary();
            return dumpPingResultsSummary(getAllTypesPingResults());
        } else {
            ps.println("Internal SSL not enabled.  Will not perform SSL scan. ");
            return 0;
        }
        
        
    }
    
    /**
     * 
     * @param instances
     * @return number of failures
     * @throws SSLException
     */
    public int scanInstances(Set<String> instances) throws SSLException {
        if(sslEnvironment.getConfigWrapper().isSslEnabled()){
            dumpSSLConfigSummary();
            return dumpPingResultsSummary(getPingResultsForInstances(instances));
        } else {
            ps.println("Internal SSL is not enabled.  Not performing an SSL scan.");
            return 0;
        }
    }
    
    /**
     * Echo the key user configurable items from the cental ssl config. 
     */
    private void dumpSSLConfigSummary(){
        final SSLConfigWrapper sslConfig = sslEnvironment.getConfigWrapper();
        if(sslConfig.isSslEnabled()){
            ps.println("Internal SSL enabled");
            if( sslConfig.isFIPSEnabled() ){
                ps.println("   FIPS 140 enabled");
            } else {
                ps.println("   FIPS 140 not enabled");
            }
            if( sslConfig.isClientVerification() ){
                ps.println("   Client verification enabled (Two way SSL)");
            } else {
                ps.println("   Client verification disabled (One way SSL)");
            }
            if( sslConfig.getOpensslCipherListString().isEmpty() && sslConfig.getSSLAlgorithms().getJavaCipherArray().length == 0){
                ps.println("   Using all available default ciphers");
            } else {
                ps.println("   Using restricted cipher list");
            }
            
            
        } else {
            ps.println("Internal SSL is not enabled");
        }
    }
    
    /**
     * Dump summary of ping results.   
     * @return number of failures  
     * @param pingResults
     */
    private int dumpPingResultsSummary(Collection<PingResult> pingResults){
        
        
        final List<PingResult> failures = new ArrayList<PingResult>();
        final List<PingResult> successes = new ArrayList<PingResult>();
        
        for(PingResult pingResult: pingResults){
            if( pingResult.isPingSuccess() ){
                successes.add(pingResult);
            } else {
                failures.add(pingResult);
            }            
        }
        
        ps.println();
        final int total = successes.size()  + failures.size();
        ps.println( "Summary: Out of " + total + " endpoints " + successes.size() + " succeeded, and " + failures.size() + " failed.");
        ps.println();
        ps.println("Ping successes (" + successes.size() + "):");
        for( PingResult success : successes){
            ps.println( success.getSummary() );
        }
        
        
        ps.println();
        ps.println("Ping failures (" + failures.size() + "):");
        for( PingResult failure : failures){
            ps.println( failure.getSummary() );
        }

        return failures.size();
    }
    
    
    private List<PingResult> getPingResultsForInstances(Set<String> instances) throws SSLException{
        final List<PingResult> ret = new ArrayList<PingResult>();
        final Homes homes = sslEnvironment.getHomes();
        final CredentialAccessor credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        // Ensure that on completion passphrase is shredded
        // See findbugs/excludeFilter.xml - problem with try with resources. 
        try( Passphrase identityKeyPassphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
        
            final Clients clients = new Clients(this.sslEnvironment, identityKeyPassphrase, keyStoreType);
            final EndpointContext context = new EndpointContextBase();
            
            // Instance names are not unique.  Do not use deprecated endpointManager.getEnpointByInstance. 
            // Instead drive by type. 
            
            for( String type : httpsScannedTypes){
                final RegisteredEndpointList endpointList = endpointManager.getRegisteredEndpointsByComponentType(type, context);
                for( RegisteredEndpoint endpoint : endpointList.getEndpoints()){
                    final String instance = endpoint.getInstanceId();
                    if( instances.contains( instance) ){
                        ps.println("Scanning instance: " + instance);
                        ret.add(scanEndpoint( endpoint, clients.getHTTPSJavaSslClient(), clients.getHTTPSOpensslClient()));
                    }
                }
            }
            
            
            for( String type : internalScannedTypes){
                final RegisteredEndpointList endpointList = endpointManager.getRegisteredEndpointsByComponentType(type, context);
                for( RegisteredEndpoint endpoint : endpointList.getEndpoints()){
                    final String instance = endpoint.getInstanceId();
                    if( instances.contains(instance ) ){
                        ps.println("Scanning instance: " + instance);
                        ret.add(scanEndpoint( endpoint, clients.getInternalJavaSslClient(), clients.getInternalOpensslClient()));                        
                    }
                }
            }
            
            
        }
        return ret;
    }
    
    /**
     * 
     * @param instance
     * @return
     * @throws SSLException
     */
    private List<PingResult> scanSingleEndpointType(String type) throws SSLException{
        final Homes homes = sslEnvironment.getHomes();
        // Results take a while, so show some progress
        ps.println("Type: " + type);
        final CredentialAccessor credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        // Ensure that on completion passphrase is shredded
        // See findbugs/excludeFilter.xml - problem with try with resources. 
        try( Passphrase identityKeyPassphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
        
            final Clients clients = new Clients(sslEnvironment, identityKeyPassphrase, keyStoreType);
            
            final RegisteredEndpointList endpointList = endpointManager.getRegisteredEndpointsByComponentType(type);
            if( httpsScannedTypes.contains(type)){
                logger.info("Scanning HTTPS endpoints of type " + type);
                return scanEndpoints(type, endpointList.getEndpoints(), clients.getHTTPSJavaSslClient(), clients.getHTTPSOpensslClient());
            } else {
                logger.info("Scanning internal endpoints of type " + type);
                return scanEndpoints(type, endpointList.getEndpoints(), clients.getInternalJavaSslClient(), clients.getInternalOpensslClient());                
            }
        }
    }
    
    /**
     * Programmatic api
     * @return
     * @throws SSLException
     */
    public List<PingResult> getAllTypesPingResults() throws SSLException{
        if(this.sslEnvironment.getConfigWrapper().isSslEnabled()){
            return scanEndpointTypes(allScannedTypes);
        } else {
            throw new IllegalStateException("Internal SSL not enabled");
            
        }
        
    }
    /**
     * @param types 
     * @return
     * @throws SSLException
     */
    private List<PingResult> scanEndpointTypes(List<String> types) throws SSLException{
        if(types == null){
            throw new IllegalArgumentException("null types");
        }
        
        final List<PingResult> results = new ArrayList<PingResult>();
        for(String type : types){            
            results.addAll(scanSingleEndpointType(type));
        }
        
        return results;
    }
    
    private List<PingResult> scanEndpoints(String type, Collection<RegisteredEndpoint> endpoints, JavaSSLClient javaSslClient, OpensslClient opensslClient){
        
        
        final List<PingResult> results = new ArrayList<PingResult>();
        if( endpoints.isEmpty() ){
            ps.println("    No endpoints of type " + type);
        } else {
            for(RegisteredEndpoint endpoint : endpoints){
                ps.println("    Scanning endpoint " + endpoint);
                logger.info("Scanning endpoint " + endpoint);
                results.add( scanEndpoint(endpoint, javaSslClient, opensslClient) );
            }
        }
        return results;
    }
    
    
    
    /**
     * Ping a single endpoint.
     * @param endpoint
     * @param javaSslClient
     * @param opensslClient
     * @return
     */
    private PingResult scanEndpoint(RegisteredEndpoint endpoint, JavaSSLClient javaSslClient, OpensslClient opensslClient){
        final String host = EndpointHelper.getEffectiveClientListenAddress(endpoint);
        Integer sslPort = endpoint.getSSLPort();
        
        // For temporary use, prior to endpoint api correctly returning sslPorts for CAM components.   
        if( sslPort == null){
             sslPort = endpoint.getPort();
        }    
        
        if( sslPort == null){
            // No ssl port provided, dont attempt to do an ssl ping
            return new PingResult(endpoint);
        } else {
            final JavaPingResult javaPingResult = javaSslClient.ping(host, sslPort, chat);
            final OpensslPingResult opensslPingResult;
            if( OSUtils.isWindowsFamily()){
                // Cannot do Openssl ping using openssl s_client reliably without hanging on windows.
                logger.info("Omitting OpenSSL ping not supported on windows.  ");
                opensslPingResult = null;
            } else {
                if( javaPingResult.getSSLState() == JavaPingResult.JavaSSLState.SSL_OFF){
                    // Do not run openssl client if no ssl server.  Openssl client would add no more information, 
                    // and can take upto 90 seconds because the connection timeout cannot be modified. 
                    opensslPingResult = null;
                } else {
                    // Typically handshake exception.  Or unexpected cause.  
                    // Openssl client can report certificates even if the handshake fails. 
                    opensslPingResult = opensslClient.ping(host,  sslPort);
                }
            }
            
            return new PingResult(endpoint, javaPingResult, opensslPingResult);
        }
    
    }
}
