package oracle.bi.ssl.config;

import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.pub.SSLException;
import oracle.bi.ssl.pub.SSLProtocols;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import java.security.KeyStore;


public final class SSLContextFactory {
    /**
     * No instances
     */
    private SSLContextFactory() {

    }

    /**
     * Create an SSLContext with given identity, trust and protocol options.  The SSLContext is specific for a given host -
     * this allows the context to do the host verification for SSL stacks (such as the FIPS 140-2 stack) which do not support
     * X509ExtendedTrustManager.
     *
     * @param hostname                 target.  Due to this field SSLContexts created here cannot be shared.  You must create a new one for each hostname.
     * @param sslProtocols             what protocols allowed, eg only TLSv1.2
     * @param hostVerification         whether to check host.  Note that even if this is HostVerification.ALLOW_ANY_HOST the client using the
     *                                 SSLContext may choose to force HTTPS style host checks by setting the SSLParameters EndpointIdentificationAlgorithm to https on the SSLSocket.
     *                                 HTTP based client - such as Jersey clients - do this.
     * @param identityKeyStoreAccessor accessor for key store objects.  If null, then the returned SSLContext will use JVM default.
     * @param identityAlias            the alias of the single identity we should use within the above idetityKeyStoreAccessor.
     * @param keystorePassphrase       to gain access to the key stores
     * @param identityKeyPassphrase    to gain access to the individual key
     * @param trustKeyStoreAccessor    accessor for trust store objects.   If null, then the returned SSLContext will use JVM default.
     * @return SSLContext
     * @throws SSLException on failure
     */
    public static SSLContext getSSLContext(
            String hostname,
            SSLProtocols sslProtocols,
            KeyStoreType keyStoreType,
            HostVerification hostVerification,
            KeyStoreAccessor identityKeyStoreAccessor,
            String identityAlias,
            Passphrase keystorePassphrase,
            Passphrase identityKeyPassphrase,
            KeyStoreAccessor trustKeyStoreAccessor) throws SSLException {
        try {
            final KeyManager[] keyManagers = identityKeyStoreAccessor == null ? null : getKeyManagers(keyStoreType, identityKeyStoreAccessor, identityAlias, keystorePassphrase, identityKeyPassphrase);

            final TrustManager[] trustManagers = trustKeyStoreAccessor == null ? null : getTrustManagers(hostname, hostVerification, trustKeyStoreAccessor);

            final SSLContext ctx = SSLContext.getInstance(sslProtocols.getBaseProtocol());
            ctx.init(keyManagers, trustManagers, null);

            return ctx;
        } catch (Exception e) {
            throw new SSLException("Unable to create ssl context due to: " + e.getMessage(), e);
        }
    }

    public static SSLContext getSSLContext(
            String hostname,
            SSLProtocols sslProtocols,
            HostVerification hostVerification,
            TrustManager[] trustManagers) throws SSLException {
        try {
            WrapperTrustManagerFactory.wrapTrustManagers(getRequiredHostname(hostname, hostVerification), trustManagers);

            final SSLContext ctx = SSLContext.getInstance(sslProtocols.getBaseProtocol());
            ctx.init(null, trustManagers, null);

            return ctx;
        } catch (Exception e) {
            throw new SSLException("Unable to create ssl context due to: " + e.getMessage(), e);
        }
    }

    private static TrustManager[] getTrustManagers(String hostname, HostVerification hostVerification, KeyStoreAccessor trustKeyStoreAccessor) throws Exception {
        final String requiredHostname = getRequiredHostname(hostname, hostVerification);
        return WrapperTrustManagerFactory.getTrustManagers(trustKeyStoreAccessor.getKeyStore(), requiredHostname);
    }

    private static String getRequiredHostname(String hostname, HostVerification hostVerification) {
        final String requiredHostname;
        if (hostVerification == HostVerification.ALLOW_ANY_HOST) {
            requiredHostname = null;
        } else {
            requiredHostname = hostname;
        }
        return requiredHostname;
    }

    private static KeyManager[] getKeyManagers(KeyStoreType keyStoreType,
                                               KeyStoreAccessor identityKeyStoreAccessor,
                                               String identityAlias,
                                               Passphrase keystorePassphrase,
                                               Passphrase identityKeyPassphrase) throws Exception {
        // Do not specify provider as "SunJSSE" since this is not available on AIX.
        final KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());

        final KeyStore singleEntryKeyStore =
                SingleIdentityKeyStoreFactory.createSingleIdentityKeyStore(identityKeyStoreAccessor, keyStoreType, identityAlias, keystorePassphrase, identityKeyPassphrase);

        kmf.init(singleEntryKeyStore, identityKeyPassphrase.getPassphraseChars());
        return kmf.getKeyManagers();
    }
}
