package oracle.bi.ssl.config;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Objects;

import javax.net.ssl.X509TrustManager;

import oracle.bi.ssl.certificate.CertificateSubjectNames;

/**
 * A trust manager which explicitly adds host checks.  Use for SSL stacks such as FIPS which do not support X509ExtendedTrustManager.  
 * We therefore have to do our own host checkin.  SSL stacks which support X509ExtendedTrustManager can use the 
 * {@link ExtendedHostTrustManager}
 *  
 */
final class HostTrustManager implements X509TrustManager
{
    private final String allowedHost;
    private final X509TrustManager baseTrustManager;

    public HostTrustManager(String allowedHost, 
            X509TrustManager baseTrustManager)
    {
        this.baseTrustManager = Objects.requireNonNull(baseTrustManager, "null baseTrustManager");
        this.allowedHost = Objects.requireNonNull(allowedHost, "null allowedHost");
    }


    private void checkSubjectNameTrusted(X509Certificate[] chain) throws CertificateException
    {
        System.out.println("checkSubjectNameTrusted");
        // Check the common name of the server certificate
        if( chain.length == 0 ){
            throw new CertificateException("No certificates in chain");
        }

        final X509Certificate serverCertificate = chain[0];

        final CertificateSubjectNames certificateSubjectNames = new CertificateSubjectNames(serverCertificate);
        certificateSubjectNames.checkSubjectNames(allowedHost);
        
    }

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType) 
            throws CertificateException
    {
        baseTrustManager.checkClientTrusted(chain, authType);
       
        checkSubjectNameTrusted(chain);
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType) 
            throws CertificateException
    {
        baseTrustManager.checkServerTrusted(chain, authType);
        
        checkSubjectNameTrusted(chain);
    }

    public X509Certificate[] getAcceptedIssuers()
    {
        return baseTrustManager.getAcceptedIssuers();
    }
}
