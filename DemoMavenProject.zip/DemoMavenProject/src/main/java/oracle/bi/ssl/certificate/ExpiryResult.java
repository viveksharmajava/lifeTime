package oracle.bi.ssl.certificate;

/**
 * Carries certificate expiry result in both string form (for display) and enum form (for further processing). 
 * @author pharry
 *
 */
public enum ExpiryResult { 
    MISSING("ERROR: Certificates missing.  You should run ssl[.sh] regenerate."),
    OK("All certificates have more than 30 days to expiry."), 
    WARNING("WARNING: One or more certificates have less than 30 days to expiry.  You should run ssl[.sh] regenerate. "), 
    EXPIRED("ERROR: One or more certificates have expired.  You must run regenerate. ");
    
    
    private final String resultString;
    
    public String getResultString() {
        return resultString;
    }

    

    private ExpiryResult(String resultString) {
        this.resultString = resultString;
    }
    
    
}
