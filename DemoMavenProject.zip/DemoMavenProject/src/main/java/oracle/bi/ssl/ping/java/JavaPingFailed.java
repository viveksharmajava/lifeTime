package oracle.bi.ssl.ping.java;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.Objects;

import javax.net.ssl.SSLException;

/**
 * Records why a Java SSL ping failed.  Recording the failure rather than just throwing allows the 
 * SSL report command to list multiple failures. 
 * 
 *
 */
public final class JavaPingFailed  extends JavaPingResult{
 
    private final Throwable _throwable;
    
    public JavaPingFailed(Throwable throwable){
        super(deriveStateFromThrowable(throwable));
        _throwable = Objects.requireNonNull(throwable, "null throwable");
    }

    @Override
    public String getSummary() {
        String msg = getSSLState().getMessage() + " " + _throwable.getMessage();
        
        return msg;
    }
    
    public Throwable getThrowable(){
        return _throwable;
    }
    
    /**
     * The state tries to summarise why the ping failed.  The mapping from throwable to state depends on the SSL stack in use - so 
     * varies depending on whether FIPS is enabled.  Converting to state is encapsulated inside the JavaPingFailed class. 
     * 
     */
    private static JavaSSLState deriveStateFromThrowable(Throwable t){
        if ( t instanceof SocketTimeoutException) {
            // Probably timed out attempting handshake due to other end not running ssl at all - but possible poor performance.
            return JavaSSLState.SSL_OFF;
        } if ( t instanceof SSLException){
            // Non FIPS security provider throws an javax.net.ssl.SSLHandshakeException, derived from SSLException. 
            // FIPS security provider throws SSLException
            return JavaSSLState.SSL_BAD_HANDSHAKE;
        } if ( t instanceof  ConnectException) {
            return JavaSSLState.CONNECT_FAILURE;
        } else {
            return JavaSSLState.UNEXPECTED_FAILURE;
        }
    }
}
