package oracle.bi.ssl.ping.openssl;




import oracle.bi.ssl.resources.SSLMsgId;
import oracle.bi.ssl.resources.SSLMsgResource;







/**
 * Contains result of running an ssl ping using an openssl client.  Unlike the Java client we don't have multiple 
 * failure classifications.  However we do have dumps of certificates. 
 */
public final class OpensslPingResult
{
   public enum OpensslState { 
      // Succeeded in connecting.  Exception will be null. 
      OPENSSL_OK(SSLMsgId.SSL_OK), 
      
      // Failed to connect.  
      OPENSSL_FAIL(SSLMsgId.SSL_FAIL);
      
     
      
      private final String msgId;
      
      private OpensslState(String msgId){
          this.msgId = msgId;
      }
      public String getMessage(){
          return SSLMsgResource.getMessage(msgId);
      }
   };
   
   
 
   private final OpensslState _sslState;
   private final String _logOutput;
   
   
   public static OpensslPingResult success(String logOutput){
       
       return new OpensslPingResult(OpensslState.OPENSSL_OK, logOutput);
   }
   
   
   
   public static OpensslPingResult failed(String logOutput){
       return new OpensslPingResult(OpensslState.OPENSSL_FAIL, logOutput);
   }
   /**
    * @param exception null if succeeded
    * @param details ignored if nullb
    */
   private OpensslPingResult(OpensslState sslState, String logOutput)
   {
      _sslState = sslState;
      _logOutput = logOutput;
   }

   public OpensslState getSSLState()
   {
      return _sslState;
   }
   
   public String getSummary(){
       return this._sslState.getMessage();
   }
   
   @Override
   public String toString()
   {
      final StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this._sslState.getMessage());
      
     
      
      if(_logOutput != null){
          stringBuilder.append("\n");
          stringBuilder.append( _logOutput);
      }
      
      return stringBuilder.toString();
   }
   
   public String getLogOutput(){
       return _logOutput;
   }
   
   
   
   
   

   
}
