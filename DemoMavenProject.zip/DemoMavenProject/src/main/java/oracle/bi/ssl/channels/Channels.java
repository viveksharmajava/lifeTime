package oracle.bi.ssl.channels;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Logger;

import oracle.bi.endpointmanager.jee.JEEMap;
import oracle.bi.endpointmanager.jee.WebApp;
import oracle.bi.endpointmanager.pub.Scope;
import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.commands.AdminServerConnectionConfig;
import oracle.bi.ssl.config.SSLConfigWrapper;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.credentials.CredentialAccessor;
import oracle.bi.ssl.exec.ExecWLST;
import oracle.bi.ssl.locations.Homes;
import oracle.bi.ssl.logging.EchoMode;
import oracle.bi.ssl.logging.ExecLogger;
import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.logging.OnCompletionExecLogger;
import oracle.bi.ssl.pub.SSLException;

/**
 * Manipulate channels in the WebLogic configuration.  Instead of using the external facing ports, we add our own internal_bi_channel1.
 * Since this channel is for our own use only, we can configure it with our own ssl server certificate without impacting external 
 * clients such as browsers.  If we were to use the external 
 * facing port we would have to work with whatever certificate the customer has chosen.  The customer would also have to give us the 
 * certificate authority (CA) certificate to match.  In 11g we di use the external channel and suffered multiple errors.  For example 
 * when customers gave us the wrong CA certificate, or used a special server certificate (eg wld card or self signed) which openssl does not support.
 * <p>
 * All changes to the weblogic config.xml file are made via wlst scripts which this code execs.  Nominally using WLST rather than direct edits to the 
 * config.xml should isolate us from the config.xml syntax.  Sadly since many of the wlst commands are little more than xml domain tree navigation 
 * commands (cd and ls) so we do not get a huge amount of protection.  Another problem with wlst commands is that the offline and online commands 
 * are often different.  In most cases we therefore only support offline.  
 * </p>
 * <p>
 * Internal channels have a port and ssl mode (HTTP or HTTPS) and a server certificate signed by our internal CA. 
 * </p>
 * <p>
 * The channels methods are used by:
 * <ul>
 * <li>ssl.sh command line tool</li>
 * <li>Directly by config assistant</li>
 * </ul>
 * </p>
 */
public final class Channels {
    private final static Logger logger = LoggerFactory.createLogger(Channels.class);
    
    private final SSLEnvironment sslEnvironment;
    private final EchoMode echoMode;
    
    /**
     * This is the public API used by the config assistant.  Called from within the create internal 
     * channels step (oracle.bi.install.config.steps.suites.InternalChannelsStep).  This is separate from 
     * the create SSL certificates step (oracle.bi.install.config.steps.suites.SSLStep).  
     * For backward compatibility take homes as argument, and convert the SSLException into a runtime exception.
     * @param homes
     * @param echoMode
     */
    public Channels(Homes homes, EchoMode echoMode){
        this( createSSLEnvironment(homes), echoMode);
        
    }
    
    /**
     * Convert new exception to a runtime one, to support the backward compatible constructor API. 
     * @param homes
     * @return 
     */
    private static SSLEnvironment createSSLEnvironment(Homes homes){
        try {
            return new SSLEnvironment(homes);
        } catch (SSLException e){
            throw new IllegalStateException("Unable to create SSLEnviornment", e);
        }
    }
    
    /**
     * Internal constructor - use within the SSL project, avoids unnecessarily creting a new SSLEnvironment instance. 
     * @param sslEnvironment
     * @param echoMode
     */
    public Channels(SSLEnvironment sslEnvironment, EchoMode echoMode){
        this.sslEnvironment = Objects.requireNonNull(sslEnvironment, "null sslEnvironment");
        this.echoMode = Objects.requireNonNull(echoMode, "null echoMode");
    }
    
    /**
     * Set system to use or not use ssl.  Will check that all servers in the bi_cluster are correctly set to use channels, and there is no 
     * overriding demo ssl configuration which clashes with channel configuration. 
     * <p>
     * Currently only implements the channel side of things. 
     * </p>
     * @param useSSL
     * @return
     * @throws SSLException
     */
    public void setUseSSL(SSLProtocol sslProtocol) throws SSLException{
        final Homes homes = this.sslEnvironment.getHomes();
        
        final ExecLogger execLogger = new OnCompletionExecLogger(logger, echoMode);
        final ExecWLST execWLST = new ExecWLST(homes, homes.getDomainLocations().getSSLCommandDir(), execLogger);
        final File enableScript = homes.getOracleHomeLocations().getSetProtocolScript();
        
        final List<String> args = Arrays.asList(
                enableScript.getAbsolutePath(), 
                homes.getDomainLocations().getDomainHome().getAbsolutePath(), 
                sslProtocol.name());
        execWLST.runWLSTCommand(args, new ArrayList<char[]>(), "Set channel protocol to " + sslProtocol.name());
        
        // Above script checks all channels set up correctly.  Only set ssl if script passes. 
        setSSLBIEE( sslProtocol);
    }
    
    
    
    /**
     * Ensure that all existing channels point to a certificate matching the listener - optionally use online WLST commands so scaleout 
     * can be done without turning the system off.  
     * @param AdminServerConnectionConfig if null use offline, if non-null use online admin server
     * @throws SSLException 
     */
    public void rebindChannelCertificates(AdminServerConnectionConfig adminServerConfig) throws SSLException{
        final ExecLogger execLogger = new OnCompletionExecLogger(logger, echoMode);
        final Homes homes = this.sslEnvironment.getHomes();
        final ExecWLST execWLST = new ExecWLST(homes, homes.getDomainLocations().getSSLCommandDir(), execLogger);
        final File enableScript = homes.getOracleHomeLocations().getRebindChannelCertificatesScript(adminServerConfig);
        
        if( adminServerConfig == null){
            // offline
            final List<String> args = Arrays.asList(
                    enableScript.getAbsolutePath(), 
                    homes.getDomainLocations().getDomainHome().getAbsolutePath());
            final List<char[]> inputs = new ArrayList<>();
            execWLST.runWLSTCommand(args, inputs, "rebindChannelCertificatesOffline");
        } else {
            // online
        
            final List<String> args = Arrays.asList(
                    enableScript.getAbsolutePath(), 
                    homes.getDomainLocations().getDomainHome().getAbsolutePath(),
                    adminServerConfig.getAdminServerConnectString(),
                    adminServerConfig.getUser());
            // Password is passed in over stdin, not in command line, since some OS's allow listing of other people's command lines. 
            final List<char[]> inputs = new ArrayList<>();
            inputs.add(adminServerConfig.getAdminPassword().getPassphraseChars());
            execWLST.runWLSTCommand(args, inputs, "rebindChannelCertificatesOnline");
        }
    }
    
    public void configureInitialCompactDomainChannels(int port, SSLProtocol sslProtocol) throws SSLException{
        final List<Channel> initialChannels = Collections.singletonList( new Channel("AdminServer", port));
        configureInitialChannels("AdminServer", initialChannels, sslProtocol);
    }
    
    public void configureInitialExpandedDomainChannels(int port, SSLProtocol sslProtocol) throws SSLException{
        final List<Channel> initialChannels = Collections.singletonList( new Channel("bi_server1", port));
        configureInitialChannels("bi_cluster", initialChannels, sslProtocol);
    }

    /**
     * Target applications at the virtual host.  May be called prior to channels being created, or after they have been 
     * created to fix the targeting of a newly added app.   The current ssl protocol (http or https) is left unchanged.  
     * @param deploymentTarget if null only target to virtual host if previously targeted, if non-null setup virtual host and target apps to it
     * @throws SSLException 
     */
    public void targetApps(String deploymentTarget) throws SSLException{
        final SSLProtocol currentSSLProtocol = getSSLProtocol();
        configureInitialChannels(deploymentTarget, new ArrayList<Channel>(),currentSSLProtocol);
    }
    /**
     * Since wlst invocations are expensive we have one very powerful entry point to do multiple steps in one call.  Targets 
     * applications, creates channels (including setting channelPort), sets sslprotocol. 
     * 
     * @param target deploymentTarget of virtual host and channels - cluster or single server (eg AdminServer).  The bi internal virtual host 
     * and hence all channels will be targeted only at this deployment target.  Should match the deployment target of the applications 
     * which are to be targeted at channels.  If null only target if a virtual host already exists.  
     * @param channels initial channels to create.  Can either create all now, or create one by one later.
     * @param sslProtocol
     */
    private void configureInitialChannels(String deploymentTarget, List<Channel> channels, SSLProtocol sslProtocol) throws SSLException{
        final Homes homes = this.sslEnvironment.getHomes();
        setSSLBIEE( sslProtocol);
        
        final ExecLogger execLogger = new OnCompletionExecLogger(logger, echoMode);
        final ExecWLST execWLST = new ExecWLST(homes, homes.getDomainLocations().getSSLCommandDir(), execLogger);
        final File channelScript = homes.getOracleHomeLocations().getCreateChannelScript();
        
        final CredentialAccessor credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        
        // On close, auto clears passphrase
        try(Passphrase passphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
            final char[] keystorePassphrase = passphrase.getPassphraseChars();
            final char[] keyPassphrase = passphrase.getPassphraseChars();
            
            // Hard wiring these app names and web appnames will make it hard for providers to change their names!  Need a declarative way via the 
            // endpoint api. 
            final List<char[]> inputs = Arrays.asList( keystorePassphrase, keyPassphrase);
            final List<String> argsList = new ArrayList<String>();
            argsList.add( channelScript.getAbsolutePath() );
            argsList.add("--domainhome");
            argsList.add( homes.getDomainLocations().getDomainHome().getAbsolutePath() );
            if( deploymentTarget != null){
                argsList.add( "--target");
                argsList.add( deploymentTarget );
            }
            argsList.add("--protocol");
            argsList.add(sslProtocol.name() );
            
            for(Channel channel : channels){
                argsList.addAll( Arrays.asList(
                  "--server", channel.getServerName(),
                  "--port", Integer.toString(channel.getChannelPort())
                  ));
            }
            
            /* Add web app scopes of form:
                "--app", "bi-actions",
                      "--webapp", "analytics/actions",
                      "--scope", "internal",
                      
               This drives the targetting of web apps to channel and or public port. 
             */
            
            // JEEMap takes BIProduct home NOT oracle home. 
            final JEEMap jeeMap = new JEEMap( homes.getOracleHomeLocations().getBiProductHome() );
            // Map from app name to web app name to WebApp
            final Map<String, Map<String, WebApp>> webapps = jeeMap.getWebApps();
            for( Map.Entry<String, Map<String, WebApp>> appEntry: webapps.entrySet() ){
                final String appName = appEntry.getKey();
                final Map<String, WebApp> webApps = appEntry.getValue();
                if( appUsesChannels(webApps)){
                    argsList.add( "--app"); argsList.add( appName);
                    for( WebApp webApp : webApps.values() ){
                        final Scope scope = webApp.getScope();
                        if( scope == Scope.INTERNAL || scope == Scope.DUAL){
                            argsList.add("--webapp"); argsList.add(webApp.getWebAppName());
                            final String scopeArg;
                            if( scope == Scope.INTERNAL){
                                scopeArg = "internal";
                            } else {
                                scopeArg = "dual";
                            }
                            argsList.add("--scope"); argsList.add(scopeArg);
                            logger.info("Setting scope = " + scopeArg + " for app " + appName + " web app " + webApp.getWebAppName() );
                            
                        } else {
                            logger.info("App " + appName + " has entirely external web apps" );
                        }
                    }
                }
                
            }
            
            /*
                    // Actions location/registry/execution servlets in actions web app used by obips and scheduler
                    "--app", "bi-actions",
                      "--webapp", "analytics/actions",
                      "--scope", "internal",
                    
                    // Security used by obis and scheduler.
                    "--app", "bi-security",
                      "--webapp", "bi-security",
                      "--scope", "internal",
                      
                    // ws for soa needs analytics-ws.  Also a public api. Current requirement to configure all web apps in an enterprise app 
                    // consistently (due to limitations in endpoint api registration mechanism) means make all three dual. 
                    "--app", "analytics#11.1.1",
                      "--webapp", "analytics",
                      "--scope", "dual",
                      "--webapp", "analytics-bi-adf",
                      "--scope", "dual",
                      "--webapp", "analytics-ws",
                      "--scope", "dual",
                              
                    
                    
            };
            */
            
            
            execWLST.runWLSTCommand(argsList, inputs, "target applications ");
        }
        
    }
    
    /**
     * Create internal bi channel on a server, listening on a port.  If the channel already exists will overwrite with the new configuration. 
     * Protocol is set to match current central ssl configuration. 
     * @param server
     * @param port
     * @return protocol channel created with
     * @throws SSLException
     */
    public SSLProtocol createChannel(String server, int port) throws SSLException{
        final Homes homes = this.sslEnvironment.getHomes();
        final ExecLogger execLogger = new OnCompletionExecLogger(logger, echoMode);
        final ExecWLST execWLST = new ExecWLST(homes, homes.getDomainLocations().getSSLCommandDir(), execLogger);
        final File channelScript = homes.getOracleHomeLocations().getCreateChannelScript();
        
        final CredentialAccessor credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        
        final SSLProtocol sslProtocol = this.getSSLProtocol();
        
        // On close, auto clears passphrase
        try(Passphrase passphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
            final char[] keystorePassphrase = passphrase.getPassphraseChars();
            final char[] keyPassphrase = passphrase.getPassphraseChars();
            
            final List<char[]> inputs = Arrays.asList( keystorePassphrase, keyPassphrase);
            final String [] argsArray = {
                    channelScript.getAbsolutePath(),
                    "--domainhome",
                    homes.getDomainLocations().getDomainHome().getAbsolutePath(),
                    "--server",
                    server,
                    "--port",
                    Integer.toString(port),
                    "--protocol",
                    sslProtocol.toString()
            };
            
            final List<String> args = Arrays.asList( argsArray);
            // Although it uses the same underlying WLST script as the initial setup script, we do not add any new app targetting.  The setup script is 
            // a general purpose script doing all things to do with channels.  This allows setup to do lots of things without calling WLST multiple 
            // times - which is very slow. 
            execWLST.runWLSTCommand(args, inputs, "Create channel on server " + server + " port " + port);
            
            return sslProtocol;
        }
    }
    
    public SSLProtocol createChannels(HashMap<String, String> map) throws SSLException
    {
        final Homes homes = this.sslEnvironment.getHomes();
        final ExecLogger execLogger = new OnCompletionExecLogger(logger, echoMode);
        final ExecWLST execWLST = new ExecWLST(homes, homes.getDomainLocations().getSSLCommandDir(), execLogger);
        final File channelScript = homes.getOracleHomeLocations().getCreateChannelScript();
        
        final CredentialAccessor credentialAccessor = new CredentialAccessor(homes.getDomainLocations());
        
        final SSLProtocol sslProtocol = this.getSSLProtocol();
        
        // On close, auto clears passphrase
        try(Passphrase passphrase = credentialAccessor.getPassphrase(CredentialAccessor.SSL_INTERNAL_PASSPHRASE);){
            final char[] keystorePassphrase = passphrase.getPassphraseChars();
            final char[] keyPassphrase = passphrase.getPassphraseChars();
            
            final List<char[]> inputs = Arrays.asList( keystorePassphrase, keyPassphrase);
           
            final List<String> argsArray = new ArrayList<String>();
            argsArray.add( channelScript.getAbsolutePath() );
            argsArray.add("--domainhome");
            argsArray.add( homes.getDomainLocations().getDomainHome().getAbsolutePath() );             
            
            for (Map.Entry<String, String> entry : map.entrySet()) {
                   argsArray.addAll( Arrays.asList(
                        "--server",  entry.getKey(),
                        "--port", entry.getValue()
                   ));
            }
          
            argsArray.add("--protocol");
            argsArray.add(sslProtocol.toString());
            
            final List<String> args = argsArray;
            // Although it uses the same underlying WLST script as the initial setup script, we do not add any new app targetting.  The setup script is 
            // a general purpose script doing all things to do with channels.  This allows setup to do lots of things without calling WLST multiple 
            // times - which is very slow. 

            execWLST.runWLSTCommand(args, inputs, "Creating channel on servers");
            
            return sslProtocol;
        }
    }    
    
    /**
     * 
     * @param webApps
     * @return true if any web app has a scope which uses an internal channel
     */
    private boolean appUsesChannels(Map<String, WebApp> webApps){
        for( WebApp webApp : webApps.values() ){
            final Scope scope = webApp.getScope();
            if( scope == Scope.DUAL || scope == Scope.INTERNAL){
                return true;
            }            
        }
        return false;
    }
    
    /**
     * Edits the central ssl config file to enable/disable internal BIEE ssl. 
     * @param sslProtocol
     * @throws SSLException
     */
    private void setSSLBIEE(SSLProtocol sslProtocol) throws SSLException{
        final SSLConfigWrapper sslConfig = this.sslEnvironment.getConfigWrapper();
        sslConfig.setSslEnabled( sslProtocol == SSLProtocol.https);
        sslConfig.save();
    }
    
    /**
     * Read the central ssl config file to get current value of enable/disable ssl
     * @return
     * @throws SSLException 
     */
    private SSLProtocol getSSLProtocol() throws SSLException{
        final SSLConfigWrapper sslConfig = this.sslEnvironment.getConfigWrapper();
        if( sslConfig.isSslEnabled() ){
            return SSLProtocol.https;
        } else {
            return SSLProtocol.http;
        }
    }
}
