package oracle.bi.ssl.files;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.ssl.logging.LoggerFactory;
import oracle.bi.ssl.pub.SSLException;

import org.apache.commons.io.FileUtils;

/**
 * Simple file utilities
 */
public final class SSLFileUtils
{
   private final static Logger _logger = LoggerFactory.createLogger(SSLFileUtils.class);
   /**
    * No instances
    */
   private SSLFileUtils()
   {
   }
   
   /**
    * Return file under dir, deleting any existing file.  Use for intermediate files.  Note that the file remains 
    * in situ - there is no auto deletion.  Hence deletion on each call.  
    * Leaving the file in situ makes debugging any problems with the chain of steps easier.  Id does mean that the 
    * file should not contain security sensitive information. 
    * @param dir
    * @param name
    */
   public static File unusedFile(File dir, String name) throws SSLException {
       final File file = new File(dir,name);
       try {
           if( file.exists() ){
               if( !file.isFile() ){
                   throw new SSLException("File to be deleted at " + file.getAbsolutePath() + " is not a file ");
               }
               FileUtils.forceDelete(file);
           }
       } catch (IOException e) {
           throw new SSLException("Unable to delete existing file at " + file.getAbsolutePath(), e);
       }
       return file;
   }

   /**
    * Read all the contents of a binary file
    */
   public static byte[] readBinaryFile(File inFile) throws SSLException
   {
     
       final ByteArrayOutputStream accumulator = new ByteArrayOutputStream();
              
       try (FileInputStream is = new FileInputStream(inFile);){
         
         int i;
         while( (i = is.read()) != -1)
         {
            byte b = (byte)i;
            accumulator.write(b);
         }
         return accumulator.toByteArray();
       } 
       catch(IOException e)
       {
         throw new SSLException("Failed to read file " + inFile.getAbsolutePath() );
       }
       
   }

   /**
    * Copy a file (text or binary).  Resultant file is set to private.   
    */
   public static void copyFilePrivate(File in, File out) throws SSLException
   { 
         try {            
             FileUtils.copyFile(in,  out);
         } catch(IOException e) {
             throw new SSLException("Failed to copy file from " + in+ " to "+ out, e);
         }
           
         FilePermissions.setPrivateFilePermissions(out);
         
      
   }
   
   /**
    * Ensure file contains given content, creating a new file if there is no existing file. 
    * If an existing identical file exists it does 
    * nothing to avoid unnecessary read/write lock conflicts. 
    * If an existing file exists but the contents do not match it is overwritten by a new file. 
    * @param content full content of file.  No extra line feeds etc will be added. If null, no content. 
    * As a char array rather than a string to conform to recommendations for manipulating passwords in 
    * memory.  
    * @param filePurpose added to log and errors.  Eg "passphrase file"
    */
   public static void syncContentInTextFile(File file, char[] content, String filePurpose) throws SSLException
   {
     _logger.log(Level.FINE, "Creating " + filePurpose + ", " + file.toString() );
      
      createNewTextFile(file, content, filePurpose);
      
   }
   
   
   
   /**
    * Create a new file, silently overriding any existing file.  
    * @param file
    * @param content
    * @param filePurpose
    * @throws SSLException
    */
   private static void createNewTextFile(File file, char[] content, String filePurpose) 
   throws SSLException
   {
      
      try (Writer  w = new OutputStreamWriter(new FileOutputStream(file), Charset.defaultCharset()/*make it explicit that we're relying on default encoding*/);
           PrintWriter pw = new PrintWriter(w);   ){
          // All the contents of the file make up the content - even including line feeds.  So must not 
          // have a linefeed artifically added here.
          if( content != null){      
              pw.write(content);
          }
      } catch(IOException e) {
         throw new SSLException("Failed to create " + file.getAbsolutePath() + " for " + filePurpose, e);
      }
      
      
      // All of the SSL-specific files are worth protecting as only user-visible.
      FilePermissions.setPrivateFilePermissions(file);
      
      
   }
   
   /**
    * Ensure a directory exists.  This is weaker than createPrivateCleanDir - do not assume its just for our use, 
    * so do not clean out.  Typically used for temp dirs shared amongst multiple parts of the system, of for configuration 
    * dirs created on demand in the domain. 
    * @param dir
    * @throws SSLException
    */
   public static void ensureDirExists(File dir) throws SSLException{
       if( !dir.exists() ){
           try {
               if (!Files.exists(dir.toPath())) {
                   Files.createDirectories(dir.toPath());
               }
           } catch (IOException e) {
               throw new SSLException("Unable to create directory " + dir.getAbsolutePath(), e);
           }
       }
   }
   
   /**
    * Ensure directory exists and is empty.  Ensure has private permissions.
    * @param dir
    * @throws SSLException
    */
   public static void createPrivateCleanDir(File dir) throws SSLException
   {
       
       try{
           
           FileUtils.forceMkdir(dir);
       } catch(IOException e){
           throw new SSLException("Failed to mkdir " + dir.getAbsolutePath(), e);
       }
       FilePermissions.setPrivateDirPermissions(dir);
       
       try{
           FileUtils.cleanDirectory(dir);
       } catch (IOException e){
           throw new SSLException("Failed to clean dir " + dir, e);
       }
   }
   
   
  
   
   
   
   /**
    * Check new file exists, and is non-zero in size, and then set its private permissions.
    * This is used to confirm that 
    * certificate creation has worked.  Openssl is prone to producing empty files 
    * if the arguments are wrong.  An exception here is the result of a bug.  There is typically nothing a customer can do to fix it. 
    * Its just like a NullPointerException.  So dont translate!
    * @param comment operation which should have produced this file.  Used in exception string.  
    */
   public static void checkNewlyCreatedFile(File file, String comment) throws SSLException
   {
       FilePrereqs.checkNonEmptyFile(file, comment);
       FilePermissions.setPrivateFilePermissions(file);
       
   }
   
   /**
    * Delete file if it exists
    */
   public static void optionalDeleteFile(File file) throws SSLException 
   {
       if( file.exists() ){
           try {
               FileUtils.forceDelete(file);
           } catch (IOException e) {
               throw new SSLException("Cannot delete file " + file.getAbsolutePath(), e);
           }
       }
   }
}


