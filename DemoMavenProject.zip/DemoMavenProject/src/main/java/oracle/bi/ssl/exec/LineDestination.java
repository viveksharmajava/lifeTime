package oracle.bi.ssl.exec;



/**
 * Destination of individual lines from an exec process 
 */
interface LineDestination   {
   void consumeLine(String line);
   
   
}
