package oracle.bi.ssl.resources;

/**
 * Message IDs used by the SysmanCommon.
 */
public class SSLMsgId {

    /**
     * Private constructor. Don't want this class instantiated.
     */
    private SSLMsgId() {
    }
    
   
    public static final String SSL_OK = "SSL_OK";
    public static final String SSL_OFF = "SSL_OFF";
    public static final String SSL_BAD_HANDSHAKE = "SERVER_OFF";
    public static final String CONNECT_FAILURE = "CONNECT_FAILURE";
    public static final String BAD_CN = "BAD_CN";
    public static final String SSL_FAIL = "SSL_FAIL";
    public static final String UNEXPECTED_FAILURE = "UNEXPECTED_FAILURE";
}

