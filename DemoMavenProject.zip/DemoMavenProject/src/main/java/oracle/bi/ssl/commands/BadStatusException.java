package oracle.bi.ssl.commands;

/**
 * Carries non 0 process status.  Intended to propagate status to the exit call.   Any output should already 
 * have been performed by the thrower.  Hence no useful message included. 
 *
 */
public final class BadStatusException extends Exception{
    
    public final static BadStatusException BAD_ARG_COUNT_STATUS = new BadStatusException(11);
    public final static BadStatusException BAD_USAGE_STATUS = new BadStatusException(12);
    public final static BadStatusException EXPIRED_STATUS = new BadStatusException(13);
    public final static BadStatusException EXPIRY_WARNING_STATUS = new BadStatusException(14);
    public final static BadStatusException CERTS_MISSING_STATUS = new BadStatusException(15);
    public final static BadStatusException SCAN_FAILURE_STATUS = new BadStatusException(16);
    public final static BadStatusException EXCEPTION_STATUS = new BadStatusException(17);
    public final static BadStatusException NOT_OFFLINE_STATUS = new BadStatusException(18);
    public final static BadStatusException EMPTY_PASSPHRASE_STATUS = new BadStatusException(19);
    
    private static final long serialVersionUID = 1L;
    
    private final int status;
    
    private BadStatusException(int status){
        this.status = status;
    }
    
    public int getStatus(){
        return status;
    }
}
