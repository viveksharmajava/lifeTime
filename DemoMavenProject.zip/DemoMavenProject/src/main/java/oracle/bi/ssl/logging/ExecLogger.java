package oracle.bi.ssl.logging;


/**
 * Log lines from process execution.  Implementations may log stdErr and stdOut to separate log destinations, or interleave, or 
 * accumulate until completion.  Log lines are associated with a source which is a human readable name of the process.  Loggers may 
 * choose to prefix with the source or may discard.  Since stderr and stdout are consumed concurrently, all calls should be 
 * protected from concurrent access. 
 */
public interface ExecLogger
{ 
 
    public void stdErr(String source, String line);

    public void stdOut(String source, String line);

    /**
     * Clear any accumulated lines
     */
    public void clear();

    public String getStderr();

    /**
     * If the process failed an accumulating logger may choose to log at a higher level.
     * @param success
     */
    public void completed(boolean success);
}

