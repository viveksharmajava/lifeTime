package oracle.bi.ssl.ping;


import oracle.bi.ssl.certificate.Passphrase;
import oracle.bi.ssl.config.HostVerification;
import oracle.bi.ssl.config.KeyStoreType;
import oracle.bi.ssl.config.SSLConfigWrapper;
import oracle.bi.ssl.config.SSLEnvironment;
import oracle.bi.ssl.jps.KeyStoreAccessor;
import oracle.bi.ssl.locations.OpensslCertificateFileLocations;
import oracle.bi.ssl.openssl.OpensslEndpoint;
import oracle.bi.ssl.ping.java.JavaSSLClient;
import oracle.bi.ssl.ping.java.SSLSpec;
import oracle.bi.ssl.ping.openssl.OpensslClient;
import oracle.bi.ssl.pub.SSLException;

/**
 * Creates clients for each trust and technology stack. 
 * @author pharry
 *
 */
public final class Clients {

    private final OpensslClient internalOpensslClient;
    private final OpensslClient httpsOpensslClient;
    private final JavaSSLClient internalJavaSslClient;
    private final JavaSSLClient httpsJavaSslClient;
    
    
    public Clients(SSLEnvironment sslEnvironment, Passphrase sharedPassphrase, KeyStoreType keyStoreType) throws SSLException{
        
        final SSLConfigWrapper sslConfig = sslEnvironment.getConfigWrapper();
        final KeyStoreAccessor biIdentityKeyStore = sslConfig.getBIIdentityKeyStoreAccessor();
        final KeyStoreAccessor biTrustKeyStore = sslConfig.getBIInternalTrustKeyStoreAccessor();
        
        
        // The ping is designed to test that all certificates are set up correctly for use internally between servers.  So use the 
        // internal identities, not the client identities. 
        
        internalJavaSslClient = 
                new JavaSSLClient(
                        new SSLSpec(
                                  keyStoreType,
                                  sslConfig.getSSLAlgorithms(), 
                                  HostVerification.ALLOW_ANY_HOST, 
                                  biIdentityKeyStore, 
                                  sslConfig.getIdentityAlias(), 
                                  sharedPassphrase, 
                                  sharedPassphrase,
                                  biTrustKeyStore)
                        );
        httpsJavaSslClient = 
                new JavaSSLClient(
                        new SSLSpec(
                                  keyStoreType,
                                  sslConfig.getSSLAlgorithms(), 
                                  HostVerification.MATCH_HOST, 
                                  biIdentityKeyStore, 
                                  sslConfig.getIdentityAlias(),
                                  sharedPassphrase,
                                  sharedPassphrase,
                                  biTrustKeyStore)
                        );
        
        final OpensslCertificateFileLocations opensslCertLocations = 
                new OpensslCertificateFileLocations(sslEnvironment.getHomes().getDomainLocations());
        final OpensslEndpoint httpsOpensslEndpoint = new OpensslEndpoint(
                        opensslCertLocations.getExternalTrustDir(), 
                        opensslCertLocations.getOpensslServerCertificate(),
                        opensslCertLocations.getOpensslServerKey(),
                        sharedPassphrase,
                        sslConfig.getOpensslCipherListString());
        final OpensslEndpoint internalOpensslEndpoint = new OpensslEndpoint(
                        opensslCertLocations.getInternalTrustDir(), 
                        opensslCertLocations.getOpensslServerCertificate(),
                        opensslCertLocations.getOpensslServerKey(),
                        sharedPassphrase,
                        sslConfig.getOpensslCipherListString());
        
        // Switched trust dirs result in very odd self signed certificate error??
        internalOpensslClient = new OpensslClient(sslEnvironment, internalOpensslEndpoint);
        httpsOpensslClient = new OpensslClient(sslEnvironment, httpsOpensslEndpoint);
        
    }


    public OpensslClient getInternalOpensslClient() {
        return internalOpensslClient;
    }


    public OpensslClient getHTTPSOpensslClient() {
        return httpsOpensslClient;
    }


    public JavaSSLClient getInternalJavaSslClient() {
        return internalJavaSslClient;
    }


    public JavaSSLClient getHTTPSJavaSslClient() {
        return httpsJavaSslClient;
    }
    
    
}
