package ToolsQA;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          System.out.println("Hello323");
          try{  
        	//step1 load the driver class  
        	Class.forName("oracle.jdbc.driver.OracleDriver");  
        	  
        	//step2 create  the connection object  
        	Connection con=DriverManager.getConnection(  
        	"jdbc:oracle:thin:SECURITY_SCHEMAUSER/welcome1@//100.105.27.12:26653/PDBORCL.LOCALDOMAIN");  
        	  
        	//step3 create the statement object  
        	Statement stmt=con.createStatement();  
        	  
        	//step4 execute query  
        	//System.out.println("before db sleep");
        	//stmt.executeQuery("dbms_session.sleep(5)");  
        	//System.out.println("after db sleep");
        	ResultSet rs=stmt.executeQuery("select * from BISEC_APP_ROLE");  
        	while(rs.next())  
        	System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
        	  
        	//step5 close the connection object  
        	con.close();  
        	  
        	}catch(Exception e){ System.out.println(e);}  
        	  
        	 
	
	     Thread t1 = new Thread("Update"){
	    	 public void run(){
	    		 //update  BISEC_APP_ROLE set description='Custom description' where stripe_guid='207FC6963045022CE063040011AC3E5B';
	    	 

	    			// TODO Auto-generated method stub
	    	          System.out.println("Updating");
	    	          try{  
	    	        	//step1 load the driver class  
	    	        	Class.forName("oracle.jdbc.driver.OracleDriver");  
	    	        	  
	    	        	//step2 create  the connection object  
	    	        	Connection con=DriverManager.getConnection(  
	    	        	"jdbc:oracle:thin:SECURITY_SCHEMAUSER/welcome1@//100.105.27.12:26653/PDBORCL.LOCALDOMAIN");  
	    	        	  
	    	        	//step3 create the statement object  
	    	        	Statement stmt=con.createStatement();  
	    	        	  
	    	        	//step4 execute query  
	    	        	//System.out.println("before db sleep");
	    	        	//stmt.executeQuery("dbms_session.sleep(5)");  
	    	        	//System.out.println("after db sleep");
	    	        	int rows = stmt.executeUpdate("update  BISEC_APP_ROLE set description=\'Custom description\' where stripe_guid=\'207FC6963045022CE063040011AC3E5B\'");  
	    	        	System.out.println("Rows updated ="+rows);
	    	        	 Thread.sleep(50000);
	    	        	rows = stmt.executeUpdate("insert into BISEC_APP_ROLE(app_role_guid,stripe_guid, name,display_Name) values('207FC6DA03180360E063040011ACBabc','207FC6963045022CE063040011AC3E5B'  , 'DVContentAuthor121','DVContentAuthor121')");  
	    	        	System.out.println("Rows inserted  ="+rows);
	    	        	//while(rs.next())  
	    	        	//System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
	    	        	
	    	        	//step5 close the connection object  
	    	        	 System.out.println("Update completed");
	    	        	stmt.close();
	    	        	con.close();  
	    	        	  
	    	        	}catch(Exception e){ System.out.println(e);}  
	    	        	  
	    		
	    	 }
	     };
	     
	     Thread t2 = new Thread("Delete"){
	    	 public void run(){
	    		 //update  BISEC_APP_ROLE set description='Custom description' where stripe_guid='207FC6963045022CE063040011AC3E5B';
	    	 

	    			// TODO Auto-generated method stub
	    	          System.out.println("Deleting");
	    	          try{  
	    	        	//step1 load the driver class  
	    	        	Class.forName("oracle.jdbc.driver.OracleDriver");  
	    	        	  
	    	        	//step2 create  the connection object  
	    	        	Connection con=DriverManager.getConnection(  
	    	        	"jdbc:oracle:thin:SECURITY_SCHEMAUSER/welcome1@//100.105.27.12:26653/PDBORCL.LOCALDOMAIN");  
	    	        	  
	    	        	//step3 create the statement object  
	    	        	 PreparedStatement preparedStatement = con.prepareStatement("delete from BISEC_APP_ROLE where stripe_guid=\'207FC6963045022CE063040011AC3E5B\'");
	    	        	 int row = preparedStatement.executeUpdate();
                       
	    	             // rows affected
	    	             System.out.println("rows deleted "+row);
	    	        	//step4 execute query  
	    	        	//System.out.println("before db sleep");
	    	        	//stmt.executeQuery("dbms_session.sleep(5)");  
	    	        	//System.out.println("after db sleep");
	    	        	//while(rs.next())  
	    	        	//System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
	    	        	 Thread.sleep(5000);
	    	        	//step5 close the connection object  
	    	        	
	    	        	con.close();  
	    	        	System.out.println("Delete completed");
	    	        	  
	    	        	}catch(Exception e){ System.out.println(e);}  
	    	        	  
	    		
	    	 }
	     };
	     
	     t1.start();
	     try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     t2.start();
	}
	}

