package ToolsQA;

import java.util.HashSet;

public class MatchMapping {

	public static void main(String[] args) {
		
		String [] restclient ={"    download (group: 'com.oracle.bi.cache', name: 'bi-cache', version: '1.+', classifier: 'schema-config', ext: 'xml')","    downloadjars (group: 'commons-cli', name: 'commons-cli', version: '1.5.0', ext: 'jar')","    downloadjars (group: 'com.oracle.bi.platform', name: 'bi-bootstrap-utils', version: '1.0.+', ext: 'jar')","    downloadjars (group: 'com.oracle.bi.platform', name: 'bi-base-lcm-api', version: '1.0.+', ext: 'jar')","    downloadjars (group: 'com.oracle.bi.platform', name: 'bi-servicelcm-api', version: \"${serviceLcmApiVersion}\", ext: 'jar', transitive: false)","    downloadjars (group: 'com.oracle.bi.platform', name: 'oa-platform-utils', version: '2.0.8.0.0+', ext: 'jar')","    downloadjars (group: 'jakarta.xml.bind', name: 'jakarta.xml.bind-api', version: '2.3.2', ext: 'jar')","    downloadjars (group: 'org.slf4j', name: 'slf4j-api', version: '1.7.36', ext: 'jar')","    downloadjars (group: 'com.oracle.bi.platform', name: 'bi-endpointmanager-pub', version: '1.0.0.0+')","    downloadjars (group: 'com.oracle.bi.platform', name: 'bi-endpointmanager-impl', version: '1.0.0.0+')    ","    downloadjars (group: 'org.apache.commons', name: 'commons-collections4', version: '4.4-3839ecf')","    downloadjars (group: 'com.oracle.coherence', name:'coherence', version:'12.2.1-4-0-73500', ext: 'jar')","    downloadjars (group:'com.fasterxml.jackson.core',name:'jackson-databind', version:\"${jacksonVersion}\",ext:'jar')","    downloadjars (group:'com.fasterxml.jackson.core',name:'jackson-annotations', version:\"${jacksonVersion}\",ext:'jar')","    downloadjars (group:'com.fasterxml.jackson.core',name:'jackson-core', version:\"${jacksonVersion}\",ext:'jar')","    downloadjars (group: 'org.apache.commons', name: 'commons-lang3', version: '3.14.0', ext: 'jar')","    downloadjars (group: 'com.oracle.weblogic', name:'javax-json', version:'1-0-1693252.187', ext: 'jar')","    downloadjars (group: 'commons-io', name: 'commons-io', version: '2.13.0', ext: 'jar')","    downloadjars (group: 'com.oracle.bi.securestore', name: 'bi-securestore', version :'1.0.0.0.0-+')","    downloadjars (group: 'com.nimbusds', name: 'nimbus-jose-jwt', version :'9.39')","    downloadjars (group: 'com.oracle.bi.http', name:'bi-http-client', version:\"${biHttpClientVersion}\", ext: 'jar')","    downloadjars (group: 'org.apache.httpcomponents', name:'httpclient', version:'4.5.14', ext: 'jar')","    downloadjars 'com.oracle.bi.uploaded:ojdl:12.1.3.0.0-+'","    downloadjars 'com.oracle.bi.contentstorage:bi-contentstorage-common:1.9.0.0.0-+'","    downloadjars 'org.apache.commons:commons-text:1.10.0'","    downloadjars (group: 'net.minidev', name:'json-smart', version:'2.5.0', ext: 'jar')","    downloadjars (group: 'net.minidev', name:'accessors-smart', version:'2.5.0')","    downloadjars 'com.google.code.gson:gson:2.9.0'","    downloadjars ('com.oracle.pki:oraclepki:8.0.0-190227.2343@jar')","    downloaddb 'com.oracle.bi.uploaded:ojdl:12.1.3.0.0-+'","    downloaddb 'com.oracle.bi.contentstorage:bi-contentstorage-common:1.9.0.0.0-+'","    downloaddb 'org.flywaydb:flyway-core:4.1.2'","    downloaddb 'com.oracle.bi.schema:schema_plugin:1.0.2.0.0-20180710141850'","    downloaddb 'com.oracle.bi.schema:schema_plugin_api:1.0.1.2.0-20191125183320'","    downloaddb 'com.oracle.bi.config:config_plugin_api:1.0.1.2.0-20191125183320'","    downloaddb 'com.oracle.jdbc:ojdbc7:1.0.0-140210.1116'","    downloaddb 'commons-io:commons-io:2.13.0'","    downloaddb 'com.oracle.weblogic:javax-json:1-0-1693252.187'","    downloadjacoco (group: 'org.jacoco', name: 'jacoco', version: '0.8.6', ext:'zip')","    downloadcachejars (group: 'com.oracle.bi.cache', name: 'bi-cache', version: '1.+', ext: 'jar')","    downloadcachejars (group: 'com.oracle.bi.cache.manifest', name: 'bi-cache-manifest', version: '1.+', ext: 'jar')","    testCompile (group:'com.fasterxml.jackson.core',name:'jackson-databind', version:\"${jacksonVersion}\",ext:'jar')"};
        HashSet <String> set1 = new HashSet<>();
		for(int i=0; i < restclient.length; i++){
        	if(restclient[i].contains("group:")){
        		System.out.println(restclient[i].substring(restclient[i].indexOf("group:")+8,restclient[i].indexOf("name:"))+"\t "+
        				restclient[i].substring(restclient[i].indexOf("name:")+6
        				));
        		set1.add(restclient[i].substring(restclient[i].indexOf("group:")+8,restclient[i].indexOf("name:")) +"\t "+
        				restclient[i].substring(restclient[i].indexOf("name:")+6)
        				);
        	 
        	}
        	else{
        		set1.add(restclient[i].substring(restclient[i].indexOf("'"),restclient[i].lastIndexOf("'")));
        	  System.out.println("Else "+restclient[i].substring(restclient[i].indexOf("'"),restclient[i].lastIndexOf("'")));
        	}
        }
		
		System.out.println("Set \n"+set1);
	}

}
